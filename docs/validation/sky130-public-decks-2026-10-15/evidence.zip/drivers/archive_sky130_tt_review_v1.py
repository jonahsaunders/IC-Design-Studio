import datetime
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
repo=root/'work/IC-Design-Studio'
outputs=root/'outputs'
source=outputs/'sky130-tt-precheck-review-v2'
failed=outputs/'sky130-tt-precheck-review-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
native=json.loads((source/'record.json').read_bytes())
assert native['status']=='PASS' and native['reference_native_checks_pass']
assert len(native['runs'])==14 and len(native['controls'])==4
assert native['driver_sha256']==sha(repo/'scripts/review_sky130_public_decks.py')
systems={p:json.loads((source/p/'tests.json').read_bytes()) for p in ('win32','linux')}
for p,data in systems.items():
    assert data['status']=='PASS' and data['tests']==14 and not any(data[x] for x in ('failures','errors','skipped'))
    assert data['log_sha256']==sha(source/p/'tests.log')
    for path,digest in data['sources'].items():assert sha(repo/path)==digest
assert systems['win32']['sources']==systems['linux']['sources']
for item in native['runs']:
    run=source/item['label']/item['deck']
    for file,key in [('report.lyrdb','report_sha256'),('stdout.log','stdout_sha256'),('stderr.log','stderr_sha256')]:
        assert sha(run/file)==item[key]
files={}
for label,directory in [('accepted',source),('failed-trial',failed)]:
    for path in sorted(directory.rglob('*')):
        if path.is_file():files[label+'/'+path.relative_to(directory).as_posix()]=path.read_bytes()
for case in ('counter','uart','apb'):
    p=outputs/'sky130-application-boundary-v1/linux'/case/'sky130-pin-export/final.gds'
    hashes={r['gds_sha256'] for r in native['runs'] if r['label']==case}
    assert hashes=={sha(p)}
    files['references/'+case+'/sky130-pin-export/final.gds']=p.read_bytes()
for rel in ('scripts/review_sky130_public_decks.py','scripts/sky130_interconnect_geometry.py',
            'tests/test_sky130_interconnect_geometry.py','LICENSE','licenses/Apache-2.0.txt'):
    files['source/'+rel]=(repo/rel).read_bytes()
fixture=repo/'tests/fixtures/sky130-public-decks-v1'
for p in sorted(fixture.rglob('*')):
    if p.is_file():files['source/tests/fixtures/sky130-public-decks-v1/'+p.relative_to(fixture).as_posix()]=p.read_bytes()
for name in ('run_sky130_tt_precheck_review_v1.py','record_sky130_tt_tests_v1.py','archive_sky130_tt_review_v1.py'):
    files['drivers/'+name]=(root/'work'/name).read_bytes()
files['NOTICES.txt']=b'''SKY130 public-deck comparison evidence, 2026-10-15.
Unmodified Tiny Tapeout and ChipFoundry decks retain their explicit GNU GPLv3
headers and the full license in source/tests/fixtures/sky130-public-decks-v1.
Their upstream URLs and exact identities are in source-lock.json there.
Studio's added scripts and synthetic controls are GPL-3.0-or-later; source/LICENSE.
The three reference layouts contain SkyWater HD standard cells from the pinned
sky130-fa87f8f4bbcc7255b6f0c0fb506960f531ae2392 Volare release. SkyWater source
and derivative assets retain Apache-2.0: source/licenses/Apache-2.0.txt.
Copyright 2020 The SkyWater PDK Authors; original PDK source and notices:
https://github.com/google/skywater-pdk-libs-sky130_fd_sc_hd
Generated counter/UART/APB designs retain the Studio project's license.
The failed-trial used 81:10 instead of 81:2 for the core marker. Its failed
assertion is retained, not counted as accepted control evidence.
The accepted comparison has 14 native runs and 14 targeted tests on each OS.
Passing these checks does not establish complete catalog or foundry signoff.
Reproduce using source/scripts/review_sky130_public_decks.py --reference-root
<extracted>/references --output <new-directory> --klayout <native-executable>.
Python needs klayout.db; native KLayout requires Ruby DRC support.
'''
manifest={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(files.items())}
files['SHA256SUMS.json']=(json.dumps(manifest,indent=2)+'\n').encode()
destination=repo/'docs/validation/sky130-public-decks-2026-10-15'
destination.mkdir(exist_ok=True)
archive=destination/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,content in sorted(files.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,15,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,content)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,entry in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==entry['sha256']
permanent=Path(r'C:/Users/jonah/Documents/Codex/IC-Design-Studio-evidence/sky130-public-decks-2026-10-15-v1')
permanent.mkdir(exist_ok=True)
shutil.copyfile(archive,permanent/'evidence.zip')
assert sha(archive)==sha(permanent/'evidence.zip')
report=dict(schema=1,chunk=6,status='public-deck-comparison-verified',qualified=False,chunk_complete=False,
    checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    application_commit_before_review='782262ee673507f0570380d858fc037806d04eb0',
    new_coverage_decisions=0,unresolved_catalog_records=302,
    user_resource_preference='Prioritize Tiny Tapeout public resources where per-file licenses and actual coverage support reuse.',
    scope='Six native reference runs pass FEOL/BEOL/off-grid checks. Eight native controls establish a missing-contact difference. This is not full Tiny Tapeout precheck or complete physical qualification. Application runtime behavior is unchanged.',
    native=native,systems=systems,
    sources=json.loads((fixture/'source-lock.json').read_bytes()),
    findings=[
        'The Tiny Tapeout 2025.10.29_01.10 and ChipFoundry 2026.03.30_01.00 native decks both return zero markers on counter, UART and APB with FEOL, BEOL and off-grid enabled.',
        'These decks share upstream provenance. Output-label changes from the older 2022 deck include renames and are not counted as new physical coverage.',
        'The Tiny Tapeout version reports zero contact-coverage markers for an uncovered mcon inside areaid:core (81:2); ChipFoundry and the existing Studio ct.4 predicate each report one.',
        'Outside core, both decks detect the uncovered contact; covered contact controls pass the coverage predicate with and without core.',
        'The new Studio regression covers absent, enclosing and crossing core markers, a one-nm uncovered strip, and fill that must not substitute for a drawn conductor.',
        'The first trial used the wrong marker (81:10); its assertion failed. Corrected v2 uses 81:2. Failed outputs are retained and excluded from accepted controls.',
        'The copied decks retain explicit GPLv3 file headers and the full license. No Apache root license is substituted, and no later-version grant is inferred.',
    ],
    inspected_not_incorporated=[
        dict(repository='TinyTapeout/tinytapeout-10',revision='46f0a2f45c3b1fcc27aac7acb7faa054631d9955',
             files={'sky130_tapeout_drc/fom_density.drc':'bfd903b4c9baaa5a6a06b41e95b7401dd280accb',
                    'sky130_tapeout_drc/met_density.lydrc':'39ec86ce3d7a0d156c3f4a0969b466126b056b2d',
                    'sky130_tapeout_drc/poly_density.drc':'cd67c94ff4aacd2635803a305b3234ac35b15a2f'},
             result='Public FOM/poly sources use raw draw/fill unions and the same exclusive endpoint-window counting pattern; whole-chip metal density uses seal geometry. No missing catalog mask equivalence or applicable acceptance contract is established. These three scripts were not executed or copied into the project.'),
        dict(repository='TinyTapeout/tt-support-tools',revision='01d5d2814fa9dd61e9d211e0b235a4a592a9316a',
             path='precheck/tech-files/nwell_urpm.drc',git_blob='a6e97c0b3e86878b1c23f19c98b12db946e588e6',
             result='Reviewed as a candidate; provenance README points to external Slack. Not incorporated or used to change rule dispositions in this batch.'),
    ],
    unchanged_checkpoint=dict(path='docs/validation/sky130-dummy-partners-2026-10-15.json',sha256=sha(repo/'docs/validation/sky130-dummy-partners-2026-10-15.json')),
    portable_evidence=dict(path=archive.relative_to(repo).as_posix(),sha256=sha(archive),bytes=archive.stat().st_size,
                          file_count=len(files),all_member_hashes_verified=True,
                          permanent_archive=str(permanent/'evidence.zip'),permanent_copy_sha256=sha(permanent/'evidence.zip')))
target=repo/'docs/validation/sky130-public-decks-2026-10-15.json'
target.write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps(dict(audit_sha256=sha(target),archive=report['portable_evidence'],native_runs=len(native['runs']),tests={p:d['tests'] for p,d in systems.items()}),indent=2))
