import hashlib
import json
import sys
import unittest
from pathlib import Path

root=Path(__file__).resolve().parents[1]
repo=root/'work/IC-Design-Studio'
sys.path.insert(0,str(repo))
out=root/'outputs/sky130-tt-precheck-review-v2'/sys.platform
out.mkdir(exist_ok=False)
suite=unittest.defaultTestLoader.loadTestsFromName('tests.test_sky130_interconnect_geometry')
with (out/'tests.log').open('w',encoding='utf-8',newline='\n') as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=dict(status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,
            failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
            platform=sys.platform,python=sys.version,driver_sha256=sha(__file__),
            log_sha256=sha(out/'tests.log'),sources={p:sha(repo/p) for p in (
                'tests/test_sky130_interconnect_geometry.py','scripts/sky130_interconnect_geometry.py',
                'scripts/review_sky130_public_decks.py','tests/fixtures/sky130-public-decks-v1/source-lock.json')})
(out/'tests.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record))
assert result.wasSuccessful() and result.testsRun==14 and not result.skipped
