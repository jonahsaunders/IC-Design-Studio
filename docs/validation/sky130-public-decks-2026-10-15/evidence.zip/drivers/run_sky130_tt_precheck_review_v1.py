"""Run unmodified public candidate decks and a missing-contact control."""
import hashlib
import json
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import klayout.db as k

root = Path(__file__).resolve().parents[1]
repo = root / 'work/IC-Design-Studio'
sys.path.insert(0, str(repo))
from scripts.sky130_interconnect_geometry import check

source = root / 'work/sky130-public-precheck-review-v1'
out = root / 'outputs/sky130-tt-precheck-review-v1'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
decks = {
    'tinytapeout': (source / 'tt-sky130A_mr.drc', '8bf71103d5f65eaf6283fe39a342c4163f59ca42aeb9b92d1e4f8ff4ebae3d09'),
    'chipfoundry': (source / 'cf-sky130A_mr.drc', 'aeba6ab5137923f2258714ab5d91ce99ca6a6f932bea55dedfe6f79aca697ba1'),
}
for path, digest in decks.values():
    assert sha(path) == digest
record = dict(schema=1, status='RUNNING', qualified=False, chunk_complete=False,
              new_coverage_decisions=0, driver_sha256=sha(__file__),
              engine=subprocess.check_output(['/opt/icstudio/bin/klayout', '-b', '-v'], text=True).strip(),
              engine_sha256=sha('/opt/icstudio/bin/klayout'), runs=[], controls=[])

def save():
    (out / 'record.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())

def run(label, gds, top, deck_name, flags):
    directory = out / label / deck_name
    directory.mkdir(parents=True)
    report = directory / 'report.lyrdb'
    command = ['/opt/icstudio/bin/klayout', '-b', '-r', str(decks[deck_name][0])]
    variables = dict(input=str(gds), top_cell=top, report=str(report), thr='1',
                     feol='false', beol='false', offgrid='false', seal='false',
                     floating_met='false', sram_exclude='false')
    variables.update(flags)
    for name, value in variables.items():
        command += ['-rd', f'{name}={value}']
    start = time.monotonic()
    result = subprocess.run(command, cwd=directory, capture_output=True, timeout=240)
    (directory / 'stdout.log').write_bytes(result.stdout)
    (directory / 'stderr.log').write_bytes(result.stderr)
    item = dict(label=label, deck=deck_name, gds_sha256=sha(gds), command=command,
                returncode=result.returncode, elapsed_seconds=round(time.monotonic()-start, 2),
                stdout_sha256=sha(directory / 'stdout.log'), stderr_sha256=sha(directory / 'stderr.log'))
    record['runs'].append(item)
    save()
    assert result.returncode == 0, result.stderr.decode(errors='replace')[-4000:]
    tree = ET.parse(report)
    counts = {}
    for marker in tree.findall('.//items/item'):
        category = marker.findtext('category')
        counts[category] = counts.get(category, 0) + 1
    item.update(markers=sum(counts.values()), categories=counts, report_sha256=sha(report))
    save()
    print(json.dumps(dict(label=label, deck=deck_name, markers=item['markers'], categories=counts)), flush=True)
    return counts

try:
    for case, top in [('counter','counter'), ('uart','uart_tx'), ('apb','apb_fifo')]:
        gds = root / 'outputs/sky130-application-boundary-v1/linux' / case / 'sky130-pin-export/final.gds'
        for deck in decks:
            run(case, gds, top, deck, dict(feol='true',beol='true',offgrid='true'))
    for core in (False, True):
        for covered in (False, True):
            name = f'mcon-core-{int(core)}-covered-{int(covered)}'
            layout = k.Layout()
            layout.dbu = 0.001
            cell = layout.create_cell('mcon_control')
            masks = {(67,44): k.Region(k.Box(0,0,170,170)),
                     (68,20): k.Region(k.Box(-200,-200,370,370))}
            if core:
                masks[(81,10)] = k.Region(k.Box(-1000,-1000,1000,1000))
            if covered:
                masks[(67,20)] = k.Region(k.Box(-200,-200,370,370))
            for layer, region in masks.items():
                cell.shapes(layout.layer(*layer)).insert(region)
            gds = out / (name + '.gds')
            layout.write(str(gds))
            studio = next(row['violations'] for row in check(masks)['checks'] if row['rule']=='ct.4')
            values = {}
            for deck in decks:
                counts = run(name, gds, cell.name, deck, dict(beol='true'))
                values[deck] = sum(value for key,value in counts.items() if 'MR_mcon.CON.10' in key)
            record['controls'].append(dict(name=name, core=core, covered=covered, studio_ct4=studio, native_mcon_coverage=values))
            assert (studio > 0) == (not covered)
            assert (values['chipfoundry'] > 0) == (not covered)
            assert (values['tinytapeout'] > 0) == (not covered and not core)
    record['status']='PASS'
    record['scope']='Successful execution/comparison only; native reference violations are retained. Not a full Tiny Tapeout precheck, foundry acceptance, or complete catalog coverage.'
finally:
    if record['status']=='RUNNING':
        record['status']='FAIL'
    save()
