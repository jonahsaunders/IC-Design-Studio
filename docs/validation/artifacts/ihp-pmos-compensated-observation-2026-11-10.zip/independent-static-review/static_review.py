import struct,json,re,hashlib
from pathlib import Path
R=Path(__file__).parent
class ELF:
 def __init__(self,v):
  self.b=(R/v/'psp103.osdi').read_bytes(); b=self.b; off=struct.unpack_from('<Q',b,40)[0]; es,n,si=struct.unpack_from('<HHH',b,58); self.sec=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*es) for i in range(n)]; st=self.sec[si]; names=b[st[4]:st[4]+st[5]];self.names=[names[s[0]:].split(b'\0')[0].decode() for s in self.sec];self.sy=[]
  for s in self.sec:
   if s[1]!=2:continue
   t=self.sec[s[6]];ss=b[t[4]:t[4]+t[5]]
   for i in range(s[4],s[4]+s[5],s[9]):
    no,info,other,idx,val,size=struct.unpack_from('<IBBHQQ',b,i);name=ss[no:].split(b'\0')[0].decode();self.sy.append((name,val,size,idx,info&15))
  self.func={n:(a,z) for n,a,z,i,t in self.sy if t==2 and z}
 def read(self,a,n):
  for s in self.sec:
   if s[3]<=a and a+n<=s[3]+s[5] and s[1]!=8:return self.b[s[4]+a-s[3]:s[4]+a-s[3]+n]
  raise ValueError(hex(a))
 def resolve(self,a):
  for n,v,z,i,t in self.sy:
   if z and v<=a<v+z:return (n,a-v)
  for n,s in zip(self.names,self.sec):
   if s[3]<=a<s[3]+s[5]:return (n,a-s[3])
  raise ValueError(hex(a))
 def funcs(self,v):
  text=(R/v/'disassembly.txt').read_text();out={}
  for m in re.finditer(r'^([0-9a-f]+) <([^>]+)>:\n(.*?)(?=\n\n|\Z)',text,re.M|re.S):
   name=m[2]
   if name not in self.func:continue
   a,z=self.func[name];rows=[]
   for line in m[3].splitlines():
    k=re.match(r'\s*([0-9a-f]+):[ ]*([^\t]*)\t(.*)',line)
    if not k:continue
    pc=int(k[1],16)
    if pc>=a+z:continue
    op=k[3];ref=None
    if '(%rip)' in op:
     q=re.search(r'(-?\d+)\(%rip\)',op);assert q,(name,line)
     ref=pc+len(bytes.fromhex(k[2]))+int(q[1]);op=re.sub(r'-?\d+\(%rip\)','TARGET(%rip)',op)
    op=op.split('#')[0].strip()
    if re.search(r'\b(?:j\w+|callq?)\s+0x',op):
     q=re.search(r'0x([0-9a-f]+) <([^>]+)>',op);assert q,op
     target=int(q[1],16)
     if a<=target<a+z:label=('self',target-a)
     elif '@plt' in q[2]:label=q[2]
     else:label=self.resolve(target)
     op=op[:q.start()]+str(label)
    rows.append((pc-a,op,ref))
   out['cb.1' if v=='on' and name=='cb.4' else name]=[(o,t.replace("('cb.4',","('cb.1',") if v=='on' else t,r) for o,t,r in rows]
  return out
p=ELF('pristine');c=ELF('on');a=p.funcs('pristine');b=c.funcs('on');report={};issues=[];refs=[]
for n in a:
 if n.startswith('load_spice_rhs'):continue
 if n not in b:issues.append((n,'missing'));continue
 if len(a[n])!=len(b[n]):issues.append((n,'length'));continue
 ok=True
 for x,y in zip(a[n],b[n]):
  if x[:2]!=y[:2]:issues.append((n,'instruction',x,y));ok=False;break
  if x[2] is not None:
   u,v=x[2],y[2];ru,rv=p.resolve(u),c.resolve(v)
   refs.append((n,hex(u),hex(v),ru,rv))
   if ru!=rv:
    # unnamed literal constant data: exact referenced 16-byte window
    width=8 if re.match(r'\w*sd\b',x[1]) else 4 if re.match(r'\w*ss\b',x[1]) else 16
    if p.read(u,width)!=c.read(v,width):issues.append((n,'reference',ru,rv,hex(u),hex(v)));ok=False;break
 report[n]=ok
print('functions',len(report),'issues',len(issues));print(issues[:12]);(R/'static-preliminary.json').write_text(json.dumps({'functions':report,'issues':issues,'references':refs},indent=2))
