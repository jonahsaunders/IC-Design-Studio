exec(open(__file__.replace('data_review.py','static_review.py')).read().split("p=ELF('pristine')")[0])
p=ELF('pristine');c=ELF('on')
def reloc(e):
 out={}
 for s in e.sec:
  if s[1]!=4:continue
  sym=e.sec[s[6]];st=e.sec[sym[6]];ss=e.b[st[4]:st[4]+st[5]]
  for i in range(s[4],s[4]+s[5],24):
   a,info,add=struct.unpack_from('<QQq',e.b,i);typ=info&0xffffffff;idx=info>>32
   if typ==8:
    target=e.resolve(add)
    for sn,sec in zip(e.names,e.sec):
     if sec[3]<=add<sec[3]+sec[5]:
      if sn=='.data.rel.ro':target=(sn,add-sec[3])
      if sn=='.rodata':
       oo=[(v,z) for _,v,z,j,t in e.sy if t==1 and z and v<=add<v+z]
       assert oo,hex(add)
       v,z=oo[0];target=('rodata_object_bytes',e.read(v,z).hex(),add-v)
    target=('cb.1',target[1]) if target[0]=='cb.4' else target
   else:
    no=struct.unpack_from('<I',e.b,sym[4]+idx*sym[9])[0];target=(ss[no:].split(b'\0')[0].decode(),add)
   out[a]=(typ,target)
 return out
rp,rc=reloc(p),reloc(c)
# Entire pointer-bearing descriptor/parameter/node metadata section.
def normalized(e,rs):
 s=e.sec[e.names.index('.data.rel.ro')];raw=bytearray(e.read(s[3],s[5]));rr={}
 for a,v in rs.items():
  if s[3]<=a<s[3]+s[5]:raw[a-s[3]:a-s[3]+8]=b'\0'*8;rr[a-s[3]]=v
 return bytes(raw),rr
ap,bp=normalized(p,rp);ac,bc=normalized(c,rc);print('metadata raw',ap==ac,'relocs',bp==bc,len(bp));print([(k,bp[k],bc.get(k)) for k in bp if bp[k]!=bc.get(k)][:10])
objs=[] # Generated local names are not stable identity; actual referenced bytes checked below.
# Exact actual RIP operands, including unnamed constants, GOT identities and jump tables.
a=p.funcs('pristine');b=c.funcs('on');issues=[];tables=[];count=0
for n in a:
 if n.startswith('load_spice_rhs'):continue
 for x,y in zip(a[n],b[n]):
  if x[2] is None:continue
  u,v=x[2],y[2];op=x[1];count+=1
  if u in rp:
   if rp[u]!=rc.get(v):issues.append((n,'reloc',rp[u],rc.get(v)))
   continue
  if op.startswith('leaq'):
   # Named string/table address: exact full object or jump table below.
   ru,rv=p.resolve(u),c.resolve(v)
   if n!='access_0':
    def string(e,addr):
     data=bytearray()
     for k in range(4096):
      x=e.read(addr+k,1);data+=x
      if x==b'\0':return bytes(data)
     raise ValueError('unbounded string')
    if string(p,u)!=string(c,v):issues.append((n,'address_bytes',ru,rv))
    continue
   # Anonymous relative jump table ends at next referenced table start or named symbol.
   targets=sorted({q[2] for rows in a.values() for q in rows if q[2] is not None and q[1].startswith('leaq') and q[2]>u} | {val for _,val,z,_,_ in p.sy if z and val>u})
   end=targets[0];size=end-u
   if u==0x86e6c:size=236*4 # actual access_0 cmp index <=235 before this table
   if size%4:issues.append((n,'unknown_table_extent',hex(u),size));continue
   print('table candidate',n,hex(u),hex(v),size)
   for j in range(0,size,4):
    pp=struct.unpack('<i',p.read(u+j,4))[0];cc=struct.unpack('<i',c.read(v+j,4))[0]
    if p.resolve(u+pp)!=c.resolve(v+cc):issues.append((n,'jump_table',j,p.resolve(u+pp),c.resolve(v+cc)));break
   tables.append((hex(u),hex(v),size));continue
  width=8 if re.match(r'\w*sd\b',op) else 4 if re.match(r'\w*ss\b',op) else 16
  if p.read(u,width)!=c.read(v,width):issues.append((n,'literal',hex(u),hex(v),op))
print('RIP',count,'tables',tables,'issues',issues[:12],len(issues))
(R/'data-review.json').write_text(json.dumps({'metadata_bytes_equal':ap==ac,'metadata_relocations_equal':bp==bc,'metadata_relocation_count':len(bp),'named_rodata_issues':objs,'rip_operand_count':count,'jump_tables':tables,'rip_issues':issues},indent=2))
