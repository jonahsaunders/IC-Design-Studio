from pathlib import Path
import json,hashlib,struct,sys,re,collections
from fractions import Fraction as F
R=Path(__file__).resolve().parent;sys.path.insert(0,'/workspace/shared/ihp-pmos-compensated-observation-plan');from parse_observer import parse
sys.path.insert(0,'/workspace/shared/ihp-psp-compensated-rhs-prototype');from kernel import two_product,add_component,supported
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();decode=lambda b:struct.unpack('>d',bytes.fromhex(b))[0]
def main():
 run=json.loads((R/'runs-v2/on/run.json').read_text());assert 'seconds' in run and run['post_identity_pass']
 logpath=R/'runs-v2/on/console.log';parsed=parse(logpath);rows=[]
 for r in parsed['records']:
  residual=decode(r['residual_bits']);pairs=[tuple(map(decode,p)) for p in r['pairs_bits']];lim=None if r['limiter_bits'] is None else decode(r['limiter_bits'])
  target=sum((F(j)*F(x) for j,x in pairs),F())-F(residual)+(F(lim) if lim is not None else F())
  row=dict(sequence=r['sequence'],kind=r['kind'],call_count=r['call_count'],status=r['status'],exact_cached_target=str(target),residual=residual,pairs=pairs)
  if r['status']==0:
   assert all(supported(v) for pair in pairs for v in pair) and supported(residual)
   expansion=[]
   for j,x in pairs:
    p,e=two_product(j,x);expansion=add_component(expansion,e);expansion=add_component(expansion,p)
   expansion=add_component(expansion,-residual)
   if lim is not None:assert supported(lim);expansion=add_component(expansion,lim)
   estimate=0.
   for v in expansion:estimate+=v
   actual=decode(r['result_bits']);assert actual.hex()==estimate.hex()
   n=len(expansion);u=F(1,2**53);bound=n*u/(1-n*u)*sum((abs(F(v)) for v in expansion),F());assert abs(F(actual)-target)<=bound
   row.update(actual=actual,actual_hex=actual.hex(),exact_error=str(abs(F(actual)-target)),bound=str(bound))
  rows.append(row)
 log=logpath.read_text();failures=[l for l in log.splitlines() if l.startswith('ICEQ first-node-failure')]
 result=dict(status='OBSERVED_HELPER_ENGAGEMENT_WITH_PERSISTING_GATE_CYCLE',qualified=False,run_sha256=sha(R/'runs-v2/on/run.json'),log_sha256=sha(logpath),timed_out=run['timed_out'],raw_complete=False,counts=dict(collections.Counter(str((r['kind'],r['status'])) for r in rows)),trace_bytes=parsed['trace_bytes'],first_failures=failures,exact_rows=rows,scope='Actual sampled externalG helper status and cached binary64 expression; no performance or general convergence claim; sparse later records do not establish unsampled behavior. Selected call1 late rows are directly adjacent to matching osdi/post-load markers; no extrapolated phase correlation.')
 (R/'readback.json').write_text(json.dumps(result,indent=2)+'\n');print(result['counts'],len(rows))
if __name__=='__main__':main()
