/* Deliberately integer/no-wait-only translation unit. Never use fast-math.
 * Build without strictfp attribute to prevent LLVM15 X86InsertWait treating
 * inline asm's implicit fpsr clobber as an x87 memory instruction.
 */
#include <float.h>
__attribute__((noinline)) int integer_guard(void) {
#if defined(__linux__) && defined(__x86_64__) && FLT_RADIX == 2 && DBL_MANT_DIG == 53 && DBL_MAX_EXP == 1024
 unsigned short control; unsigned csr;
 __asm__ volatile("fnstcw %0" : "=m"(control));
 __asm__ volatile("stmxcsr %0" : "=m"(csr));
 return (control & 0x0c3fu)==0x003fu &&
        (csr & (0x1f80u | (1u<<15) | (1u<<6) | (3u<<13)))==0x1f80u;
#else
 return 0;
#endif
}
