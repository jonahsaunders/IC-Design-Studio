"""Strict read-only diagnostic record parser; silence is never coverage proof."""
import re,struct
from pathlib import Path
HEX=re.compile(r'[0-9a-f]{16}')
def parse(path):
 data=Path(path).read_bytes();lines=data.splitlines(keepends=True);rows=[];total=0;last={};previous_sequence=0
 for line in lines:
  if not line.startswith(b'ICRHS'):continue
  assert line.endswith(b'\n'),'truncated observer record'
  tokens=line.decode('ascii').rstrip('\n').split(' ');assert tokens[0]=='ICRHS'
  assert all(HEX.fullmatch(t) for t in tokens[1:]),'invalid hex field'
  v=[int(t,16) for t in tokens[1:]];assert len(v)>=8
  seq,kind,row,count,n,status,lp,res=v[:8]
  assert kind in (0,1) and row==1 and 1<=n<=64 and status in range(6) and lp in (0,1)
  assert len(v)==8+lp+2*n+int(status==0),'wrong field count or rejected result present'
  assert seq>previous_sequence;previous_sequence=seq
  assert count>last.get(kind,0);last[kind]=count
  at=8;lim=v[at] if lp else None;at+=lp;pairs=[v[at+2*i:at+2*i+2] for i in range(n)]
  result=v[-1] if status==0 else None
  rows.append(dict(sequence=seq,kind=kind,row=row,call_count=count,status=status,residual_bits=f'{res:016x}',limiter_bits=None if lim is None else f'{lim:016x}',pairs_bits=[[f'{x:016x}' for x in pair] for pair in pairs],result_bits=None if result is None else f'{result:016x}'))
  total+=len(line)
 assert len(rows)<=512 and total<=262144
 return dict(records=rows,trace_bytes=total,coverage_from_silence=False,exact_engine_iteration_correlation=False)
