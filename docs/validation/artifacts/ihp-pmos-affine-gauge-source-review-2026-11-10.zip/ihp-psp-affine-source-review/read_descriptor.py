# Read-only ELF64 little-endian metadata decode; never load or execute the DSO.
import struct,json,hashlib
from pathlib import Path
p=Path('/workspace/shared/ihp-measured-runtime-v1/osdi/psp103.osdi');raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='24c016572d59fb079fda4f3a1c0aa4c8999d931e8ee335f180066f13ddd70ff4';assert raw[:6]==b'\x7fELF\x02\x01'
phoff=struct.unpack_from('<Q',raw,32)[0];ents,n=struct.unpack_from('<HH',raw,54);segments=[]
for i in range(n):
 t,flags,off,va,pa,fs,ms,align=struct.unpack_from('<IIQQQQQQ',raw,phoff+i*ents)
 if t==1:segments.append((va,off,fs))
def data(va,n):
 for start,off,size in segments:
  if start<=va and va+n<=start+size:return raw[off+va-start:off+va-start+n]
 raise ValueError(va)
def u64(va):return struct.unpack('<Q',data(va,8))[0]
def string(va):
 out=b''
 while data(va+len(out),1)!=b'\0':out+=data(va+len(out),1)
 return out.decode()
desc=0xa7dd0 # Independently read nm symbol OSDI_DESCRIPTORS; OSDI0.3 C header.
count,term=struct.unpack('<II',data(desc+8,8));nodes=u64(desc+16);mapping=struct.unpack('<I',data(desc+96,4))[0]
print('descriptor',string(u64(desc)),count,term,'nodes',hex(nodes))
rows=[]
for i in range(count):
 ptr=nodes+48*i;row=dict(index=i,name=string(u64(ptr)),resist_residual_off=struct.unpack('<I',data(ptr+24,4))[0],react_residual_off=struct.unpack('<I',data(ptr+28,4))[0],resist_limit_rhs_off=struct.unpack('<I',data(ptr+32,4))[0]);rows.append(row)
print(json.dumps(rows,indent=2))
Path(__file__).with_name('descriptor-readback.json').write_text(json.dumps(dict(module_sha256=hashlib.sha256(raw).hexdigest(),descriptor_symbol_address=hex(desc),node_mapping_offset=mapping,nodes=rows),indent=2)+'\n')
