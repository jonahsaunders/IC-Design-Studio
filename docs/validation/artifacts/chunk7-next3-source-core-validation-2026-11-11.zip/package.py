"""Package completed immutable local validation only; never run tests or native jobs."""
from pathlib import Path
import hashlib,json,re,zipfile
ROOT=Path('/workspace/shared');OUT=ROOT/'chunk7-next3-validation-package'
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(path):return json.loads(Path(path).read_bytes())
def require(ok,msg):
 if not ok:raise ValueError(msg)
def test_result(text):
 matches=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s\s*\n\s*OK(?: \(skipped=(\d+)\))?\s*$',text,re.M)
 require(bool(matches),'Missing successful unittest summary')
 return [(int(n),float(t),int(s or 0)) for n,t,s in matches]
def main():
 lanes={x:ROOT/f'chunk7-next3-{x}-20261111' for x in ('source','core')}
 reports={k:load(v/'launcher-report.json') for k,v in lanes.items()}
 # Must not package provisional/running evidence as a completed validation.
 for k,r in reports.items():require(r['status']=='passed' and r['returncode']==0,k+' not finalized passed')
 payload={};omitted=[];summary={};identities=[]
 for lane,root in lanes.items():
  r=reports[lane];snapshot=Path(r['cwd']);manifest=load(root/'snapshot-manifest.json');before=load(root/'source-before.json');after=load(root/'source-after.json');snapafter=load(root/'snapshot-after.json')
  require(before==after==snapafter,lane+' identity maps differ');require(len(before)==r['source_identity_count']==manifest['source_identity_count']==2492,'Identity count differs')
  require(r['source_unchanged'] and r['snapshot_unchanged'] and r['all_copied_files_unchanged'],'Launcher mutation')
  require(sha(root/'console.log')==r['console_sha256'],'Console hash differs')
  for n,h in before.items():require(sha(snapshot/n)==h,'Snapshot source changed '+n)
  for n,info in manifest['files'].items():
   if info=={'deleted':True}:
    require(not (snapshot/n).exists(),'Intentionally deleted path reappeared '+n);continue
   require(sha(snapshot/n)==info['sha256'] and (snapshot/n).stat().st_size==info['bytes'],'Copied snapshot changed '+n)
  identities.append(before)
  summary[lane]={'status':'passed','returncode':0,'process_elapsed_seconds':r['elapsed_seconds'],'source_identity_count':len(before),'copied_file_count':len(manifest['files']),'launcher_sha256':sha(root/'launcher-report.json')}
  for p in sorted(root.rglob('*')):
   require(not p.is_symlink(),'Linked evidence')
   if not p.is_file():continue
   rel=p.relative_to(root);name=lane+'/'+rel.as_posix()
   keep=len(rel.parts)==1 or (len(rel.parts)==2 and rel.parts[0]=='run' and p.suffix in ('.log','.json')) or p.name in ('report.json','files.json','inventory.json','readback.json')
   if keep:payload[name]=p.read_bytes()
   else:omitted.append({'path':name,'sha256':sha(p),'bytes':p.stat().st_size,'reason':'GUI project/layout/staging/raw payload omitted; original evidence remains local and report/inventory identities retained'})
 require(identities[0]==identities[1],'Source/core different tested identities')
 feedback=load(lanes['source']/'run/report.json');require(feedback['status']=='passed' and not feedback['release_acceptance'],'Feedback scope/status');require(feedback['source_files_sha256']==identities[0],'Feedback identities differ')
 require(len(feedback['stages'])==14 and len({x['name'] for x in feedback['stages']})==14 and all(x['returncode']==0 for x in feedback['stages']),'Stage set incomplete')
 unit=[]
 for stage in feedback['stages']:
  p=lanes['source']/'run'/(stage['name']+'.log');require(p.is_file(),'Missing stage log')
  if re.search(r'^Ran \d+ tests? in ',p.read_text(),re.M):unit+=test_result(p.read_text())
 summary['source'].update(stage_count=14,tests=sum(x[0] for x in unit),skips=sum(x[2] for x in unit),syntax_files=feedback['syntax_files'],feedback_elapsed_seconds=feedback['elapsed_seconds'])
 require(summary['source']['tests']==1814 and summary['source']['skips']==18 and feedback['syntax_files']==1611,'Unexpected source totals')
 core=test_result((lanes['core']/'console.log').read_text());require(len(core)==1,'Ambiguous core summary');summary['core'].update(tests=core[0][0],test_seconds=core[0][1],skips=core[0][2])
 # Independently join GUI inventory/report identities without replaying native code.
 for inventory in (lanes['source']/'run').rglob('files.json'):
  for name,value in load(inventory).items():
   path=inventory.parent/name
   require(path.resolve().is_relative_to(inventory.parent.resolve()) and sha(path)==value,'GUI inventory mismatch')
 guard=load(lanes['source']/'run/ihp-guard-corner-readback.json');guardroot=lanes['source']/'run/ihp-guard-corner'
 require(guard['status']=='PASS' and not guard['installed_acceptance'] and not guard['native_execution'],'Guard GUI scope')
 require(sha(guardroot/'report.json')==guard['report_sha256'] and sha(guardroot/'files.json')==guard['files_sha256'],'Guard readback identity')
 summary['source']['guard_gui']={key:guard[key] for key in ('gui_layouts','gui_controls','legacy_projects','installed_acceptance','native_execution')}
 # Retain app GUI reports without generated profiles/screenshots.
 gui=Path(reports['source']['cwd'])/'build'
 for folder in ('menu-audit','project-hub-evidence'):
  for p in sorted((gui/folder).glob('*.json')):payload['gui/'+folder+'/'+p.name]=p.read_bytes()
 # Historical setup failures and corrected focused results stay visible, not overwritten.
 for folder,names in [('ihp-pmos-v3-portable',['integrated-focused-tests.log','integrated-focused-tests-final.log']),('ihp-tap-linked-native',['focused-integration.log','focused-integration-2.log','next2-integrated-focused.log'])]:
  for name in names:
   p=ROOT/folder/name;require(p.is_file(),'Missing historical focused log');payload['historical-focused/'+folder+'/'+name]=p.read_bytes()
 payload['package.py']=Path(__file__).read_bytes()
 driver=ROOT/'ihp-windows-installed-triage/run-next-candidate-validation.py'
 payload['launcher-source/run-next-candidate-validation.py']=driver.read_bytes()
 manifest={'schema':1,'scope':'LOCAL_SOURCE_AND_CORE_VALIDATION_NOT_INSTALLED_ACCEPTANCE','standalone_replay':False,'source_snapshot_base_commit':reports['source']['base_commit'],'tested_identity_map_sha256':sha(lanes['source']/'source-before.json'),'included':{n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in payload.items()},'omitted':omitted,'limitations':['Compact validation record, not standalone GUI/native replay. Omitted GUI/project/layout/engine staging payloads are explicitly hashed; report and inventories are retained.','Launcher implementation is retained with a postrun hash only; original launch reports did not bind its prelaunch hash.',
'Tested snapshot contains uncommitted integrated changes atop named base; base commit alone does not identify tested content. Use included source and copied-file manifests.','Tests/skips are local evidence only. No installed acceptance, family qualification or calibration promotion.','Historical focused failures are retained as originally observed; final source/core results are separate.']}
 payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();archive=OUT/'chunk7-next3-source-core-validation-2026-11-11.zip';require(not archive.exists(),'Do not overwrite archive')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,b in sorted(payload.items()):z.writestr(name,b)
 with zipfile.ZipFile(archive) as z:
  require(z.testzip() is None and set(z.namelist())==set(payload),'Archive member mismatch')
  for n,b in payload.items():require(z.read(n)==b,'Archive payload changed')
 result={'schema':1,'status':'LOCAL_SOURCE_AND_CORE_PASS','installed_acceptance':False,'qualified':False,'calibrated':False,'lanes':summary,'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'manifest_sha256':hashlib.sha256(payload['MANIFEST.json']).hexdigest(),'included_files':len(payload),'omitted_files':len(omitted),'scope':manifest['limitations']}
 (OUT/'chunk7-next3-source-core-validation-2026-11-11.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
