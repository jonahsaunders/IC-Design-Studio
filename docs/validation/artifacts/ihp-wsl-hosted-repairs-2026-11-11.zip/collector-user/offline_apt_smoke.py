"""Ordinary-user offline APT update; empty sources, no downloads/install/system writes."""
from pathlib import Path
import os,json,subprocess,hashlib
root=Path('/workspace/shared/collector-user-fix-evidence/offline-apt');assert not root.exists() and os.getuid()>0;root.mkdir()
for name in ('lists/partial','cache/archives/partial','log','empty','downloads'):(root/name).mkdir(parents=True)
(root/'sources.sources').write_text('');(root/'empty.conf').write_text('')
config=''.join(f'Dir::{k} "{v}";\n' for k,v in {'Etc::sourcelist':root/'sources.sources','Etc::sourceparts':root/'empty','Etc::parts':root/'empty','Etc::main':root/'empty.conf','State::lists':root/'lists','Cache':root/'cache','Log':root/'log'}.items())
config+='Acquire::AllowInsecureRepositories "false";\nAcquire::AllowDowngradeToInsecureRepositories "false";\nAcquire::GzipIndexes "false";\nAPT::Architecture "amd64";\n'
(root/'apt.conf').write_text(config)
command=['/usr/bin/apt-get','update'];env={'PATH':'/usr/bin:/bin','HOME':str(root),'LANG':'C','LC_ALL':'C','APT_CONFIG':str(root/'apt.conf')}
r=subprocess.run(command,cwd=root/'downloads',env=env,capture_output=True,text=True,timeout=30)
(root/'stdout.log').write_text(r.stdout);(root/'stderr.log').write_text(r.stderr)
lock=root/'lists/lock';assert r.returncode==0,(r.stdout,r.stderr);assert lock.is_file() and lock.stat().st_uid==os.getuid();digest=hashlib.sha256(lock.read_bytes()).hexdigest()
receipt={'scope':'OFFLINE_NONROOT_APT_SOURCE_FEASIBILITY_NOT_DOCKER_OR_HOSTED_ACCEPTANCE','uid':os.getuid(),'gid':os.getgid(),'command':command,'returncode':r.returncode,'sources_empty':True,'network_sources':0,'packages_installed':False,'lock_uid':lock.stat().st_uid,'lock_mode':oct(lock.stat().st_mode&0o777),'lock_read_sha256':digest};(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
