import unittest
from scripts.prepare_ihp_wsl_research_projects import split_deck,LIB
DECK='''* fixture
.control
pre_osdi runtime/psp103.osdi
pre_osdi runtime/psp103_nqs.osdi
.endc
.lib "pdk/libs.tech/ngspice/models/cornerMOSlv.lib" mos_tt
.option reltol=1e-8 abstol=1e-16 vntol=1e-13
.option gminsteps=0 srcsteps=0
XDUT d g s b sg13_lv_pmos w=2u l=0.13u m=1
VD d 0 0
VG g 0 -0.5
VS s 0 0
VB b 0 0
.temp 27
.dc VD 0 -1.35 -0.05
.end
'''
class ProjectSourceTests(unittest.TestCase):
 def test_exact_statements_and_sources(self):
  sources,statements=split_deck(DECK);self.assertEqual(len(sources),4);self.assertEqual(statements[0],LIB);self.assertIn('XDUT d g s b sg13_lv_pmos w=2u l=0.13u m=1',statements)
 def test_control_injection(self):
  with self.assertRaisesRegex(ValueError,'Unexpected control'):split_deck(DECK.replace('pre_osdi runtime/psp103.osdi','shell bad'))
 def test_changed_sweep(self):
  with self.assertRaisesRegex(ValueError,'sweep'):split_deck(DECK.replace('-0.05','-0.01'))
 def test_changed_accuracy(self):
  with self.assertRaisesRegex(ValueError,'accuracy'):split_deck(DECK.replace('1e-8','1e-4'))
 def test_duplicate_dut(self):
  with self.assertRaisesRegex(ValueError,'DUT count'):split_deck(DECK+'XDUT d g s b duplicate\n')
 def test_missing_source(self):
  with self.assertRaisesRegex(ValueError,'Source count'):split_deck(DECK.replace('VB b 0 0\n',''))
