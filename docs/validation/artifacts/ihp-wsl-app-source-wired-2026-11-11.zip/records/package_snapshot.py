"""Local durable source/test snapshot only; no network or native execution."""
from pathlib import Path
import hashlib,json,zipfile
R=Path('/workspace/shared/ic-design-studio-wsl-app-rebuild');W=Path('/workspace/shared/ihp-wsl-app-reconstruction')
def h(b):return hashlib.sha256(b).hexdigest()
def main():
 payload={}
 names=['scripts/ihp_wsl_elf_symbols.py','tests/test_ihp_wsl_elf_symbols.py','tests/test_ihp_wsl_app_dispatch.py','scripts/prepare_ihp_wsl_app_contract.py','scripts/probe_ihp_wsl_research_app.py','scripts/audit_ihp_wsl_research_app.py','scripts/prepare_ihp_wsl_research_projects.py','scripts/prepare_ihp_wsl_research_payload.py','tests/test_ihp_wsl_app_reconstruction.py','tests/test_ihp_wsl_research_projects.py','docs/QUALIFICATION_PROGRESS.md']
 for n in names:payload['source/'+n]=(R/n).read_bytes()
 dependency=Path('/workspace/shared/ic-design-studio-wsl-rebuild/scripts/check_ihp_wsl_prepared.py');payload['dependency-source/check_ihp_wsl_prepared.py']=dependency.read_bytes()
 for p in W.iterdir():
  if p.is_file() and p.suffix in ('.md','.log','.json','.py') and p.name not in ('files.json','snapshot.json','snapshot-wired.json'):payload['records/'+p.name]=p.read_bytes()
 for name in ('ihp-wsl-app-reconstruction-tests-dispatch.log','ihp-wsl-app-reconstruction-tests-elf-final.log','ihp-wsl-app-reconstruction-tests-elf.log','ihp-wsl-app-reconstruction-tests.log','ihp-wsl-app-reconstruction-tests-final.log','ihp-wsl-app-reconstruction-projects.log'):
  p=W.parent/name;payload['records/'+name]=p.read_bytes()
 projects=W.parent/'ihp-wsl-app-reconstruction-projects'
 for p in projects.iterdir():
  if p.is_file():payload['source-only-generated-projects/'+p.name]=p.read_bytes()
 manifest=dict(schema=1,scope='POST_RESET_NEW_SOURCE_ONLY_NO_NATIVE_EXECUTION',base_commit='62c6930a820ee9c9ccb1040e38d1dd7394d9108e',qualified=False,installed_acceptance=False,standalone_native_replay=False,exact_historical_restoration=['source/scripts/prepare_ihp_wsl_research_projects.py'],new_reconstruction=[n for n in payload if n.startswith('source/') and n!='source/scripts/prepare_ihp_wsl_research_projects.py'],files={n:dict(bytes=len(b),sha256=h(b)) for n,b in payload.items()},omissions=['Original immutable PMOS v3 evidence is already published separately; this archive binds its manifest through source and test records, not native binaries.','Base application/PDK source is named base commit; new source files must overlay that reviewed base with independently reconstructed build-only dependencies.','Synthetic test receipt/raw copies were temporary and deleted; generator source and honest logs retained. No actual Windows/private WSL runtime result exists.'])
 payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
 archive=W/'app-source-reconstruction-wired.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(payload.items()):z.writestr(n,b)
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and set(z.namelist())==set(payload)
  for n,b in payload.items():assert z.read(n)==b
 for n in names:assert (R/n).read_bytes()==payload['source/'+n]
 result=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=h(archive.read_bytes()),payload_files=len(payload),scope=manifest['scope'])
 (W/'snapshot-wired.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
