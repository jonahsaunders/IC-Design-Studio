# Post-reset Windows Studio WSL app source reconstruction

Base: 62c6930. App contract/probe/auditor are new implementation, not restored
historical bytes or inherited approval. Only project preparer is exact historical
SHA256 48c67d260f3059f9f355ef9085c6744e59b0a10fba8a2eeb4e8ca33fa97ab24d.

Implemented source: prepared-host/payload/source-bound draft contract;
separate exact contract+runner authorization; actual Studio save/reopen/prepare/
start-job adapter with fixed 20 jobs/90 seconds and no retry/refinement; private
runtime identity and actual canonical engine loader closure pre/post, with static
ELF module-symbol joins (no DT_NEEDED is not a self-contained-module claim); retained failure,
cleanup and inventory receipts. Native approval flags remain false in drafts.

Audit source joins complete native input/host/artifact/module receipts, regenerated
full decks and translated original model closure, independent original device/
body/options/bias lines, ngspice47 raw titles, strict Sparse solver and exact known
m-hierarchy warning, all 560 grid points and 2,240 terminal comparisons, KCL,
source-aware multiplicity and 140 measured residuals. It composes the immutable
published-v3 reader; no measured-limit or calibration claim is introduced.

Validation is SOURCE ONLY: 37 focused tests, twenty regenerated cases, a synthetic
20-job receipt fixture using copied historical raw files, and four semantic
negative controls. A real Linux offscreen Studio save/reopen test passed with
native preparation/launch forbidden. Earlier environment/parser/normalization
failures are retained. No actual Windows/WSL native job ran.

Pending: independent source review and actual prepared host/payload, private
Windows distro/state-root/runtime lock identity, reviewed native contract and
separate authorization. The public run/CLI is wired through preflight, exact independent-review flags
and separate native authorization. Current drafts cannot execute. Dispatch and
audit each run once, and failures preserve the original native receipt. Native installed acceptance is untested.
No publication, default changes, new bounds, qualification or calibration.
Chunk 7 estimate unchanged: 74%, low confidence 55–82%, not acceptance fraction.

Static ELF symbol joining checks names/types only and does not interpret GNU
symbol-version tables. It is a source prerequisite, not proof of complete dynamic
loader compatibility; actual authorized Windows/WSL execution remains necessary.
