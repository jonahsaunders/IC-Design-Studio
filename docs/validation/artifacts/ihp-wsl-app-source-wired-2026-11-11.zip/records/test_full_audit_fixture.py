"""Synthetic receipt exercise only: copies retained raw, executes no simulator."""
from pathlib import Path
import sys,json,copy,tempfile,shutil
sys.path.insert(0,'/workspace/shared/ic-design-studio-wsl-app-rebuild')
from scripts import audit_ihp_wsl_research_app as a
from scripts.prepare_ihp_wsl_app_contract import sha,SELECTION
from scripts.read_ihp_pmos_measured_v3 import MANIFEST_SHA
from icstudio.model import load_project
E=Path('/workspace/shared/ihp-wsl-rebuild-evidence');V=E/'measured-v3';O=V/'attempt-1';P=Path('/workspace/shared/ihp-wsl-app-reconstruction-projects')
spec=json.loads((O/'contract.json').read_text());mods=[(p.name,sha(p)) for p in sorted((V/'osdi-inputs').glob('*.osdi'))]
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
with tempfile.TemporaryDirectory() as tmp:
 t=Path(tmp);out=t/'attempt';out.mkdir();runtime=dict(kind='wsl',sha256='a'*64,distro='FIXTURE-NOT-EXECUTED',root='FIXTURE')
 c=dict(source_files_sha256={'scripts/probe_ihp_wsl_research_app.py':'0'*64},runtime_full_identity={'fixture':True},host_dependencies={'/fixture':'not-native'},runtime_identity=runtime,payload_archive_sha256='a'*64,evidence_manifest_sha256=MANIFEST_SHA,projects_manifest_sha256=sha(P/'projects.json'),managed_modules=mods,project_files_sha256={x['case']:x['sha256'] for x in json.loads((P/'projects.json').read_text())['cases']})
 receipt=dict(qualified=False,installed_acceptance=False,status='EXECUTED_PENDING_INDEPENDENT_NATIVE_AUDIT',cleanup='no_owned_active_row',cleanup_errors=[],source_before=c['source_files_sha256'],source_after=c['source_files_sha256'],source_unchanged=True,runtime_identity=runtime,runtime_full_before=c['runtime_full_identity'],runtime_full_after=c['runtime_full_identity'],dependencies_before=c['host_dependencies'],dependencies_after=c['host_dependencies'],actual_dependency_closure_before={'dependencies':c['host_dependencies'],'rows':{}},actual_dependency_closure_after={'dependencies':c['host_dependencies'],'rows':{}},runs=[])
 for route,index in SELECTION:
  key=f'{route}-{index}';job=out/key;job.mkdir();saved=out/(key+'.icproj');shutil.copyfile(P/(key+'.icproj'),saved);project=load_project(saved)
  n=dict(project=copy.deepcopy(project),cell=project['top'],settings=copy.deepcopy(project['analysis']),executable='/opt/icstudio/bin/ngspice')
  entries=[dict(path='/opt/icstudio/osdi/ihp-sg13g2/'+name,sha256=h,system='Linux',machine='x86_64') for name,h in mods]
  n['project']['simulation_runtime']={'osdi':entries};directory='/var/tmp/icstudio-physical/'+'b'*32;n['project']['pdk']['package_root']=directory+'/pdk';n['settings']['managed_osdi']='ihp-sg13g2';n['settings']['tools']={n:'/opt/icstudio/bin/'+n for n in ('magic','netgen','ngspice','klayout')}
  deck,staged=a.regenerated_deck(n,project,O/'pdk',spec['model_files'],mods)
  for name,b in staged.items():q=job/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
  (job/'input.cir').write_text(deck)
  raw=(O/'runs'/key/'result.raw').read_text().splitlines();raw[0]='Title: '+deck.splitlines()[0];(job/'result.raw').write_text('\n'.join(raw)+'\n');shutil.copyfile(O/'runs'/key/'console.log',job/'engine.log')
  write(job/'runtime-lock.json',{'osdi':entries})
  for i,(name,h) in enumerate(mods):q=job/f'runtime-osdi/model-{i}.osdi';q.parent.mkdir(exist_ok=True);shutil.copyfile(V/'osdi-inputs'/name,q)
  artifacts={p.relative_to(job).as_posix():sha(p) for p in job.rglob('*') if p.is_file()};write(job/'physical-artifacts.json',artifacts);write(job/'physical-backend-input.json',n)
  meta=dict(runtime=runtime,native_directory=directory,native_input_sha256=sha(job/'physical-backend-input.json'));write(job/'physical-backend.json',meta);write(job/'physical-host-result.json',dict(managed_execution=dict(meta,received_files=artifacts)));write(job/'status.json',dict(status='complete',exit_code=0));write(job/'result.json',{})
  receipt['runs'].append(dict(route=route,gate_index=index,job_directory=str(job),saved_project=str(saved),saved_project_sha256=sha(saved),state='Complete'))
 c.update(review_state='REVIEWED_FOR_EXPLICIT_NATIVE_AUTHORIZATION',host_acceptance_pending=False,approved_managed_six_module_loading=True,native_adapter_ready=True)
 closures={'/opt/icstudio/research/ihp-pmos-v3/measured-v3/attempt-1/engine/runtime/ngspice'}|{'/opt/icstudio/osdi/ihp-sg13g2/'+n for n,h in mods}
 from scripts.ihp_wsl_elf_symbols import elf_symbols
 for key in ('actual_dependency_closure_before','actual_dependency_closure_after'):
  receipt[key]['rows']={n:{'libraries':c['host_dependencies'],'resolution':'ENGINE_LOADER_REPORTED'} for n in closures}
  for name,h in mods:
   symbols=elf_symbols(V/'osdi-inputs'/name)
   receipt[key]['rows']['/opt/icstudio/osdi/ihp-sg13g2/'+name].update(resolution='NO_DT_NEEDED_USES_AUTHENTICATED_ENGINE_SCOPE',symbol_resolution={'strong_undefined_count':len(symbols['undefined']),'weak_undefined':symbols['weak_undefined'],'needed':[],'scope':'STATIC_ENGINE_AND_AUTHENTICATED_DEPENDENCY_EXPORT_JOIN_NOT_SELF_CONTAINED'})
 receipt['files']={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()};rp=t/'attempt.launch.json';cp=t/'contract.json';write(cp,c);receipt.update(contract_sha256=sha(cp),runner_sha256='0'*64,authorization={'status':'AUTHORIZED_REVIEWED_WINDOWS_WSL_RESEARCH','contract_sha256':sha(cp),'runner_sha256':'0'*64});write(rp,receipt)
 result=a.audit_native(rp,cp,E,P)
 print(json.dumps({k:v for k,v in result.items() if k!='measured_residuals'},indent=2))
 tests=0
 def rejects(label):
  global tests
  try:a.audit_native(rp,cp,E,P)
  except (ValueError,KeyError):tests+=1;print('NEGATIVE PASS:',label)
  else:raise AssertionError('Accepted invalid '+label)
 base=copy.deepcopy(receipt)
 receipt['runs']=receipt['runs'][:-1];write(rp,receipt);rejects('missing twentieth job')
 receipt=copy.deepcopy(base);receipt['cleanup']='owned_process_still_present';write(rp,receipt);rejects('unknown cleanup')
 receipt=copy.deepcopy(base);receipt['actual_dependency_closure_before']['rows'].pop(next(iter(receipt['actual_dependency_closure_before']['rows'])));write(rp,receipt);rejects('missing module loader closure')
 receipt=copy.deepcopy(base);job=Path(receipt['runs'][0]['job_directory']);deck=(job/'input.cir').read_text();(job/'input.cir').write_text(deck.replace('XDUT d g s b','XDUT s g d b'))
 # Refresh transport hashes so this tests semantic deck checking, not only inventory.
 artifacts=json.loads((job/'physical-artifacts.json').read_text());artifacts['input.cir']=sha(job/'input.cir');write(job/'physical-artifacts.json',artifacts)
 host=json.loads((job/'physical-host-result.json').read_text());host['managed_execution']['received_files']=artifacts;write(job/'physical-host-result.json',host)
 receipt['files']={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()};write(rp,receipt);rejects('body/terminal deck mutation with recomputed hashes')
 print('SYNTHETIC SOURCE TEST ONLY; no native execution; negative controls',tests)
