"""Linux offscreen save/reopen only; no prepare/start-job/runtime execution."""
import sys,tempfile,os
from pathlib import Path
os.environ['QT_QPA_PLATFORM']='offscreen';sys.path.insert(0,'/workspace/shared/ic-design-studio-wsl-app-rebuild')
from PySide6.QtCore import QSettings,QStandardPaths
from PySide6.QtWidgets import QApplication
from unittest.mock import patch
from icstudio.gui import Studio
from icstudio.model import load_project
from scripts.probe_ihp_wsl_research_app import save_reopen_project
with tempfile.TemporaryDirectory() as root:
 root=Path(root);os.environ['HOME']=str(root);os.environ['XDG_CACHE_HOME']=str(root/'cache');os.environ['XDG_DATA_HOME']=str(root/'data');QStandardPaths.setTestModeEnabled(True);QSettings.setDefaultFormat(QSettings.IniFormat);QSettings.setPath(QSettings.IniFormat,QSettings.UserScope,str(root/'settings'))
 app=QApplication([]);app.setApplicationName('SourceWSLSaveReopenOnly');w=Studio(recover=False);w.jobs_dir=root/'jobs'
 try:
  p=load_project('/workspace/shared/ihp-wsl-app-reconstruction-projects/nominal-0.icproj');saved=root/'saved.icproj'
  with patch.object(w,'start_job',side_effect=AssertionError('No native jobs permitted')),patch.object(w,'prepare_simulation',side_effect=AssertionError('No runtime preparation permitted')):
   try:result=save_reopen_project(w,p,saved)
   except Exception:
    import json
    from icstudio.model import example
    print('ACTUAL_EMPTY',json.dumps(w.project,sort_keys=True));print('EXPECTED_EMPTY',json.dumps(example('empty'),sort_keys=True));print('PATH',w.path);raise
  assert result==w.project
  print('PASS actual Linux offscreen Studio save/reopen; no native preparation or launch')
 finally:
  with patch.object(w,'maybe_save',return_value=True):w.close()
  app.quit()
