/* Diagnostic only. No floating arithmetic, FP controls or model state writes.
 * One non-retried write per retained record; sequence gaps expose dropped writes.
 */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
static uint64_t sequence, counts[2][2], events, bytes;
static void hex(char **p,uint64_t v){static const char h[]="0123456789abcdef";for(int k=15;k>=0;k--)*(*p)++=h[(v>>(k*4))&15];}
static void word(char **p,uint64_t v){*(*p)++=' ';hex(p,v);}
static uint64_t bits(double v){uint64_t u;memcpy(&u,&v,8);return u;}
__attribute__((noinline)) void openvaf_rhs_observe(unsigned kind,unsigned row,
 const double*j,const double*x,unsigned n,double residual,int lp,double limiter,int status,const double*result){
 int saved_errno=errno;
 if(kind>1||(row!=1&&row!=5)||n>64||!n)goto done;
 if(sequence==UINT64_MAX||counts[kind][row==5]==UINT64_MAX)goto done;
 ++sequence;uint64_t count=++counts[kind][row==5];
 if(count>128)goto done;
 if(events>=512||bytes>=262144)goto done;
 char line[4096],*p=line;memcpy(p,"ICRHS",5);p+=5;
 word(&p,sequence);word(&p,kind);word(&p,row);word(&p,count);word(&p,n);word(&p,(unsigned)status);word(&p,(unsigned)lp);
 word(&p,bits(residual));if(lp)word(&p,bits(limiter));
 for(unsigned k=0;k<n;k++){word(&p,bits(j[k]));word(&p,bits(x[k]));}
 if(status==0)word(&p,bits(*result));
 *p++='\n';size_t len=(size_t)(p-line);if(bytes+len>262144)goto done;
 ++events;bytes+=len;(void)write(2,line,len);
 done:errno=saved_errno;
}
