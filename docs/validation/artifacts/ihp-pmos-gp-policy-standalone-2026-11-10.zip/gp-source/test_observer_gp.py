import tempfile,unittest
from pathlib import Path
from parse_observer_gp import parse

def line(seq,kind,row,count,n,status=0):
 v=[seq,kind,row,count,n,status,0,0]+[0]*(2*n)+([1] if status==0 else [])
 return 'ICRHS'+''.join(' %016x'%i for i in v)+'\n'
class Tests(unittest.TestCase):
 def read(self,text):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'log';p.write_text(text);return parse(p)
 def test_row_key(self):self.assertEqual(len(self.read(line(1,0,1,1,2)+line(2,0,5,1,5))['records']),2)
 def test_global_sequence(self):self.assertRaises(AssertionError,self.read,line(1,0,1,1,2)+line(1,0,5,1,5))
 def test_truncation(self):self.assertRaises(AssertionError,self.read,line(1,0,5,1,5).rstrip('\n'))
 def test_finalzero_no_result(self):self.assertIsNone(self.read(line(1,1,5,1,5,4))['records'][0]['result_bits'])
 def test_target_caps(self):
  text='';seq=0
  for kind in (0,1):
   for count in range(1,129):
    for row,n in [(1,2),(5,5)]:seq+=1;text+=line(seq,kind,row,count,n)
  r=self.read(text);self.assertEqual(len(r['records']),512);self.assertEqual(r['trace_bytes'],142336)
if __name__=='__main__':unittest.main()
