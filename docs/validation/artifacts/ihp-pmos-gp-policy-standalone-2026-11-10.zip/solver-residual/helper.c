#pragma STDC FENV_ACCESS ON
#pragma clang optimize off
/* Source-only experimental OSDI adapter kernel; compiled integration UNVERIFIED.
 * Exact-real expansion of supplied cached values, under documented bounds.
 * No correct-rounding, circuit convergence or signed-zero equivalence claim.
 */
#include <math.h>
#include <fenv.h>
#include <stddef.h>
#include <stdint.h>
#include <float.h>
#if defined(__x86_64__) || defined(__i386__)
#include <xmmintrin.h>
#endif
#define CAP 64
#define EMAX (2*CAP+2)
typedef struct { double expansion[EMAX]; double estimate; size_t count; } Result;
enum { ACCEPT=0, ENVIRONMENT=1, DOMAIN=2, OPTIONAL=3, ZERO_POLICY=4, LIMIT=5 };

/* Separate integer-only non-strictfp TU: LLVM15 strictfp inline asm may
 * insert FWAIT before rejection of pending unmasked x87 exceptions. */
extern int integer_guard(void);
static int environment_ok(void) { return integer_guard(); }
static int input_ok(double x) {
    return isfinite(x) && (x==0.0 ||
           (fabs(x)>=0x1p-200 && fabs(x)<=0x1p200));
}
static void two_sum(double a,double b,double *s,double *e) {
    double q=a+b;
    double bv=q-a;
    double av=q-bv;
    double br=b-bv;
    double ar=a-av;
    *s=q;*e=ar+br;
}
static size_t grow(double *expansion,size_t n,double b) {
    double out[EMAX];size_t m=0;double q=b;
    for(size_t k=0;k<n;k++) {
        double s,e;two_sum(q,expansion[k],&s,&e);q=s;
        if(e!=0.0)out[m++]=e;
    }
    if(q!=0.0)out[m++]=q;
    for(size_t k=0;k<m;k++)expansion[k]=out[k];
    return m;
}
int compensated_rhs(const double *j,const double *x,size_t n,
                    int residual_present,double residual,
                    int limiter_present,double limiter,Result *out) {
    /* On fallback no compensated estimate/expansion is returned. Caller must
     * invoke its ORIGINAL optional-term loader, not this kernel's approximation. */
    out->count=0;out->estimate=NAN;
    if(!environment_ok())return ENVIRONMENT;
    if(n>CAP)return LIMIT;
    /* Absence is never synthesized as +0. Empty rows also use original path. */
    if(n==0 || !residual_present)return OPTIONAL;
    if(!input_ok(residual)||(limiter_present && !input_ok(limiter)))return DOMAIN;
    for(size_t k=0;k<n;k++)if(!input_ok(j[k])||!input_ok(x[k]))return DOMAIN;
    double expansion[EMAX];size_t count=0;
    for(size_t k=0;k<n;k++) {
        double p=j[k]*x[k];
        /* Genuine libm fused operation; compiled -fno-builtin-fma.
         * fma error is exact within the reviewed lattice/range bounds. */
        double e=fma(j[k],x[k],-p);
        count=grow(expansion,count,e);
        count=grow(expansion,count,p);
    }
    count=grow(expansion,count,-residual);
    if(limiter_present)count=grow(expansion,count,limiter);
    double estimate=0.0;
    for(size_t k=0;k<count;k++)estimate+=expansion[k];
    /* Solver-residual-only: exact empty expansion returns positive zero.
     * Nonempty rounded-zero final result preserves original signed
     * zero semantics through fallback, not a claimed equivalent +0. */
    if(count==0) { out->count=0; out->estimate=0.0; return ACCEPT; }
    if(estimate==0.0)return ZERO_POLICY;
    if(!isfinite(estimate))return DOMAIN;
    for(size_t k=0;k<count;k++)out->expansion[k]=expansion[k];
    out->count=count;out->estimate=estimate;
    return ACCEPT;
}

/* Private strict scalar-output adapter: expansion remains internal. */
__attribute__((noinline,optnone))
int openvaf_experimental_compensated_rhs(const double *j,const double *x,
    unsigned n,double residual,int limiter_present,double limiter,double *value) {
    Result result;
    int status=compensated_rhs(j,x,n,1,residual,limiter_present,limiter,&result);
    if(status==0)*value=result.estimate;
    return status;
}
