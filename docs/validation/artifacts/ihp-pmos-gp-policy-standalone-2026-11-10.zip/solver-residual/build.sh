#!/bin/bash
set -euo pipefail
cd /workspace/shared/ihp-compensated-mna-residual
B=/workspace/shared/ihp-openvaf-baseline-toolchain/llvm-install-x86-aarch64/bin
$B/clang -emit-llvm -O0 -ffp-model=strict -ffp-contract=off -fno-builtin-fma -fno-inline -fPIC -target x86_64-unknown-linux-gnu -c shim.c -o strict.bc
$B/clang -emit-llvm -O2 -fno-fast-math -ffp-contract=off -fPIC -target x86_64-unknown-linux-gnu -c integer_guard.c -o guard.bc
$B/llvm-link strict.bc guard.bc -o linked.bc
$B/opt -O3 linked.bc -o optimized.bc
$B/llvm-dis optimized.bc -o optimized.ll
$B/clang -shared optimized.bc -fuse-ld=$B/ld.lld -lm -o libkernel.so
$B/llvm-objdump -d libkernel.so > disassembly.txt
$B/clang -O2 -fno-fast-math -ffp-contract=off probe.c -L. -lkernel -Wl,-rpath,/workspace/shared/ihp-compensated-mna-residual -o probe
$B/llvm-objdump -d probe > probe-disassembly.txt
ldd libkernel.so > dependencies.txt
python test_pending.py > pending-test.log 2>&1
