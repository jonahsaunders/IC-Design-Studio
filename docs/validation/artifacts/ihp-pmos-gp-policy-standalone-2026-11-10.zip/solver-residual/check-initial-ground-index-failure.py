from pathlib import Path
from fractions import Fraction as F
import ctypes as C,sys,json,hashlib,math,random
R=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/shared/ihp-pmos-gp-rhs-investigation')
from replay_sparse import replay
from analyze import parse,value,analyze
L=C.CDLL(str(R/'libkernel.so'))
class Result(C.Structure):_fields_=[('expansion',C.c_double*130),('estimate',C.c_double),('count',C.c_size_t)]
L.compensated_rhs.argtypes=[C.POINTER(C.c_double),C.POINTER(C.c_double),C.c_size_t,C.c_int,C.c_double,C.c_int,C.c_double,C.POINTER(Result)]
def residual(a,x,b):
 aa=(C.c_double*len(a))(*a);xx=(C.c_double*len(x))(*x);o=Result()
 status=L.compensated_rhs(aa,xx,len(a),1,b,0,0.,C.byref(o))
 return status,o
# Literal extraction of reviewed factor and solve loops, same separate binary64
# multiply/subtract order. No dynamic pivot/fill inference, and LU computed once.
def factor(c):
 n=c['n'];a={(ir,ic):float(value(bits)) for ir,ic,er,ec,bits in c['entries']}
 columns={j:[ir for ir,ic,er,ec,bits in c['entries'] if ic==j] for j in range(1,n+1)}
 assert all(v==sorted(set(v)) for v in columns.values())
 assert all((i,i) in a for i in range(1,n+1))
 a[1,1]=1./a[1,1]
 for step in range(2,n+1):
  for row in columns[step]:
   if row>=step:break
   a[row,step]=a[row,step]*a[row,row];multiplier=a[row,step]
   for lower in columns[row]:
    if lower<=row:continue
    assert (lower,step) in a
    a[lower,step]=a[lower,step]-multiplier*a[lower,row]
  assert a[step,step]!=0;a[step,step]=1./a[step,step]
 return a,columns

def solve(c,lu,rhs):
 a,columns=lu;n=c['n'];x={i:float(rhs[c['maps'][i][0]]) for i in range(1,n+1)}
 for i in range(1,n+1):
  temp=x[i]
  if temp!=0:
   temp=temp*a[i,i];x[i]=temp
   for row in columns[i]:
    if row>i:x[row]=x[row]-temp*a[row,i]
 for i in range(n,0,-1):
  temp=x[i]
  for col in range(i+1,n+1):
   if (i,col) in a:temp=temp-a[i,col]*x[col]
  x[i]=temp
 return {c['maps'][i][1]:v for i,v in x.items()}

def check_row(a,x,b):
 status,o=residual(a,x,b);assert status==0
 target=sum((F(j)*F(v) for j,v in zip(a,x)),F())-F(b)
 e=list(o.expansion[:o.count]);assert sum(map(F,e),F())==target
 if not e:assert target==0 and o.estimate.hex()=='0x0.0p+0'
 else:assert o.estimate!=0
 u=F(1,2**53);bound=o.count*u/(1-o.count*u)*sum((abs(F(v)) for v in e),F())
 assert abs(F(o.estimate)-target)<=bound
 return o.estimate,target,bound

checks=0
for a,x,b in [([1.],[1.],1.),([-0.],[1.],-0.),([1.,-1.],[2.,2.],0.),([2.**200,2.**-200],[2.**200,2.**-200],0.)]:check_row(a,x,b);checks+=1
rng=random.Random(734)
for _ in range(500):
 n=rng.randrange(1,65);a=[rng.choice([-0.,0.,rng.uniform(-2,2)]) for _ in range(n)];x=[rng.choice([-0.,0.,rng.uniform(-2,2)]) for _ in range(n)];check_row(a,x,rng.choice([-0.,0.,rng.uniform(-2,2)]));checks+=1
for bad in [math.nan,math.inf,-math.inf,5e-324,2.**-201,2.**201]:assert residual([bad],[1.],0.)[0]==2
assert residual([1.]*65,[1.]*65,0.)[0]==5
assert residual([],[],0.)[0]==3
log=Path('/workspace/shared/ihp-pmos-mna-capture/capture-run/on/console.log');reports=[]
for c in parse(log):
 lu=factor(c);ids=sorted(c['vectors']);native=solve(c,lu,{i:c['vectors'][i][0] for i in ids});expected=replay(c)
 assert all(native[i].hex()==expected[i].hex()==float(c['vectors'][i][2]).hex() for i in ids)
 entries={(er,ec):float(value(bits)) for ir,ic,er,ec,bits in c['entries']};correction_rhs={};rows=[]
 exact={r['external_id']:F(r['exact_solution']) for r in analyze(c)['rows']}
 for i in ids:
  cols=sorted(j for er,j in entries if er==i)
  actual,target,bound=check_row([entries[i,j] for j in cols],[native[j] for j in cols],float(c['vectors'][i][0]))
  correction_rhs[i]=-actual
  rows.append({'id':i,'name':c['node_names'][i][0],'native_residual_Ax_minus_b':actual.hex(),'exact_residual':str(target),'error_bound':str(bound),'native_residual_error':str(F(actual)-target)})
 before=dict(lu[0]);delta=solve(c,lu,correction_rhs);assert lu[0]==before
 for row in rows:
  i=row['id'];refined=native[i]+delta[i];row.update(native=native[i].hex(),delta=delta[i].hex(),refined=refined.hex(),nearest_exact=float(exact[i]).hex(),nearest_exact_match=refined.hex()==float(exact[i]).hex(),refined_error=str(F(refined)-exact[i]))
 reports.append({'iteration':c['iteration'],'rows':rows,'all_nearest_exact':all(r['nearest_exact_match'] for r in rows)})
result={'status':'OFFLINE_NATIVE_RESIDUAL_ONE_CORRECTION','standalone_fraction_rows':checks,'captured_native_rows':sum(len(r['rows']) for r in reports),'reports':reports,'limits':['Native strict residual only; factor/solve is reviewed-order binary64 Python replay, not native engine integration.','Same computed LU reused once per captured matrix; actual runtime factor bytes were not captured.','Different assembled matrices remain different; no assembly cure or PMOS convergence claim.']}
(R/'result.json').write_text(json.dumps(result,indent=2)+'\n')
for r in reports:print(r['iteration'],[(x['name'],x['refined'],x['nearest_exact'],x['nearest_exact_match']) for x in r['rows'] if x['name'] in ('vg#branch','n.xdut.nsg13_lv_pmos#GP')])
