"""Offline counterfactual on two observed systems; no native kernel/model change."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,struct,copy
sys.path.insert(0,'/workspace/shared/ihp-pmos-mna-capture');from analyze import parse,value,analyze
sys.path.insert(0,'/workspace/shared/ihp-pmos-gp-rhs-investigation');from replay_sparse import replay
from parse_observer_gp import parse as traceparse
sys.path.insert(0,'/workspace/shared/ihp-psp-compensated-rhs-prototype');from kernel import two_product,add_component
R=Path(__file__).resolve().parent;f=lambda h:struct.unpack('>d',bytes.fromhex(h))[0]
def main():
 log=R/'runs/on/console.log';systems=parse(log);trace=traceparse(log)['records'];out=[]
 for original in systems:
  rec=next(r for r in trace if r['kind']==0 and r['row']==5 and r['call_count']==original['iteration']);assert rec['status']==4
  expansion=[];exact=F()
  for jbits,xbits in rec['pairs_bits']:
   j,x=f(jbits),f(xbits);p,e=two_product(j,x);expansion=add_component(expansion,e);expansion=add_component(expansion,p);exact+=F(j)*F(x)
  residual=f(rec['residual_bits']);assert rec['limiter_bits'] is None;expansion=add_component(expansion,-residual);exact-=F(residual)
  estimate=0.
  for v in expansion:estimate+=v
  assert estimate!=0
  c=copy.deepcopy(original);gp=next(i for i,n in c['node_names'].items() if n[0]=='n.xdut.nsg13_lv_pmos#GP');oldb,old,x=c['vectors'][gp];c['vectors'][gp]=(F(estimate),old,x)
  raw=replay(c);A={(er,ec):value(bits) for ir,ic,er,ec,bits in c['entries']};ids=sorted(raw)
  correction=copy.deepcopy(c)
  for i in ids:
   residual=c['vectors'][i][0]-sum((A.get((i,j),F())*F(raw[j]) for j in ids),F());_,old,x=correction['vectors'][i];correction['vectors'][i]=(F(float(residual)),old,x)
  delta=replay(correction);refined={i:raw[i]+delta[i] for i in ids};exactsolve=analyze(c)
  out.append(dict(iteration=c['iteration'],original_gp_rhs=str(oldb),candidate_gp_rhs=estimate.hex(),exact_cached_target=str(exact),candidate_error=str(F(estimate)-exact),rows=[dict(name=row['node_name'],raw_candidate_solution=raw[row['external_id']].hex(),refined_candidate_solution=refined[row['external_id']].hex(),nearest_exact=row['nearest_exact_hex']) for row in exactsolve['rows']]))
 (R/'offline-combination.json').write_text(json.dumps(dict(status='OFFLINE_COUNTERFACTUAL_ONLY',reports=out,limitations=['Replaces only captured externalGP RHS with reviewed-style expansion estimate allowing negativezero products and requiring nonzero finalresult','Does not prove future native trace/circuit convergence','Refinement residual is exactFraction oracle, not native implementation']),indent=2)+'\n')
 print([(r['iteration'],[(x['name'],x['raw_candidate_solution'],x['refined_candidate_solution']) for x in r['rows'] if x['name'] in ['vg#branch','n.xdut.nsg13_lv_pmos#GP']]) for r in out])
if __name__=='__main__':main()
