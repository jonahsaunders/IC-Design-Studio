from pathlib import Path
import struct,math,json,hashlib,sys,collections
from fractions import Fraction as F
sys.path.insert(0,'/workspace/shared/ihp-pmos-gp-rhs-investigation')
from parse_observer_gp import parse
R=Path(__file__).resolve().parent
flt=lambda b:struct.unpack('>d',bytes.fromhex(b))[0]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 run=json.loads((R/'runs/on/run.json').read_text());assert run['post_identity_pass'] and 'seconds' in run
 path=R/'runs/on/console.log';rows=parse(path)['records'];selected=[]
 for r in rows:
  if r['row']!=5 or r['kind']!=0 or r['call_count'] not in [99,100]:continue
  pairs=[tuple(map(flt,p)) for p in r['pairs_bits']];res=flt(r['residual_bits']);lim=None if r['limiter_bits'] is None else flt(r['limiter_bits']);target=sum((F(j)*F(x) for j,x in pairs),F())-F(res)+(F(lim) if lim is not None else F())
  zero_products=[i for i,(j,x) in enumerate(pairs) if j*x==0 and math.copysign(1,j*x)<0]
  values=[res,*[v for pair in pairs for v in pair]]+([] if lim is None else [lim]);invalid=[i for i,v in enumerate(values) if not math.isfinite(v) or (v==0 and math.copysign(1,v)<0) or (v!=0 and not 2**-200<=abs(v)<=2**200)]
  selected.append(dict(record=r,pairs=pairs,residual=res,exact_cached_target=str(target),exact_target_float=float(target),negative_zero_product_indices=zero_products,invalid_input_indices=invalid,interpretation='ZERO_POLICY due negativezero product established only when status4, inputvalid and nonempty indices; no model law changed'))
 assert len(selected)==2
 result=dict(status='ACTUAL_GP_STATUS_READBACK',run_sha256=sha(R/'runs/on/run.json'),log_sha256=sha(path),counts=dict(collections.Counter(str((r['kind'],r['row'],r['status'])) for r in rows)),selected=selected,qualified=False)
 (R/'readback.json').write_text(json.dumps(result,indent=2)+'\n');print(result['counts'])
if __name__=='__main__':main()
