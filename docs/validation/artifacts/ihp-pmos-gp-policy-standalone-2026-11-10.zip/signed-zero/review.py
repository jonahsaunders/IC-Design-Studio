from pathlib import Path
from fractions import Fraction as F
import hashlib,itertools,json,math,random,sys
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/workspace/shared/ihp-psp-compensated-compiler-prototype-v2/openvaf/osdi/compensated_rhs.c')
sys.path.insert(0,'/workspace/shared/ihp-psp-compensated-rhs-prototype')
from kernel import two_product,add_component

def evaluate(js,xs,r,lim=None,relaxed=True):
 if len(js)>64:return 'LIMIT',(),None
 if not js or r is None:return 'OPTIONAL',(),None
 values=js+xs+[r]+([] if lim is None else [lim])
 def valid(x):return math.isfinite(x) and (x==0 and (relaxed or math.copysign(1,x)>0) or 2**-200<=abs(x)<=2**200)
 if not all(valid(x) for x in values):return 'DOMAIN',(),None
 e=[]
 for a,b in zip(js,xs):
  p,err=two_product(a,b)
  if not relaxed and p==0 and math.copysign(1,p)<0:return 'ZERO_POLICY',(),None
  e=add_component(e,err);e=add_component(e,p)
 e=add_component(e,-r)
 if lim is not None:e=add_component(e,lim)
 estimate=0.
 for x in e:estimate+=x
 if not e or estimate==0:return 'ZERO_POLICY',(),None
 if not math.isfinite(estimate):return 'DOMAIN',(),None
 return 'ACCEPT',tuple(e),estimate

def check(js,xs,r,lim):
 status,e,value=evaluate(js,xs,r,lim)
 exact=sum((F(a)*F(b) for a,b in zip(js,xs)),F())-F(r)+(F(lim) if lim is not None else 0)
 if status=='ACCEPT':
  assert value!=0 and math.isfinite(value)
  assert sum(map(F,e),F())==exact
  n=len(e);u=F(1,2**53);bound=n*u/(1-n*u)*sum(map(lambda x:abs(F(x)),e),F())
  assert abs(F(value)-exact)<=bound
 else:assert status=='ZERO_POLICY' and exact==0
 # Canonicalizing the signs of input zeros must leave accepted expansion and
 # estimate bits identical; exact/rounded-zero rows remain delegated.
 clean=lambda seq:[0. if v==0 else v for v in seq]
 canonical=evaluate(clean(js),clean(xs),0. if r==0 else r,None if lim is None else 0. if lim==0 else lim)
 assert status==canonical[0]
 if status=='ACCEPT':assert [x.hex() for x in e]+[value.hex()]==[x.hex() for x in canonical[1]]+[canonical[2].hex()]
 old=evaluate(js,xs,r,lim,False)
 if old[0]=='ACCEPT':assert old==(status,e,value)
 return status

def main():
 source=SOURCE.read_text();candidate=source.replace('(x==0.0 && !signbit(x))','x==0.0').replace('        if(p==0.0 && signbit(p))return ZERO_POLICY;\n','')
 assert candidate!=source
 (ROOT/'compensated_rhs_candidate.c').write_text(candidate)
 values=[-0.,0.,-1.,1.,-2.,2.];counts={};total=0
 for a,b,r,l in itertools.product(values,repeat=4):
  # Include a guaranteed nonzero contribution and exact cancellations too.
  for js,xs in [([a],[b]),([a,1.],[b,2.]),([a,1.,-1.],[b,2.,2.])]:
   status=check(js,xs,r,l);counts[status]=counts.get(status,0)+1;total+=1
 rng=random.Random(733)
 for _ in range(500):
  n=rng.randrange(1,65);js=[];xs=[]
  for i in range(n):
   def value():return rng.choice([-0.,0.]) if rng.random()<.35 else math.ldexp(rng.uniform(1,1.999999),rng.randrange(-199,200))*rng.choice([-1,1])
   js.append(value());xs.append(value())
  r=rng.choice([-0.,0.,1.,-1.]);lim=rng.choice([None,-0.,0.,1.])
  status=check(js,xs,r,lim);counts[status]=counts.get(status,0)+1;total+=1
 for bad in [float('nan'),float('inf'),-float('inf'),2**-201,2**201,5e-324]:assert evaluate([bad],[1.],0.)[0]=='DOMAIN'
 assert evaluate([],[],0.)[0]=='OPTIONAL'
 assert evaluate([1.],[1.],None)[0]=='OPTIONAL'
 assert evaluate([1.]*65,[1.]*65,0.)[0]=='LIMIT'
 for lim in [None,0.,-0.]:assert evaluate([-0.,1.],[1.,1.],1.,lim)[0]=='ZERO_POLICY'
 sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
 result={'status':'PASS_REFERENCE_ARITHMETIC_ONLY','rows':total,'counts':counts,'source_sha256':sha(SOURCE),'candidate_sha256':sha(ROOT/'compensated_rhs_candidate.c'),'reference_kernel_sha256':sha('/workspace/shared/ihp-psp-compensated-rhs-prototype/kernel.py'),'script_sha256':sha(__file__),'conclusion':'Signed zero inputs/products represent exact-real zero. Under unchanged bounded finite RN nonFTZ environment, discarding zero expansion components loses no real contribution; nonzero accepted expansion/estimate identical to canonical positive-zero inputs. Final zero fallback remains mandatory.','limits':['Python Fraction FMA oracle, not native candidate codegen validation.','No PSP callback or circuit executed; no proof GP actually rejects for signed zero and no cure claim.','No generic signed-zero/exception-flag equivalence to original fast-math loader; final zero stays original fallback.','Guard, optional terms, row cap, physical residual/Jacobian/ABI unchanged. Existing strict compiler/helper callchain and full environment tests must be repeated before integration.']}
 (ROOT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
