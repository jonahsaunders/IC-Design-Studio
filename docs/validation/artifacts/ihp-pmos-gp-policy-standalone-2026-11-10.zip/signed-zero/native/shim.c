#include "helper.c"
/* Standalone test controls only, not intended production API. */
int test_getround(void){return fegetround();}
int test_setround(int x){return fesetround(x);}
int test_upward(void){return FE_UPWARD;}
int test_downward(void){return FE_DOWNWARD;}
int test_towardzero(void){return FE_TOWARDZERO;}
unsigned test_getcsr(void){
#if defined(__x86_64__)
return _mm_getcsr();
#else
return 0;
#endif
}
void test_setcsr(unsigned x){
#if defined(__x86_64__)
_mm_setcsr(x);
#else
(void)x;
#endif
}

/* Guard-only probes: no arithmetic while exceptions are unmasked. Preserve
 * x87 control/MXCSR exactly; no pending exception state is cleared/changed.
 * fnstcw/fldcw and stmxcsr/ldmxcsr are non-waiting state operations. */
int test_unmasked_guard(unsigned unit,unsigned exception) {
#if defined(__linux__) && defined(__x86_64__)
    if(exception>=6)return -1;
    unsigned oldcsr=_mm_getcsr();unsigned short oldcw;
    __asm__ volatile ("fnstcw %0" : "=m" (oldcw));
    int accepted;
    if(unit==0) {
        unsigned short changed=(unsigned short)(oldcw & ~(1u<<exception));
        __asm__ volatile ("fldcw %0" : : "m" (changed));
        accepted=environment_ok();
        __asm__ volatile ("fldcw %0" : : "m" (oldcw));
    } else if(unit==1) {
        _mm_setcsr(oldcsr & ~(1u<<(exception+7)));
        accepted=environment_ok();
        _mm_setcsr(oldcsr);
    } else return -1;
    unsigned short restored;
    __asm__ volatile ("fnstcw %0" : "=m" (restored));
    return accepted || restored!=oldcw || _mm_getcsr()!=oldcsr;
#else
    return -1;
#endif
}
