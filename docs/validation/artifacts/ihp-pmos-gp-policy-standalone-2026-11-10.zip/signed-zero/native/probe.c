#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int openvaf_experimental_compensated_rhs(const double*,const double*,unsigned,double,int,double,double*);
int main(int argc,char **argv) {
 if(argc!=4)return 64;
 int which=atoi(argv[1]),kind=atoi(argv[2]),bit=atoi(argv[3]);
 unsigned short original,cw,status=0,aftercw,afterstatus;unsigned csr,originalcsr,aftercsr;
 __asm__ volatile("fnstcw %0\n\tstmxcsr %1":"=m"(original),"=m"(originalcsr));
 __asm__ volatile("fninit");
 cw=0x037f;csr=0x1f80;
 if(kind==1)cw &= (unsigned short)~(1u<<bit);
 if(kind==2)csr &= ~(1u<<(bit+7));
 if(kind==3)cw |= (unsigned short)(bit<<10);
 if(kind==4)csr |= (unsigned)(bit<<13);
 if(kind==5)csr |= 1u<<bit;
 __asm__ volatile("fldcw %0\n\tldmxcsr %1"::"m"(cw),"m"(csr));
 if(kind==6 || kind==7) {
  /* Real masked invalid operation:0/0; no invented environment layouts. */
  __asm__ volatile("fldz\n\tfldz\n\tfdivp %%st, %%st(1)\n\tfnstsw %0":"=m"(status)::"st");
  if(!(status&1))return 65;
  if(kind==6){cw &= (unsigned short)~1u;__asm__ volatile("fldcw %0"::"m"(cw));}
 }
 double j[1]={1.0},x[1]={2.0},out=123.25;
 int result=openvaf_experimental_compensated_rhs(j,x,1,0.0,0,0.0,&out);
 int accepted=(result==0);
 __asm__ volatile("fnstcw %0\n\tfnstsw %1\n\tstmxcsr %2":"=m"(aftercw),"=m"(afterstatus),"=m"(aftercsr));
 /* Clear pending status using no-wait opcode BEFORE restoring/logging. */
 __asm__ volatile("fnclex\n\tfninit\n\tfldcw %0\n\tldmxcsr %1"::"m"(original),"m"(originalcsr));
 printf("accepted=%d pending_before=%u status_after=%u control_after=%u csr_after=%u\n",accepted,status,afterstatus,aftercw,aftercsr);
 return (aftercw==cw && aftercsr==csr && (accepted ? out==2.0 : out==123.25))?0:66;
}
