import ctypes as C, unittest, math
from test_native import L, run
L.openvaf_experimental_compensated_rhs.argtypes=[C.POINTER(C.c_double),C.POINTER(C.c_double),C.c_uint,C.c_double,C.c_int,C.c_double,C.POINTER(C.c_double)]
L.openvaf_experimental_compensated_rhs.restype=C.c_int
class Wrapper(unittest.TestCase):
 def test_scalar_wrapper_matches_full_kernel_and_no_write_fallback(self):
  cases=[([.1,-2.3],[.7,1.9],.2,0,math.nan),([100.966166859,-100.966166859],[-1.124,-1.1239999999412742],100.966166859*(-1.124+1.1239999999412742),0,0.),([1.],[1.],1.,1,2.**-200),([1.],[1.],1.,0,0.),([-0.],[1.],0.,0,0.),([2.**201],[1.],0.,0,0.),([],[],0.,0,0.),([1.]*65,[1.]*65,0.,0,0.)]
  for j,x,r,lp,l in cases:
   a=(C.c_double*len(j))(*j); b=(C.c_double*len(x))(*x); out=C.c_double(123.25)
   s=L.openvaf_experimental_compensated_rhs(a,b,len(j),r,lp,l,C.byref(out)); expected,full=run(j,x,r,l,lp=lp)
   self.assertEqual(s,expected)
   self.assertEqual(out.value,full.estimate if s==0 else 123.25)
 def test_rejected_environment_preserves_output(self):
  old=L.test_getcsr();a=(C.c_double*1)(1.);b=(C.c_double*1)(2.);out=C.c_double(123.25)
  try:
   L.test_setcsr(old|(1<<15));s=L.openvaf_experimental_compensated_rhs(a,b,1,0.,0,math.nan,C.byref(out));self.assertEqual(s,1);self.assertEqual(out.value,123.25)
  finally:L.test_setcsr(old)
if __name__=='__main__':unittest.main()
