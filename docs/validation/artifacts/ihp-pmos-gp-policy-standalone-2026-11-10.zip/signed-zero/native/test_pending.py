from pathlib import Path
import subprocess,json,signal
r=Path(__file__).parent;rows=[]
for which in [2]:
 for kind,bit in [(0,0)]+[(1,i) for i in range(6)]+[(2,i) for i in range(6)]+[(3,i) for i in range(1,4)]+[(4,i) for i in range(1,4)]+[(5,6),(5,15),(6,0),(7,0)]:
  p=subprocess.run([str(r/'probe'),str(which),str(kind),str(bit)],capture_output=True,text=True,timeout=5)
  expected_signal=kind==6 and which in (0,1)
  if expected_signal:assert p.returncode==-signal.SIGFPE,(which,kind,bit,p.returncode,p.stdout,p.stderr)
  else:
   assert p.returncode==0,(which,kind,bit,p.returncode,p.stdout,p.stderr)
   expected=1 if kind in (0,7) else 0
   assert p.stdout.startswith('accepted='+str(expected)+' '),(which,kind,bit,p.stdout)
   if kind in (6,7):
    assert int(p.stdout.split('pending_before=')[1].split()[0])&1
    assert int(p.stdout.split('status_after=')[1].split()[0])&1
  rows.append({'guard':which,'kind':kind,'bit':bit,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'expected_sigfpe':expected_signal})
(r/'results.json').write_text(json.dumps({'status':'PASS','cases':len(rows),'rows':rows},indent=2)+'\n');print('PASS',len(rows),'full scalar-helper environment cases')
