import ctypes as C,sys,itertools,json,random,math
from pathlib import Path
from fractions import Fraction as F
from test_native import run,Result
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from review import evaluate
old=C.CDLL('/workspace/shared/ihp-psp-compensated-clang-review-v2/libkernel.so')
old.compensated_rhs.argtypes=[C.POINTER(C.c_double),C.POINTER(C.c_double),C.c_size_t,C.c_int,C.c_double,C.c_int,C.c_double,C.POINTER(Result)]
rows=0;accepted=0;unchanged=0

def check(j,x,r,l):
 global rows,accepted,unchanged
 status,o=run(j,x,r,0.0 if l is None else l,lp=int(l is not None))
 expected,e,v=evaluate(j,x,r,l)
 assert status==(0 if expected=='ACCEPT' else 4)
 if status==0:
  assert [a.hex() for a in o.expansion[:o.count]]==[a.hex() for a in e]
  assert o.estimate.hex()==v.hex()
  exact=sum((F(a)*F(b) for a,b in zip(j,x)),F())-F(r)+(F(l) if l is not None else 0)
  assert sum(map(F,o.expansion[:o.count]),F())==exact
  u=F(1,2**53);bound=o.count*u/(1-o.count*u)*sum((abs(F(a)) for a in e),F())
  assert abs(F(o.estimate)-exact)<=bound;accepted+=1
 else:assert o.count==0 and math.isnan(o.estimate)
 a=(C.c_double*len(j))(*j);b=(C.c_double*len(x))(*x);previous=Result()
 prior=old.compensated_rhs(a,b,len(j),1,r,int(l is not None),0.0 if l is None else l,C.byref(previous))
 if prior==0:
  assert status==0 and previous.estimate.hex()==o.estimate.hex()
  assert [a.hex() for a in previous.expansion[:previous.count]]==[a.hex() for a in o.expansion[:o.count]];unchanged+=1
 rows+=1
vals=[-0.,0.,-1.,1.,-2.,2.]
for a,b,r,l in itertools.product(vals,repeat=4):
 for j,x in [([a],[b]),([a,1.],[b,2.]),([a,1.,-1.],[b,2.,2.])]:check(j,x,r,l)
rng=random.Random(733)
for _ in range(500):
 n=rng.randrange(1,65);j=[];x=[]
 for i in range(n):
  def value():return rng.choice([-0.,0.]) if rng.random()<.35 else math.ldexp(rng.uniform(1,1.999999),rng.randrange(-199,200))*rng.choice([-1,1])
  j.append(value());x.append(value())
 check(j,x,rng.choice([-0.,0.,1.,-1.]),rng.choice([None,-0.,0.,1.]))
result=dict(status='PASS_NATIVE_STANDALONE_ONLY',native_rows=rows,accepted=accepted,zero_fallback=rows-accepted,old_accepted_bitwise_unchanged=unchanged)
Path(__file__).with_name('signed-results.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
