Independent paired PMOS research evidence

Both fixed 90-second runs timed out, with header-only raw files and no numerical result. See independent-review.json.

The package preserves the two run receipts/decks/raw/logs, exact runner/contract/authorization, and the separate zero-launch staging failure. Prerequisite receipts and static review sources are retained. Large executables, modules, libraries and PDK files are intentionally omitted. Their exact immutable hashes and source paths remain in contracts, run inventories, prerequisite receipts and omitted-staged-payloads.json. This is not a complete executable replay bundle.

No qualification, calibration, performance improvement or model-cure claim is made.
