"""Prepared two-run research diagnostic; requires explicit reviewed authorization.
No existing qualification contract is reused. No retry or altered solver/tolerance.
"""
from pathlib import Path
import json,hashlib,subprocess,shutil,time,uuid,resource,re,math,importlib.util
R=Path(__file__).resolve().parent;OLD=Path('/workspace/shared/ihp-pmos-measured-attempt-3');COMP=Path('/workspace/shared/ihp-psp-compensated-psp-compile')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def files(p):return {x.relative_to(p).as_posix():sha(x) for x in p.rglob('*') if x.is_file()}
def loadmod(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
BAD=re.compile(r'(?im)^\s*(?:error|fatal|fatal error)\b|unknown (?:parameter|model)|simulation (?:aborted|failed)|no such file|could not load|failed to load|using KLU|singular matrix|timestep too small')
def main():
 c=json.loads((R/'contract.json').read_text());a=json.loads((R/'authorization.json').read_text())
 assert a['status']=='PARENT_AUTHORIZED_REVIEWED_TWO_RUN_DIAGNOSTIC' and a['runner_sha256']==sha(__file__) and a['contract_sha256']==sha(R/'contract.json')
 def verify():
  for p,h in c['bindings'].items():assert sha(p)==h,p
  for root,manifest in c['source_manifests'].items():assert files(Path(root))==manifest
 verify();root=R/'runs';root.mkdir(exist_ok=False)
 exe=Path(c['engine']);records=[]
 for variant in ['pristine','on']:
  verify();out=root/variant;out.mkdir();nonce=uuid.uuid4().hex
  for prefix in ['pdk','runtime']:shutil.copytree(OLD/prefix,out/prefix)
  shutil.copy2(COMP/variant/'psp103.osdi',out/'runtime/psp103.osdi')
  shutil.copy2(OLD/'engine/runtime/spinit',out/'spinit')
  original=(OLD/'runs/nominal-3/input.cir').read_bytes();body=original.split(b'\n',1)[1]
  title=f'* IHP-PMOS-compensated-pair-research-v1 {nonce} {variant} -1.124'
  (out/'input.cir').write_bytes(title.encode()+b'\n'+body)
  assert (out/'input.cir').read_bytes().split(b'\n',1)[1]==body
  env={'PATH':'/usr/bin:/bin','HOME':str(out),'LANG':'C','LC_ALL':'C','TZ':'UTC','SPICE_SCRIPTS':str(out),'OMP_NUM_THREADS':'1'}
  def deps():
   z=subprocess.run(['ldd',str(exe)],env=env,capture_output=True,text=True,timeout=10,check=True);assert 'not found' not in z.stdout+z.stderr
   return {str(Path(w).resolve()):sha(Path(w).resolve()) for line in z.stdout.splitlines() for w in line.split() if w.startswith('/') and Path(w).is_file()}
  assert deps()==c['engine_dependencies']
  inputs=files(out)
  assert {p:sha(out/'runtime'/p) for p in c['other_modules']}==c['other_modules']
  assert sha(out/'runtime/psp103.osdi')==c['psp_modules'][variant]
  cmd=[str(exe),'-n','-D','filetype=ascii','-D','ngbehavior=hsa','-b','-r',str(out/'result.raw'),str(out/'input.cir')]
  rec=dict(diagnostic_id='ihp-pmos-compensated-pair-research-v1-'+nonce,variant=variant,qualified=False,command=cmd,cwd=str(out),environment=env,deadline_seconds=90,input_hashes=inputs,nonce=nonce,title=title,returncode=None,timed_out=False,contract_sha256=sha(R/'contract.json'),runner_sha256=sha(__file__))
  def save():(out/'run.json').write_text(json.dumps(rec,indent=2)+'\n')
  save();start=time.monotonic()
  def limits():resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024*1024,16*1024*1024))
  try:
   with (out/'console.log').open('xb') as f:
    p=subprocess.run(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90,preexec_fn=limits)
   rec['returncode']=p.returncode
  except subprocess.TimeoutExpired:rec['timed_out']=True
  except Exception as e:rec['execution_error']=repr(e);raise
  finally:
   rec['seconds']=time.monotonic()-start;rec['outputs']={n:sha(out/n) for n in ['console.log','result.raw'] if (out/n).exists()}
   try:
    verify();assert deps()==c['engine_dependencies'];assert all(sha(out/p)==h for p,h in inputs.items());rec['post_identity_pass']=True
   except Exception as e:rec['post_identity_error']=repr(e);raise
   finally:save()
  log=(out/'console.log').read_text();assert not BAD.search(log),'Strict log rejection; stop pair without retry'
  if rec['timed_out']:rec['readback_status']='TIMEOUT_INCOMPLETE_NOT_ACCEPTED'
  else:
   assert rec['returncode']==0
   parser=loadmod('pair_raw',OLD/'sources/scripts/audit_sky130_li_linked.py')
   rawpath=out/'result.raw';rawtext=rawpath.read_text();assert rawtext.splitlines()[0].lower()=='title: '+title.lower()
   assert 'Flags: real' in rawtext.splitlines() and sum(x.startswith('Title:') for x in rawtext.splitlines())==1
   values,axis=parser.raw(rawpath);assert len(axis)==28 and all(abs(v+i/20)<1e-12 for i,v in enumerate(axis))
   assert set(values)=={'v(v-sweep)','i(vd)','i(vg)','i(vs)','i(vb)'}
   assert all(math.isfinite(v) for vs in values.values() for v in vs)
   currents=[{t:-values['i(v'+t+')'][i] for t in 'dgsb'} for i in range(28)]
   kcl=max(abs(sum(row.values()))/(1e-13+1e-6*sum(abs(v) for v in row.values())) for row in currents);assert kcl<=1
   measurement=loadmod('pair_measurement',OLD/'sources/scripts/ihp_pmos_measured_reference.py')
   measured=measurement.parse((OLD/'measurement.mdm').read_bytes())[84:112];assert len(measured)==28
   residuals=[]
   for ref,actual in zip(measured,currents):
    residuals.append({t:dict(measured_a=float(ref['currents'][t]),simulated_a=actual[t],signed_residual_a=actual[t]-float(ref['currents'][t]),absolute_residual_a=abs(actual[t]-float(ref['currents'][t])),relative_residual=(actual[t]-float(ref['currents'][t]))/abs(float(ref['currents'][t])) if float(ref['currents'][t]) else None) for t in 'dgsb'})
   rec['measurement_residuals_unconditional']=residuals
   rec.update(readback_status='COMPLETE_ONE_GATE_DIAGNOSTIC_ONLY',points=28,currents=currents,kcl_max_normalized=kcl,measurement_acceptance=None)
  save();records.append(rec)
 (R/'result.json').write_text(json.dumps(dict(status='TWO_RUN_RESEARCH_DIAGNOSTIC_RECORDED',qualified=False,independent_calibration=False,installed_acceptance=False,records=records),indent=2)+'\n')
if __name__=='__main__':main()
