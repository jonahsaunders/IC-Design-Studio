exec(open(__file__.replace('rhs_review.py','static_review.py')).read().split("p=ELF('pristine')")[0])
def run(v,name):
 e=ELF(v);text=(R/v/'disassembly.txt').read_text();m=re.search(r'<'+name+r'>:\n(.*?)(?=\n\n)',text,re.S);rows=[]
 for line in m[1].splitlines():
  q=re.match(r'\s*([0-9a-f]+):[^\t]*\t(.*)',line)
  if q:rows.append((int(q[1],16),q[2].split('#')[0].strip()))
 addr={a:i for i,(a,t) in enumerate(rows)};reg={'%rdi':('ptr','I'),'%rsi':('ptr','M'),'%rdx':('ptr','D'),'%rcx':('ptr','X'),'%rsp':('ptr','S'),'%rbp':('ptr','B'),'%xmm0':('alpha',)};mem={};outs=[];calls=[];i=0
 def rr(s):return '%r'+s[2:] if s.startswith('%e') else s
 def loc(s):
  q=re.fullmatch(r'(-?\d*)\((%\w+)(?:,(%\w+),(\d+))?\)',s);assert q,s
  off=int(q[1] or 0);base=reg[rr(q[2])];idx=reg[rr(q[3])] if q[3] else None
  return (base,off,idx,int(q[4] or 1))
 def get(s):
  if s.startswith('$'):return int(s[1:],0)
  if s.startswith('%'):return reg[rr(s)]
  key=loc(s)
  if key in mem:return mem[key]
  base,off,idx,scale=key
  if base==('ptr','I'):return ('I',off)
  if base==('ptr','X'):return ('X',idx)
  if base==('ptr','D'):return ('D',idx)
  raise ValueError(('get',s,key))
 def low(x):return x[1] if isinstance(x,tuple) and x[0]=='V' else x
 def vec(x):return x if isinstance(x,tuple) and x[0]=='V' else ('V',x,('unknown_high',))
 def put(s,x):
  if s.startswith('%'):reg[rr(s)]=x;return
  key=loc(s);mem[key]=x
  if key[0]==('ptr','D'):outs.append((key[2],x))
 while i<len(rows):
  pc,t=rows[i];i+=1;z=t.split(None,1);op=z[0];args=re.split(r',\s+(?![^()]*\))',z[1]) if len(z)>1 else []
  if op in ['pushq','popq','retq','nopw','nopl']:continue
  if op in ['subq','addq'] and args[-1]=='%rsp':continue
  if op in ['movq','movabsq','movl','movsd','movslq','movapd','movaps']:
   if op=='movslq':put(args[1],('map',int(re.match(r'\d+',args[0])[0])))
   else:
    value=low(get(args[0])) if op=='movsd' else get(args[0])
    if op=='movq' and args[1].startswith('%xmm') and isinstance(value,int):value=('literal',struct.unpack('<d',struct.pack('<Q',value&((1<<64)-1)))[0])
    put(args[1],value)
  elif op=='leaq':put(args[1],('address',loc(args[0])))
  elif op in ['mulsd','addsd','subsd']:put(args[1],(op,low(get(args[1])),low(get(args[0]))))
  elif op in ['mulpd','addpd']:
   x=vec(get(args[1]));y=vec(get(args[0]));put(args[1],('V',(op.replace('pd','sd'),x[1],y[1]),(op.replace('pd','sd'),x[2],y[2])))
  elif op in ['unpcklpd','unpckhpd']:
   x=vec(get(args[1]));y=vec(get(args[0]));k=1 if op=='unpcklpd' else 2;put(args[1],('V',x[k],y[k]))
  elif op=='xorpd':
   assert '(%rip)' in args[0];put(args[1],('neg',low(get(args[1]))))
  elif op=='callq':
   assert 'openvaf_experimental_compensated_rhs' in t,t
   n=reg['%rdx'];pairs=[]
   for k in range(n):
    def at(r):
     key=reg[r][1];v=mem[(key[0],key[1]+8*k,key[2],key[3])];return ('literal',struct.unpack('<d',struct.pack('<Q',v&((1<<64)-1)))[0]) if isinstance(v,int) else low(v)
    pairs.append((at('%rdi'),at('%rsi')))
   calls.append({'pairs':pairs,'residual':low(reg['%xmm0']),'n':n,'pc':hex(pc)});reg['%rax']=1
  elif op in ['testl','je']:continue # select original rejection fallback
  elif op=='jmp':i=addr[int(args[0].split()[0],16)]
  else:raise ValueError((v,name,hex(pc),t,args))
 return outs,calls
pdc,pc=run('pristine','load_spice_rhs_dc_0');odc,oc=run('on','load_spice_rhs_dc_0');pt,ptc=run('pristine','load_spice_rhs_tran_0');ot,otc=run('on','load_spice_rhs_tran_0')
print('rows',len(pdc),len(odc),'calls',len(oc),len(otc),'transrows',len(pt),len(ot))
def canon(x):
 if not isinstance(x,tuple):return x
 if x[0]=='mulsd' and ('literal',-1.0) in x[1:]:return ('neg',canon(x[2] if x[1]==('literal',-1.0) else x[1]))
 if x[0] in ['addsd','mulsd']:
  children=[]
  def f(z):
   if isinstance(z,tuple) and z[0]==x[0]:f(z[1]);f(z[2])
   else:children.append(canon(z))
  f(x[1]);f(x[2]);return (x[0],*sorted(children,key=str))
 return tuple(canon(z) for z in x)
def poly(x):
 if x[0] in ['I','X','D','alpha']:return {(str(x),):1}
 if x[0]=='literal':return {():x[1]}
 if x[0]=='neg':return {k:-v for k,v in poly(x[1]).items()}
 if x[0] in ['addsd','subsd','mulsd']:
  a,b=poly(x[1]),poly(x[2]);out={}
  if x[0]=='mulsd':
   for k,v in a.items():
    for l,w in b.items():t=tuple(sorted(k+l));out[t]=out.get(t,0)+v*w
  else:
   out=dict(a)
   for k,v in b.items():out[k]=out.get(k,0)+(v if x[0]=='addsd' else -v)
  return {k:v for k,v in out.items() if v!=0}
 raise ValueError(x)
print('fallback_algebra',canon(tuple(pdc))==canon(tuple(odc)))
def strip(rows,prior):
 def f(x):
  for dest,old in prior:
   if x==old:return ('D',dest)
  return tuple(f(y) for y in x) if isinstance(x,tuple) else x
 return [(d,f(x)) for d,x in rows]
pr=strip(pt[len(pdc):],pdc);orr=strip(ot[len(odc):],odc)
print('reactive exact trees after prior destination abstraction',pr==orr, 'algebra',canon(tuple(pr))==canon(tuple(orr)));print('dc/tran calls same',[(x['pairs'],x['residual']) for x in oc]==[(x['pairs'],x['residual']) for x in otc])
# each exact helper target matches its actual old row algebra after destination subtraction.
for (dest,expr),call in zip(pdc,oc):
 target=None
 for j,x in call['pairs']:
  term=('mulsd',j,x);target=term if target is None else ('addsd',target,term)
 target=('subsd',target,call['residual']);target=('addsd',target,('D',dest))
 assert poly(target)==poly(expr),(dest,call)
assert all(d==e and poly(x)==poly(y) for (d,x),(e,y) in zip(pdc,odc))
assert all(d==e and poly(x)==poly(y) for (d,x),(e,y) in zip(pr,orr))
print('all helper pair/residual exact algebra matches original rows')
(R/'rhs-symbolic-review.json').write_text(json.dumps({'old_dc_rows':pdc,'on_fallback_rows':odc,'helper_calls':oc,'transient_helper_calls':otc,'reactive_original':pt[len(pdc):],'reactive_on':ot[len(odc):]},indent=2))
