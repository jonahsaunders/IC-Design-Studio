from pathlib import Path
import json,subprocess,hashlib,re,platform
R=Path(__file__).parent
cmd='gcc -std=c11 -O2 -fPIC -shared -fno-fast-math -ffp-contract=off -frounding-math -fexcess-precision=standard -fno-builtin-fma -Wall -Wextra -Werror kernel.c -lm -o libkernel.so'
def run(*args):return subprocess.check_output(args,text=True).strip()
paths=[Path('/usr/bin/gcc').resolve(),Path(run('gcc','-print-prog-name=cc1')).resolve(),Path('/usr/bin/ld').resolve()]
for line in (R/'dependencies.txt').read_text().splitlines():
 for s in re.findall(r'(/[\w/+.\-]+)',line):
  if Path(s).is_file():paths.append(Path(s).resolve())
files=[R/n for n in ['kernel.c','test_native.py','libkernel.so','build.log','test.log','disassembly.txt','elf.txt','dependencies.txt']]+paths
asm=(R/'disassembly.txt').read_text()
assert re.search(r'call\s+\w+\s+<fma@plt>',asm)
assert 'addsd' in asm and 'subsd' in asm
record=dict(status='STANDALONE_NATIVE_KERNEL_TESTED_NOT_COMPILER_OR_CIRCUIT_INTEGRATION',build_command=cmd,compiler_version=run('gcc','--version'),platform=platform.platform(),
 tests={'passed':15,'exact_random_rows':500,'seconds':float(re.search(r'Ran 15 tests in ([0-9.]+)s', (R/'test.log').read_text()).group(1)),'coverage':'actual rounding modes upward/downward/towardzero and separate MXCSR rounding/FTZ/DAZ changes all fallback and restored; exact Fraction expansion/bound, signed zeros/products/zero output, optional absence, cap64, invalid/subnormal/domain extremes, stale epochs/vector, limiter, opposite-row conservation'},
 generated_code={'fma':'Actual call to fma@plt retained; ELF undefined fma@GLIBC_2.2.5 resolved by recorded libm. No hardware FMA assumption.','two_sum':'Disassembly preserves addsd then distinct subsd chain then addsd error reconstruction; -fno-fast-math and -ffp-contract=off prevent reassociation/contraction.','environment':'fegetround plus x86_64 MXCSR FTZ/DAZ AND rounding bits checked. Non-Linux or unsupported architecture falls back. Strict binary64 compile constants required.'},
 arithmetic_contract='Reviewed exact expansion and domain proof from reference specification apply; native returns expansion plus sequential estimate. Fraction harness verifies exact actual cached-expression expansion and gamma_n sumabs estimate error. No floating error bound computed by C and no correctly-rounded estimate claim.',
 fallback_contract='Nonzero status returns count0 and NaN estimate, no compensated value. Original callback must be invoked by future adapter; this standalone kernel does not implement or approximate host fallback. Absent residual/limiter or empty contribution row falls back, never synthesized as +0. Negative-zero inputs/products and zero final estimate fall back. Optional native callback semantics are not certified by this harness.',
 caveats=['This does not fix OpenVAF or a circuit. Model/runtime/candidate unchanged; no circuit run.','Preservation of floating-point exception flags is not claimed: extra exact-arithmetic operations/fma may set inexact flags. Future callback integration must establish host exception-environment contract.','Caller must provide valid arrays and output pointer with stated lengths; malformed pointers are outside standalone C ABI contract.','Source-level guards and exact arithmetic tests are not proof against all compiler/platform behaviors; identities and generated instructions retained for this specific build.'],
 reference_spec=dict(path='/workspace/shared/ihp-psp-compensated-rhs-prototype/specification.json',sha256=hashlib.sha256(Path('/workspace/shared/ihp-psp-compensated-rhs-prototype/specification.json').read_bytes()).hexdigest()),
 identities=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in dict.fromkeys(files)],circuit_runs=0,candidate_edits=0)
p=R/'evidence.json';p.write_text(json.dumps(record,indent=2)+'\n');print(hashlib.sha256(p.read_bytes()).hexdigest())
