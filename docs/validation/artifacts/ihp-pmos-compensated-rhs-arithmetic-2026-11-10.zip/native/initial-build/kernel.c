/* Standalone research kernel. NOT an OSDI/backend integration.
 * Exact-real expansion of supplied cached values, under documented bounds.
 * No correct-rounding, circuit convergence or signed-zero equivalence claim.
 */
#include <math.h>
#include <fenv.h>
#include <stddef.h>
#include <stdint.h>
#include <float.h>
#if defined(__x86_64__) || defined(__i386__)
#include <xmmintrin.h>
#endif
#define CAP 64
#define EMAX (2*CAP+2)
typedef struct { double expansion[EMAX]; double estimate; size_t count; } Result;
enum { ACCEPT=0, ENVIRONMENT=1, DOMAIN=2, OPTIONAL=3, ZERO_POLICY=4, LIMIT=5 };

static int environment_ok(void) {
#if defined(__linux__) && defined(__x86_64__) && FLT_RADIX == 2 && DBL_MANT_DIG == 53 && DBL_MAX_EXP == 1024
    return fegetround()==FE_TONEAREST && (_mm_getcsr() & ((1u<<15)|(1u<<6)|(3u<<13)))==0;
#else
    return 0;
#endif
}
static int input_ok(double x) {
    return isfinite(x) && ((x==0.0 && !signbit(x)) ||
           (fabs(x)>=0x1p-200 && fabs(x)<=0x1p200));
}
static void two_sum(double a,double b,double *s,double *e) {
    double q=a+b;
    double bv=q-a;
    double av=q-bv;
    double br=b-bv;
    double ar=a-av;
    *s=q;*e=ar+br;
}
static size_t grow(double *expansion,size_t n,double b) {
    double out[EMAX];size_t m=0;double q=b;
    for(size_t k=0;k<n;k++) {
        double s,e;two_sum(q,expansion[k],&s,&e);q=s;
        if(e!=0.0)out[m++]=e;
    }
    if(q!=0.0)out[m++]=q;
    for(size_t k=0;k<m;k++)expansion[k]=out[k];
    return m;
}
int compensated_rhs(const double *j,const double *x,size_t n,
                    int residual_present,double residual,
                    int limiter_present,double limiter,Result *out) {
    /* On fallback no compensated estimate/expansion is returned. Caller must
     * invoke its ORIGINAL optional-term loader, not this kernel's approximation. */
    out->count=0;out->estimate=NAN;
    if(!environment_ok())return ENVIRONMENT;
    if(n>CAP)return LIMIT;
    /* Absence is never synthesized as +0. Empty rows also use original path. */
    if(n==0 || !residual_present || !limiter_present)return OPTIONAL;
    if(!input_ok(residual)||!input_ok(limiter))return DOMAIN;
    for(size_t k=0;k<n;k++)if(!input_ok(j[k])||!input_ok(x[k]))return DOMAIN;
    double expansion[EMAX];size_t count=0;
    for(size_t k=0;k<n;k++) {
        double p=j[k]*x[k];
        if(p==0.0 && signbit(p))return ZERO_POLICY;
        /* Genuine libm fused operation; compiled -fno-builtin-fma.
         * fma error is exact within the reviewed lattice/range bounds. */
        double e=fma(j[k],x[k],-p);
        count=grow(expansion,count,e);
        count=grow(expansion,count,p);
    }
    count=grow(expansion,count,-residual);
    count=grow(expansion,count,limiter);
    double estimate=0.0;
    for(size_t k=0;k<count;k++)estimate+=expansion[k];
    /* Exact-zero and any rounded-zero final result preserve original signed
     * zero semantics through fallback, not a claimed equivalent +0. */
    if(count==0 || estimate==0.0)return ZERO_POLICY;
    if(!isfinite(estimate))return DOMAIN;
    for(size_t k=0;k<count;k++)out->expansion[k]=expansion[k];
    out->count=count;out->estimate=estimate;
    return ACCEPT;
}
/* Standalone test controls only, not intended production API. */
int test_getround(void){return fegetround();}
int test_setround(int x){return fesetround(x);}
int test_upward(void){return FE_UPWARD;}
int test_downward(void){return FE_DOWNWARD;}
int test_towardzero(void){return FE_TOWARDZERO;}
unsigned test_getcsr(void){
#if defined(__x86_64__)
return _mm_getcsr();
#else
return 0;
#endif
}
void test_setcsr(unsigned x){
#if defined(__x86_64__)
_mm_setcsr(x);
#else
(void)x;
#endif
}
