import ctypes as C,unittest,math,random,subprocess,sys
from pathlib import Path
from fractions import Fraction as F
L=C.CDLL(str(Path(__file__).with_name('libkernel.so')))
class Result(C.Structure):
    _fields_=[('expansion',C.c_double*130),('estimate',C.c_double),('count',C.c_size_t)]
L.compensated_rhs.argtypes=[C.POINTER(C.c_double),C.POINTER(C.c_double),C.c_size_t,C.c_int,C.c_double,C.c_int,C.c_double,C.POINTER(Result)]
L.compensated_rhs.restype=C.c_int
L.test_setround.argtypes=[C.c_int];L.test_setcsr.argtypes=[C.c_uint];L.test_getcsr.restype=C.c_uint

def run(j,x,r=0.0,l=0.0,rp=1,lp=1):
    assert len(j)==len(x)
    a=(C.c_double*len(j))(*j);b=(C.c_double*len(x))(*x);out=Result()
    status=L.compensated_rhs(a,b,len(j),rp,r,lp,l,C.byref(out))
    return status,out
class Native(unittest.TestCase):
    def check(self,j,x,r=0.0,l=0.0,lp=1):
        s,o=run(j,x,r,l,lp=lp);self.assertEqual(s,0)
        exact=sum((F(a)*F(b) for a,b in zip(j,x)),F(0))-F(r)+(F(l) if lp else F(0))
        es=list(o.expansion[:o.count]);self.assertEqual(sum(map(F,es),F(0)),exact)
        n=len(es);u=F(1,2**53);bound=n*u/(1-n*u)*sum(map(lambda a:abs(F(a)),es),F(0))
        self.assertLessEqual(abs(F(o.estimate)-exact),bound)
        self.assertLessEqual(n,2*len(j)+2)
        return o
    def fallback(self,args,status=None):
        s,o=run(*args);self.assertNotEqual(s,0)
        if status is not None:self.assertEqual(s,status)
        self.assertEqual(o.count,0);self.assertTrue(math.isnan(o.estimate))
    def test_cancellation(self):
        g=100.966166859;v=-1.124;gp=-1.1239999999412742
        self.check([g,-g],[v,gp],g*(v-gp))
    def test_stale_epochs_and_vectors(self):
        self.assertEqual(self.check([2.0],[5.0],15.0).estimate,-5.0)
        self.assertEqual(self.check([2.0],[5.0],6.0).estimate,4.0)
    def test_limiter(self):self.check([1.0],[1.0],1.0,2.0**-200)
    def test_exponents(self):self.check([2.0**200,2.0**-200],[2.0**200,2.0**-200])
    def test_cap(self):
        self.check([2.0**200]*64,[2.0**200]*64)
        self.fallback(([1.0]*65,[1.0]*65),5)
    def test_optional_absence(self):
        self.fallback(([],[]),3)
        self.fallback(([1.0],[1.0],0.0,0.0,0,1),3)
        self.check([1.0],[2.0],0.0,lp=0)
    def test_absent_limiter_ignored_exactly(self):
        for ignored in [0.0,-0.0,math.nan,math.inf,-math.inf,math.ulp(0.0)]:
            self.check([0.1,-2.3],[0.7,1.9],0.2,ignored,lp=0)
        self.fallback(([1.0],[1.0],1.0,math.nan,1,0),4)
    def test_exception_masks_guard_only_in_subprocess(self):
        code = """import ctypes as C
l=C.CDLL(%r)
l.test_unmasked_guard.argtypes=[C.c_uint,C.c_uint]
l.test_unmasked_guard.restype=C.c_int
for unit in (0,1):
 for bit in range(6):
  assert l.test_unmasked_guard(unit,bit)==0,(unit,bit)
print('12 exception-mask guard probes passed; control state restored')
""" % str(Path(__file__).with_name('libkernel.so'))
        p=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True,timeout=10)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('12 exception-mask',p.stdout)
        self.check([1.0],[2.0])
    def test_signedzero_inputs(self):
        for args in [([-0.0],[1.0]),([1.0],[-0.0]),([1.0],[1.0],-0.0),([1.0],[1.0],0.0,-0.0)]:self.fallback(args,2)
    def test_negativezero_products(self):
        self.fallback(([-1.0],[0.0]),4)
        self.fallback(([0.0],[-1.0]),4)
    def test_exactzero_outputs(self):
        self.fallback(([1.0],[1.0],1.0),4)
        self.fallback(([1.0,-1.0],[2.0,2.0]),4)
    def test_positivezero_nonzero_row(self):self.check([0.0,1.0],[1.0,2.0])
    def test_invalid_every_position(self):
        for bad in [math.nan,math.inf,-math.inf,math.ulp(0.0),2.0**-201,2.0**201]:
            for args in [([bad],[1.0]),([1.0],[bad]),([1.0],[1.0],bad),([1.0],[1.0],0.0,bad)]:self.fallback(args,2)
    def test_real_rounding_modes_restored(self):
        old=L.test_getround();csr=L.test_getcsr()
        try:
            for mode in [L.test_upward(),L.test_downward(),L.test_towardzero()]:
                self.assertEqual(L.test_setround(mode),0)
                self.fallback(([1.0],[2.0]),1)
                self.assertEqual(L.test_setround(old),0);L.test_setcsr(csr)
        finally:L.test_setround(old);L.test_setcsr(csr)
        self.check([1.0],[2.0])
    def test_mxcsr_modes_restored(self):
        old=L.test_getcsr()
        try:
            for bits in [1<<15,1<<6,(1<<15)|(1<<6),1<<13,2<<13,3<<13]:
                L.test_setcsr(old|bits)
                self.fallback(([1.0],[2.0]),1)
                L.test_setcsr(old)
        finally:L.test_setcsr(old)
        self.check([1.0],[2.0])
    def test_opposite_conservation(self):
        j=[0.1,2.3,-10.7];x=[0.7,-3.9,1.1];r=2.2;l=0.3
        a=self.check(j,x,r,l);b=self.check([-v for v in j],x,-r,-l)
        self.assertEqual(sum(map(F,a.expansion[:a.count]),F(0)),-sum(map(F,b.expansion[:b.count]),F(0)))
    def test_exact_random_rows(self):
        rng=random.Random(1703)
        for _ in range(500):
            def v():return math.ldexp(rng.choice((-1.0,1.0))*rng.uniform(.5,1.0),rng.randint(-190,190))
            n=rng.randrange(1,65);self.check([v() for _ in range(n)],[v() for _ in range(n)],v(),v())
if __name__=='__main__':unittest.main()
