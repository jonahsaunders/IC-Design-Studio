"""Reference-only FMA/TwoSum expansion of ACTUAL cached sum(J*x)-r+lim.

Python has no math.fma here. reference_fma uses Fraction and correctly rounded
float conversion as an explicitly non-native FMA oracle. No circuit code calls
this module. A native port needs true IEEE FMA, RN-even and no fast-math/FTZ/DAZ.
"""
import math
from fractions import Fraction as F

CAP = 64
LOW, HIGH = 2.0**-200, 2.0**200


def reference_fma(a, b, c):
    return float(F.from_float(a)*F.from_float(b)+F.from_float(c))


def two_sum(a, b):
    s = a+b
    bv = s-a
    av = s-bv
    br = b-bv
    ar = a-av
    return s, ar+br


def two_product(a, b):
    p = a*b
    return p, reference_fma(a,b,-p)


def add_component(expansion, b):
    out=[]
    q=b
    for a in expansion:
        q,e=two_sum(q,a)
        if e != 0.0:
            out.append(e)
    if q != 0.0:
        out.append(q)
    return out


def supported(v):
    return (type(v) is float and math.isfinite(v) and
            (v == 0.0 and math.copysign(1.0,v)>0 or LOW<=abs(v)<=HIGH))


def legacy(js, xs, residual, limiter):
    # Explicit reference order, not a claim about any native fast-math lowering.
    s=0.0
    for j,x in zip(js,xs):
        s=s+j*x
    return (s-residual)+limiter


def evaluate(js, xs, residual, limiter=0.0, *, nearest_even=True):
    js,xs=list(js),list(xs)
    if len(js)!=len(xs):
        raise ValueError('row dimensions differ')
    reason=None
    if not nearest_even:
        reason='rounding-mode-not-certified'
    elif len(js)>CAP:
        reason='row-cap'
    elif not all(supported(v) for v in js+xs+[residual,limiter]):
        reason='outside-finite-normal-bounded-domain-or-negative-zero'
    if reason:
        return dict(status='fallback',reason=reason,expansion=None)
    expansion=[]
    for j,x in zip(js,xs):
        p,e=two_product(j,x)
        expansion=add_component(expansion,e)
        expansion=add_component(expansion,p)
    expansion=add_component(expansion,-residual)
    expansion=add_component(expansion,limiter)
    # This estimate is NOT claimed correctly rounded. Exact expansion is retained.
    estimate=0.0
    for component in expansion:
        estimate+=component
    n=len(expansion)
    u=F(1,2**53)
    gamma=n*u/(1-n*u)
    forward_bound=gamma*sum((abs(F.from_float(x)) for x in expansion),F(0))
    return dict(status='expansion',expansion=tuple(expansion),estimate=estimate,
                estimate_absolute_error_bound=forward_bound)
