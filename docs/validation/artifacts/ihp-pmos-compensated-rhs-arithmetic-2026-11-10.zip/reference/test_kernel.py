import math,unittest,random
from fractions import Fraction as F
from kernel import evaluate,two_sum,two_product,CAP,LOW,HIGH,legacy

def target(j,x,r,l):
    return sum((F.from_float(a)*F.from_float(b) for a,b in zip(j,x)),F(0))-F.from_float(r)+F.from_float(l)

class Kernel(unittest.TestCase):
    def check(self,j,x,r=0.0,l=0.0):
        result=evaluate(j,x,r,l)
        self.assertEqual(result['status'],'expansion')
        exact=target(j,x,r,l)
        self.assertEqual(sum(map(F.from_float,result['expansion']),F(0)),exact)
        self.assertLessEqual(abs(F.from_float(result['estimate'])-exact),result['estimate_absolute_error_bound'])
        self.assertLessEqual(len(result['expansion']),2*len(j)+2)
        return result
    def test_large_gate_cancellation_actual_expression(self):
        g=100.966166859;vg=-1.124;gp=-1.1239999999412742
        r=g*(vg-gp) # illustrative rounded residual, NOT native traced cached r
        result=self.check([g,-g],[vg,gp],r)
        self.assertNotEqual(target([g,-g],[vg,gp],r,0.0),0)
        self.assertLess(abs(result['estimate']),abs(legacy([g,-g],[vg,gp],r,0.0)))
    def test_stale_coefficient_epoch_preserved(self):
        self.assertEqual(self.check([2.0],[5.0],15.0)['estimate'],-5.0)
    def test_different_load_vector_preserved(self):
        self.assertEqual(self.check([2.0],[5.0],6.0)['estimate'],4.0)
    def test_mixed_and_limiter_actual_terms(self):
        self.check([100.0,112.0],[-2.0,3.0],121.0,0.123)
    def test_limiter_cancellation(self):
        self.check([1.0],[1.0],1.0,2.0**-200)
    def test_empty_row(self):
        self.assertEqual(self.check([],[],3.0,2.0)['estimate'],-1.0)
    def test_positive_zeros(self):
        self.assertEqual(self.check([0.0],[0.0])['estimate'],0.0)
    def test_signed_zero_fallback(self):
        for args in [([-0.0],[1.0],0.0,0.0),([1.0],[-0.0],0.0,0.0),([],[],-0.0,0.0),([],[],0.0,-0.0)]:
            self.assertEqual(evaluate(*args)['status'],'fallback')
    def test_exponent_boundaries(self):
        self.check([LOW,HIGH,-HIGH],[LOW,HIGH,HIGH],LOW,-LOW)
    def test_invalid_subnormal_outside_domain(self):
        for bad in [math.inf,-math.inf,math.nan,math.ulp(0.0),2.0**-201,2.0**201]:
            self.assertEqual(evaluate([bad],[1.0],0.0)['status'],'fallback')
    def test_cap(self):
        self.check([HIGH]*CAP,[HIGH]*CAP)
        self.assertEqual(evaluate([1.0]*(CAP+1),[1.0]*(CAP+1),0.0)['status'],'fallback')
    def test_rounding_mode_fallback(self):
        self.assertEqual(evaluate([1.0],[1.0],0.0,nearest_even=False)['status'],'fallback')
    def test_dimension_rejected(self):
        with self.assertRaises(ValueError):evaluate([1.0],[],0.0)
    def test_opposite_row_conservation(self):
        j=[0.1,2.3,-10.7];x=[0.7,-3.9,1.1];r=2.2;l=0.3
        a=self.check(j,x,r,l);b=self.check([-v for v in j],x,-r,-l)
        self.assertEqual(sum(map(F.from_float,a['expansion']),F(0)),-sum(map(F.from_float,b['expansion']),F(0)))
    def test_two_product_reference_eft(self):
        for a,b in [(0.1,0.7),(HIGH,HIGH),(LOW,LOW),(HIGH,LOW)]:
            p,e=two_product(a,b);self.assertEqual(F.from_float(p)+F.from_float(e),F.from_float(a)*F.from_float(b))
    def test_two_sum_eft(self):
        for a,b in [(1.0,2.0**-200),(HIGH,-HIGH),(LOW,LOW),(HIGH,LOW)]:
            s,e=two_sum(a,b);self.assertEqual(F.from_float(s)+F.from_float(e),F.from_float(a)+F.from_float(b))
    def test_deterministic_exact_random_rows(self):
        rng=random.Random(1703)
        for _ in range(250):
            def val():return math.ldexp(rng.choice((-1.0,1.0))*rng.uniform(0.5,1.0),rng.randint(-190,190))
            n=rng.randrange(1,65);self.check([val() for _ in range(n)],[val() for _ in range(n)],val(),val())
if __name__=='__main__':unittest.main()
