"""Seal retained source-only review; no network or native execution."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
sources=json.loads((R/'sources.json').read_bytes())
assert len(sources)==81 and len({x['path'] for x in sources})==81
for row in sources:
 p=R/row['path'];assert p.resolve().is_relative_to(R.resolve()) and not p.is_symlink()
 b=p.read_bytes();assert H(b)==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob']
assert H((R/'analysis.json').read_bytes())=='c13e5adb269bfe8c9a5d55f398f894922533d9348ee5fa79a82af094aa2ee4cd'
license_source=Path('/workspace/shared/ic-design-studio-recovery/docs/qualification/gf180-mos-spec-sources-v1/LICENSE')
b=license_source.read_bytes();assert H(b)=='cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30'
(R/'LICENSE').write_bytes(b)
notes={'scope':'Read-only public-source review; no execution or qualification',
 'license':{'file':'LICENSE','sha256':H(b),'source':'https://raw.githubusercontent.com/google/gf180mcu-pdk/de3240d7529a6970437ac3344820aaae7839f215/LICENSE','note':'Apache-2.0 text copied unchanged from previously pinned source bundle. Upstream file copyright notices retained.'},
 'negative_results':['Latest maintained analog documentation has identical blob identities to pinned documentation.', 'Primitive updates after pinned revision do not change MOS models or specification workbook.', 'Issue search found model-formatting discussion, not an endpoint or Vth0 definition correction.', 'Broad initial web search returned irrelevant material and was not used as evidence.'],
 'failures':'No failed native run occurred; no native run was attempted. No separate raw web-tool log was retained, so none is manufactured.',
 'requested_authoritative_facts':[
 'Reconcile the published 10/0.28um,25C,3.3V fast-corner Idsat endpoints590/-290uA/um with released reference outputs590.50/-290.47: exact compatible model/specification revision and fixture, or explicit foundry acceptance semantics.',
 'Define signed Vth0 max-gm extraction completely: terminal polarity/body condition, tangent/intercept equation and finite-VDS correction, sweep/gm differentiation/interpolation/maximum selection, and comparison/precision policy.',
 'Clarify any applicable acceptance semantics through authoritative source rather than inferred rounding or unrelated curve-regression tolerances.'],
 'not_outreach':True,'no_gate_changes':True}
(R/'REVIEW-NOTES.json').write_text(json.dumps(notes,indent=2)+'\n')
archive=R/'gf180-definition-review-2026-11-11.zip';summary=R/'gf180-definition-review-2026-11-11.json';manifest_path=R/'PACKAGE-MANIFEST.json'
assert not archive.exists() and not summary.exists() and not manifest_path.exists()
files={}
for p in sorted(R.rglob('*')):
 assert not p.is_symlink()
 if p.is_file():files[p.relative_to(R).as_posix()]=p.read_bytes()
manifest={'schema':1,'scope':'READ_ONLY_GF180_DEFINITION_REVIEW_NEGATIVE_CLOSURE_RESULT','qualified':False,'chunk_complete':False,'native_runs':0,'source_files':81,'files':{n:{'bytes':len(b),'sha256':H(b)} for n,b in files.items()},'omissions':[],'limitations':['Not simulation, calibration, installed acceptance, or a complete PDK archive.','Existing mismatch values are retained historical references, not new measurements.','Search absence does not prove no unpublished authoritative specification exists.','No source-backed waiver, rounding policy, or complete Vth0 definition found.']}
mb=(json.dumps(manifest,indent=2)+'\n').encode();manifest_path.write_bytes(mb);files['PACKAGE-MANIFEST.json']=mb
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files) and len(z.namelist())==len(files)
 for n,b in files.items():assert z.read(n)==b
record={'schema':1,'date':'2026-11-11','chunk':7,'status':'SOURCE_REVIEW_NO_AUTHORITATIVE_CLOSURE_FOUND','qualified':False,'chunk_complete':False,'native_runs':0,'repository_changes':False,'archive':archive.name,'suggested_repository_path':'docs/validation/artifacts/'+archive.name,'archive_sha256':H(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'manifest_sha256':H(mb),'archive_members':len(files),'source_files':81,'analysis_sha256':H((R/'analysis.json').read_bytes()),'findings':['Official ff/ss definition expressly binds EP extremes; production-only reinterpretation is unsupported.','Maintained FOSSi analog documentation is unchanged at25ed9c64 relative to pinnedGooglede3240; primitive5e4be872 updates leave model/specification data unchanged.','5percent curve-regression tolerance is not an EP endpoint tolerance.','Complete Vth0 extraction definition remains missing.'],'requested_authoritative_facts':notes['requested_authoritative_facts'],'limitations':manifest['limitations'],'estimated_completion_change':0}
summary.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
