import urllib.request,json,pathlib,hashlib,concurrent.futures
r=pathlib.Path(__file__).parent
repos={'docs':'google/gf180mcu-pdk','pr':'fossi-foundation/globalfoundries-pdk-libs-gf180mcu_fd_pr'}
trees={k:json.loads((r/(k+'-tree.json')).read_text()) for k in repos}
selected=[]
for k,t in trees.items():
 for e in t['tree']:
  p=e['path']
  if e['type']!='blob':continue
  if k=='docs' and (p.startswith('docs/analog/model_parameters/LV/') and p.endswith(('.rst','.csv')) or p in ['docs/analog/spice/elec_specs/elec_specs.rst','docs/analog/spice/elec_specs/tables_clear/1_Low_Voltage_Devices.csv','docs/analog/spice/elec_specs/tables_clear/9_Appendix.csv']):selected.append((k,p,e['sha']))
  if k=='pr' and p in ['models/README.md','models/ngspice/README.md','models/ngspice/testing/README.md','models/180MCU_SPICE_DATA_clean/README.md','models/ngspice/sm141064.ngspice']:selected.append((k,p,e['sha']))
def one(x):
 k,p,blob=x;u=f'https://raw.githubusercontent.com/{repos[k]}/{trees[k]["sha"]}/{p}';b=urllib.request.urlopen(u,timeout=30).read();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==blob;d=r/k/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);return {'path':str(d.relative_to(r)),'url':u,'sha256':hashlib.sha256(b).hexdigest(),'git_blob':blob,'revision':trees[k]['sha']}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: rows=list(ex.map(one,selected))
(r/'sources.json').write_text(json.dumps(rows,indent=2));print('Retained',len(rows))
