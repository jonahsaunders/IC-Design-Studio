import io,json,hashlib,subprocess,sys,tempfile,types,zipfile
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/workspace/shared/ic-design-studio-recovery');sys.path.insert(0,str(ROOT))
from scripts import recover_pw2dn_diagnostics as new
from tests.test_recover_pw2dn_diagnostics import RecoveryTests
out=Path(__file__).parent
old=types.ModuleType('original_reader');old.__file__=str(ROOT/'scripts/recover_pw2dn_diagnostics.py')
baseline=subprocess.check_output(['git','show','HEAD:scripts/recover_pw2dn_diagnostics.py'],cwd=ROOT);exec(compile(baseline,'original_reader','exec'),old.__dict__)
case=RecoveryTests();rows=[]
for sep in ['/','\\']:
 for name in ['unselected\\alias','unselected\x00suffix']:
  with tempfile.TemporaryDirectory() as td:
   proxy=types.SimpleNamespace(**vars(zipfile.os));proxy.sep=sep
   selected='windows-evidence/'+new.MEMBERS[0]
   b=case.archive([(selected,b'ValueError: valid'),(name,b'x')]).getvalue()
   with patch.object(zipfile,'os',proxy):
    with zipfile.ZipFile(io.BytesIO(b)) as z:assert z.infolist()[1].orig_filename==name
    try:new.inspect_archive(io.BytesIO(b),Path(td))
    except new.ValidationFailure as exc:assert new.failure_code(exc)=='UNSAFE_ARCHIVE_PATH'
    else:raise AssertionError('new accepted alias')
    assert not list(Path(td).iterdir())
    try:old.inspect_archive(io.BytesIO(b),Path(td));old_result='accepted'
    except old.ValidationFailure as exc:old_result=old.failure_code(exc)
   expected='UNSAFE_ARCHIVE_PATH' if sep=='/' and '\\' in name else 'accepted'
   assert old_result==expected,(sep,name,old_result)
   rows.append({'separator':sep,'wire_name':repr(name),'new':'UNSAFE_ARCHIVE_PATH_NO_OUTPUT','original':old_result})
result={'status':'PASS','scope':'NEW_RECONSTRUCTION_SOURCE_ONLY','baseline_reader_sha256':hashlib.sha256(baseline).hexdigest(),'source_bindings':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['scripts/recover_pw2dn_diagnostics.py','tests/test_recover_pw2dn_diagnostics.py']},'adversarial_controls':rows,'focused_tests':18,'workflow_retired':not(ROOT/'.github/workflows/recover-pw2dn-once.yml').exists(),'native_windows_executed':False,'historical_byte_equivalence_claimed':False}
(out/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
