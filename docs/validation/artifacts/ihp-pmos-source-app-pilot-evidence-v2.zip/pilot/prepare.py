from pathlib import Path
import sys,json,hashlib
APP=Path('/workspace/shared/ic-design-studio-next2');R=Path(__file__).parent;sys.path.insert(0,str(APP))
from scripts.qualify_standard_mos import load_technology
from icstudio.spice_import import import_spice
from icstudio.native_analysis import deck
from icstudio.model import save_project
tech,identity=load_technology('ihp-sg13g2')
original=Path('/workspace/shared/ihp-pmos-measured-v3/attempt-1/runs/nominal-3/input.cir').read_text();(R/'original.cir').write_text(original)
lines=[];inside=False
for line in original.splitlines():
 if line=='.control':inside=True;continue
 if line=='.endc':inside=False;continue
 if inside or line.startswith(('.option','.save','.dc','.lib','XDUT')):continue
 if line.startswith('.lib '):line=line.replace('pdk/',str(Path(tech['package_root']))+'/')
 lines.append(line)
p,report=import_spice(R/'import.cir',tech,text='\n'.join(lines)+'\n');p['name']='RESEARCH ONLY signed-zero PSP source-app pilot';p['spice']={'version':1,'assets':{}};p['cells'][0]['spice_statements']=[l.replace('pdk/',str(Path(tech['package_root']))+'/') for l in original.splitlines() if l.startswith(('.option','.lib','XDUT'))];p['analysis'].update(type='dc',source='VD',dc_start='0',dc_stop='-1.35',dc_step='-0.05',temperature=27,timeout=90,dc_startup=False)
save_project(p,R/'prepared.icproj');out=R/'preview';out.mkdir(exist_ok=True);text,_=deck(p,p['top'],p['analysis'],out);(R/'preview.cir').write_text(text);print(text)
