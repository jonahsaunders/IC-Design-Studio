from pathlib import Path
import sys,json,hashlib,math,re
r=Path('/workspace/shared/ihp-pmos-source-app-pilot');a=r/'attempt-2';c=json.loads((r/'contract.json').read_text());z=json.loads((a/'result.json').read_text());d=Path(z['job_directory']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not z['failure'] and not z['errors'] and not z['cleanup_errors'] and all(z['post_identity'].values())
assert all(sha(p)==h for p,h in c['bindings'].items())
for n,h in json.loads((a/'files.json').read_text()).items():assert sha(a/n)==h,n
j=json.loads((d/'input.json').read_text());assert j['executable']==c['engine'] and j['settings']['timeout']==90 and not j['settings'].get('dc_startup')
assert json.loads((d/'status.json').read_text())['exit_code']==0
mapping=json.loads((d/'pdk-model-files.json').read_text());lib=next(k for k,v in mapping.items() if v.endswith('/cornerMOSlv.lib'))
preview=(r/'preview.cir').read_text().splitlines();expected=[]
for i,line in enumerate(preview):
 expected.append(line if not line.startswith('.lib ') else '.lib '+lib+' mos_tt')
 if i==0:expected.extend(['.control','pre_osdi runtime-osdi/model-0.osdi','pre_osdi runtime-osdi/model-1.osdi','.endc'])
assert (d/'input.cir').read_text().splitlines()==expected
for i,p in enumerate(c['modules']):assert sha(d/f'runtime-osdi/model-{i}.osdi')==sha(p)
sys.path.insert(0,'/workspace/shared/ihp-pmos-measured-v3')
from scripts.audit_sky130_li_linked import raw
v,x=raw(d/'result.raw');v0,x0=raw(Path('/workspace/shared/ihp-pmos-measured-v3/attempt-1/runs/nominal-3/result.raw'));assert x==x0 and len(x)==28
K=[];E=[]
for i in range(28):
 vals=[-v['i(v'+t+')'][i] for t in 'dgsb'];assert all(map(math.isfinite,vals))
 K.append(abs(sum(vals))/(1e-13+1e-6*max(map(abs,vals))))
 for t in 'dgsb':
  q=v0['i(v'+t+')'][i];E.append(abs(v['i(v'+t+')'][i]-q)/(1e-13+1e-6*abs(q)))
assert max(K)<=1 and max(E)<=1
print('PASS deck exact, identities, 28 points KCL',max(K),'samegate',max(E));print('PDK_MAPPING',mapping)
for staged,rel in mapping.items():
 original=Path('/workspace/shared/ihp-pmos-measured-v3/attempt-1/pdk')/rel
 left=(d/staged).read_text().splitlines();right=original.read_text().splitlines();assert len(left)==len(right)
 for l,q in zip(left,right):
  if l==q:continue
  mt=re.fullmatch(r'\s*\.include\s+(\S+)\s*',q,re.I);assert mt,(staged,l,q)
  dest=next(k for k,vv in mapping.items() if vv==str(Path(rel).parent/mt.group(1).strip('\"\'')))
  assert l=='.include '+dest,(l,dest)
print('PASS all six staged source files; only exact include relocation')
rr=json.loads((d/'result.json').read_text());project=json.loads((a/'RESEARCH-project.icproj').read_text());assert j['project']==project;assert rr['engine_hash']==sha(c['engine']);assert json.loads((d/'runtime-lock.json').read_text())['osdi']==project['simulation_runtime']['osdi']
log=(d/'engine.log').read_text();assert log.count('Using SPARSE 1.3 as Direct Linear Solver')==1
for line in log.splitlines():
 if re.search('error|warning|unknown|failed|fatal',line,re.I):assert line=='Warning: m=xx on .subckt line will override multiplier m hierarchy!'
k=max(abs(sum(v['i(v'+t+')'][i] for t in 'dgsb'))/(1e-13+1e-6*sum(abs(v['i(v'+t+')'][i]) for t in 'dgsb')) for i in range(28))
report={'status':'PASS_SOURCE_APP_RESEARCH_ONLY','contract_sha256':sha(r/'contract.json'),'readback_sha256':sha(r/'readback.json'),'raw_sha256':sha(d/'result.raw'),'independent_checks':['All contract and final inventory hashes','Complete final deck exact with only declared transforms','Six PDK files match original v3 source with only exact include path rewrites','Project save/reopen and job project equality; runtime-lock and both staged modules','Recorded engine hash and selected executable; not OS exec tracing','28-point raw grid and 112 finite terminal currents equal original v3 nominal-3','Strict log permits only established hierarchy multiplier warning','No failures/cleanup errors and post identities unchanged'],'kcl_normalized_original_sum_denominator':k,'same_gate_difference_normalized':max(E),'qualified':False,'installed_acceptance':False,'calibrated':False,'graphical_parameter_acceptance':False,'new_native_runs_by_reviewer':0}
(r/'independent-readback.json').write_text(json.dumps(report,indent=2)+'\n');print('RECEIPT',sha(r/'independent-readback.json'))
