from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent;D=Path('/workspace/shared/ihp-pmos-source-app-pilot-delivery');D.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();payload={};omitted=[]
v3=Path('/workspace/shared/ihp-pmos-v3-complete-evidence.zip');v3hash=sha(v3)
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink()
 n=p.relative_to(R).as_posix()
 if 'profile' in p.relative_to(R).parts or p.suffix=='.osdi':
  row={'path':n,'sha256':sha(p),'bytes':p.stat().st_size,'reason':'Ephemeral isolated Qt/font/config profile, not numerical input' if 'profile' in p.relative_to(R).parts else 'Unchanged staged binary duplicated in pinned complete v3 evidence'}
  if p.suffix=='.osdi':row['recovery_member']='measured-v3/attempt-1/runtime/'+('psp103.osdi' if p.name=='model-0.osdi' else 'psp103_nqs.osdi')
  omitted.append(row)
 else:payload['pilot/'+n]=p.read_bytes()
base=Path('/workspace/shared/ihp-pmos-measured-v3/attempt-1')
for folder,target in [(base/'runtime-provenance/licenses','licenses/runtime'),(base/'engine/licenses','licenses/engine')]:
 for p in sorted(folder.rglob('*')):
  if p.is_file():payload[target+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
payload['licenses/ihp/LICENSE']=(base/'pdk/LICENSE').read_bytes()
for n in ['compiled-provenance/integration-result.json','compiled-provenance/single-gate-result.json','runtime-provenance/profile.json']:
 p=base/n
 if p.exists():payload['v3-provenance/'+n]=p.read_bytes()
with zipfile.ZipFile(v3) as z:
 for row in omitted:
  if 'recovery_member' in row:assert hashlib.sha256(z.read(row['recovery_member'])).hexdigest()==row['sha256']
manifest={'schema':1,'scope':'PARTIAL_SOURCE_APP_RESEARCH_EVIDENCE_NOT_RELOCATION_INDEPENDENT','qualified':False,'calibrated':False,'installed_acceptance':False,'native_jobs':1,'payload':{n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in payload.items()},'omitted':omitted,'external_recovery':{'archive':v3.name,'sha256':v3hash,'engine_member':'measured-v3/attempt-1/engine/runtime/ngspice','psp_member':'measured-v3/attempt-1/runtime/psp103.osdi','nqs_member':'measured-v3/attempt-1/runtime/psp103_nqs.osdi','pdk_prefix':'measured-v3/attempt-1/pdk/'},'limitations':['App source and compiler/toolchain are not duplicated; exact local source hashes are in contract and compiler provenance. This archive is not a portable native replay package.','Profile omissions include generated font caches and isolated settings; saved research project, exact managed input, final deck and runtime-lock are included.','Absolute paths retained as original evidence, not promised to exist on another computer.','Attempt-1 interrupted in pre-native Save dialog; external interrupted-preparation receipt retained, zero native jobs. Attempt-2 is sole native job.','Original measured-v3 audit multiplicity failure remains preserved externally; this one-gate pilot does not supersede it.']}
payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode();archive=D/'ihp-pmos-source-app-pilot-evidence-v1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(payload)
 for n,b in payload.items():assert z.read(n)==b
summary={'schema':1,'status':'SOURCE_APP_RESEARCH_PILOT_INDEPENDENTLY_VERIFIED','qualified':False,'calibrated':False,'installed_acceptance':False,'graphical_parameter_acceptance':False,'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'manifest_sha256':hashlib.sha256(payload['manifest.json']).hexdigest(),'payload_count_including_manifest':len(payload),'omitted_count':len(omitted),'points':28,'terminal_values':112,'terminal_values_bitwise_equal_to_v3_reference':True,'kcl_max_normalized':0.18096884913475453,'independent_review_sha256':sha(R/'independent-readback.json'),'contract_sha256':sha(R/'contract.json'),'complete_v3_archive_sha256':v3hash,'scope':'Actual source-app Tools runtime library selection, save/reopen and managed worker; original90s/defaultSparse/unchanged model parameters. Native XDUT statement rather than graphical MOS parameter support. No installed/full calibration claim. Partial bundle with explicit recovery manifest.'}
(D/'chunk7-ihp-pmos-source-app-pilot-2026-11-11.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
