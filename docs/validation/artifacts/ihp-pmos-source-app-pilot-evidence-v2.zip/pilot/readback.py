from pathlib import Path
import json,hashlib,math,re
R=Path(__file__).resolve().parent;out=R/'attempt-2';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();result=json.loads((out/'result.json').read_text());c=json.loads((R/'contract.json').read_text());d=Path(result['job_directory'])
assert result['job_state']=='Complete' and not result['failure'] and not result['errors'] and not result['cleanup_errors'] and all(result['post_identity'].values())
assert all(h(p)==v for p,v in c['bindings'].items())
assert all(h(out/p)==v for p,v in json.loads((out/'files.json').read_text()).items())
job=json.loads((d/'input.json').read_text());rr=json.loads((d/'result.json').read_text());status=json.loads((d/'status.json').read_text());project=json.loads((out/'RESEARCH-project.icproj').read_text())
assert job['project']==project and job['executable']==c['engine'] and rr['engine_hash']==h(c['engine'])
assert status['exit_code']==0 and status['status']=='complete' and job['settings']['timeout']==90 and not job['settings'].get('dc_startup')
assert json.loads((d/'runtime-lock.json').read_text())['osdi']==project['simulation_runtime']['osdi']
assert [h(p) for p in sorted((d/'runtime-osdi').iterdir())]==[h(p) for p in c['modules']]
m=json.loads((d/'pdk-model-files.json').read_text());src=Path('/workspace/shared/ic-design-studio-next2/icstudio/assets/pdks/ihp-sg13g2')
assert set(m)=={str(p.relative_to(d)) for p in (d/'pdk-models').iterdir()}
def normalize(text, staged, source_name):
 lines=[]
 for line in text.splitlines():
  match=re.fullmatch(r'\s*\.include\s+["\']?([^"\'\s]+)["\']?\s*',line,re.I)
  if match:
   target=match[1];target=m[target] if staged else str(Path(source_name).parent/target)
   lines.append('.include '+target)
  else:lines.append(line)
 return lines
for staged,source in m.items():assert normalize((d/staged).read_text(),True,source)==normalize((src/source).read_text(),False,source),source
expected=(R/'preview.cir').read_text().splitlines();corner=next(k for k,v in m.items() if v.endswith('/cornerMOSlv.lib'));expected=[('.lib '+corner+' mos_tt') if x.startswith('.lib ') else x for x in expected];expected[1:1]=['.control','pre_osdi runtime-osdi/model-0.osdi','pre_osdi runtime-osdi/model-1.osdi','.endc'];assert (d/'input.cir').read_text().splitlines()==expected
log=(d/'engine.log').read_text();assert log.count('Using SPARSE 1.3 as Direct Linear Solver')==1 and 'Using KLU' not in log
for line in log.splitlines():
 if re.search(r'error|warning|unknown|failed|fatal',line,re.I):assert line=='Warning: m=xx on .subckt line will override multiplier m hierarchy!',line

def raw(p):
 header,body=p.read_text().split('Values:\n');n=int(re.search(r'No. Variables:\s*(\d+)',header)[1]);assert int(re.search(r'No. Points:\s*(\d+)',header)[1])==28
 names=[line.split()[1] for line in header.split('Variables:\n')[1].splitlines()];assert len(names)==n and len(set(names))==n
 lines=body.strip().splitlines();assert len(lines)==28*n;rows=[]
 for i in range(28):
  first=lines[i*n].split();assert int(first[0])==i;v=[float(first[1])]+[float(x.strip()) for x in lines[i*n+1:(i+1)*n]];assert all(math.isfinite(x) for x in v);assert abs(v[0]+i*.05)<1e-12;rows.append(dict(zip(names,v)))
 return rows
actual=raw(d/'result.raw');refpath=Path('/workspace/shared/ihp-pmos-measured-v3/attempt-1/runs/nominal-3/result.raw');reference=raw(refpath);currents=['i(vd)','i(vg)','i(vs)','i(vb)'];atol=1e-13;rtol=1e-6
kcl=max(abs(sum(row[k] for k in currents))/(atol+rtol*sum(abs(row[k]) for k in currents)) for row in actual)
comparison=max(abs(a[k]-b[k])/(atol+rtol*abs(b[k])) for a,b in zip(actual,reference) for k in currents);assert kcl<=1 and comparison<=1,(kcl,comparison)
for row in actual:assert row['v(g)']==-1.124 and row['v(s)']==row['v(b)']==0
report={'status':'SOURCE_APP_RESEARCH_PILOT_COMPLETE','qualified':False,'calibrated':False,'installed_acceptance':False,'graphical_mos_parameter_acceptance':False,'native_jobs':1,'points':28,'terminal_values':112,'kcl_max_normalized':kcl,'reference_difference_max_normalized':comparison,'terminal_values_bitwise_equal_to_reference':all(a[k].hex()==b[k].hex() for a,b in zip(actual,reference) for k in currents),'worker_elapsed_seconds':status['elapsed'],'staged_pdk_files':len(m),'complete_final_deck_exact':True,'strict_log_check':True,'scope_limit':'Source-app custom project OSDI selection/save/reopen/managed job only. Explicit native XDUT statement, not graphical MOS parameter support. No installed or calibration claim. Runtime identity established by input/result/source/pre-post hashes, not OS exec tracing. Qt prep watchdog is event-loop only; outer180s backstop used.','bindings':{'contract.json':h(R/'contract.json'),'readback.py':h(__file__),'reference_raw':h(refpath),'result.raw':h(d/'result.raw'),'input.cir':h(d/'input.cir'),'runtime-lock.json':h(d/'runtime-lock.json'),'files.json':h(out/'files.json')}}
(R/'readback.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
