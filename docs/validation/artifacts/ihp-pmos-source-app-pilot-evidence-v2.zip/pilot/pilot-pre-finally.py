from pathlib import Path
import os,sys,json,time,hashlib,shutil,math
from unittest.mock import patch
R=Path(__file__).resolve().parent;APP=Path('/workspace/shared/ic-design-studio-next2');sys.path.insert(0,str(APP))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 contract=json.loads((R/'contract.json').read_text());out=R/'attempt-1';out.mkdir(exist_ok=False)
 for p,h in contract['bindings'].items():assert sha(p)==h,p
 os.environ.update(QT_QPA_PLATFORM='offscreen',XDG_DATA_HOME=str(out/'profile/data'),XDG_CONFIG_HOME=str(out/'profile/config'),HOME=str(out/'profile'),OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',LANG='C',LC_ALL='C')
 from PySide6.QtWidgets import QApplication,QPushButton,QFileDialog
 from PySide6.QtTest import QTest
 from icstudio.gui import Studio
 from icstudio.model import load_project,save_project
 from icstudio.osdi import verified,needs_managed_runtime
 from icstudio.mim_desktop_probe import selected_file
 app=QApplication([]);w=Studio(recover=False);errors=[];w.error=lambda text:errors.append(str(text));w.show()
 p=load_project(R/'prepared.icproj');w.set_project(p);w.runtime_dialog()
 with patch.object(QFileDialog,'getOpenFileNames',return_value=(contract['modules'],'')):
  next(b for b in w._runtime_dialog.findChildren(QPushButton) if b.text()=='Select libraries…').click();app.processEvents()
 assert len(verified(w.project))==2 and not needs_managed_runtime(w.project)
 w._runtime_dialog.close();path=out/'RESEARCH-project.icproj'
 with selected_file('getSaveFileName',path):assert w.save(as_new=True)
 before=json.loads(path.read_text());w.close_project()
 with selected_file('getOpenFileName',path):w.open_project()
 app.processEvents();assert w.project==load_project(path)==before
 w.settings.setValue('engine/ngspice',contract['engine']);w.jobs_dir=out/'jobs';w.run_manager.limit=1
 job=w.prepare_simulation(w.project['analysis'],'ngspice');assert job['executable']==contract['engine'] and job['settings']['timeout']==90 and not job['settings'].get('dc_startup')
 row=w.start_job(w.project['analysis'],'ngspice');assert row['job']['executable']==contract['engine'] and row['job']['settings']['timeout']==90 and not row['job']['settings'].get('dc_startup')
 deadline=time.monotonic()+120
 while row['state'] in ('Queued','Running','Stopping') and time.monotonic()<deadline:QTest.qWait(20)
 result={'scope':'SOURCE_APP_RESEARCH_ONLY','qualified':False,'installed_acceptance':False,'calibrated':False,'job_directory':str(row['path']),'job_state':row['state'],'errors':errors,'contract_sha256':sha(R/'contract.json'),'project_sha256':sha(path)}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 assert row['state']=='Complete' and not errors and not row['result'].get('reused_from'),result
 for p,h in contract['bindings'].items():assert sha(p)==h,p
 # Retain final artifact identity; independent reader determines electrical validity.
 (out/'files.json').write_text(json.dumps({str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()},indent=2)+'\n')
 w.project['revision']=w.project.get('revision',0);w.close();app.quit()
if __name__=='__main__':main()
