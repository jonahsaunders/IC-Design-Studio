from pathlib import Path
import json,zipfile,hashlib
D=Path('/workspace/shared/ihp-pmos-source-app-pilot-delivery');N=Path('/workspace/shared/ihp-pmos-source-app-pilot-delivery-v2');N.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();name='ihp-pmos-source-app-pilot-evidence-v1.zip'
with zipfile.ZipFile(D/name) as z:payload={n:z.read(n) for n in z.namelist()}
m=json.loads(payload['manifest.json']);m['external_recovery']['portable_route']={'compact_archive':'docs/qualification/ihp-pmos-measured-reference-v3/evidence-compact.zip','compact_sha256':'1f49b494236845576c7e195a68fa7a36f468e47231d383a86d44ea8ad7010003','base_archive':'packaging/ngspice/ngspice-linux47-corrected-v1.zip','base_sha256':'e74736fd70b2fa6972bb0e0ab77cf87fff38f5926a7cb19d03431c2663e2b714','materializer':'scripts/materialize_ihp_pmos_measured_v3.py','materializer_sha256':'35e1c591c0caef403b3a91872886f3d722a0d557f1456497a9dadb04bf249eb0','argv':['python','scripts/materialize_ihp_pmos_measured_v3.py','docs/qualification/ihp-pmos-measured-reference-v3/evidence-compact.zip','packaging/ngspice/ngspice-linux47-corrected-v1.zip','FRESH_OUTPUT_DIRECTORY'],'reconstructed_manifest_sha256':'8f583f2a0002a17fdb268502e53d269cee73d633fe3aff1a9311f2ead0125a87','scope':'Reconstructs verified same evidence members, not bytes of original full ZIP. Retained full-ZIP SHA is historical archive identity only.'}
payload['packaging-portable-route.py']=Path(__file__).read_bytes();m['payload']['packaging-portable-route.py']={'sha256':sha(payload['packaging-portable-route.py']),'bytes':len(payload['packaging-portable-route.py'])};payload['manifest.json']=(json.dumps(m,indent=2)+'\n').encode()
with zipfile.ZipFile(N/name,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(N/name) as z:
 assert z.testzip() is None and set(z.namelist())==set(payload)
 for n,v in m['payload'].items():assert sha(z.read(n))==v['sha256'] and len(z.read(n))==v['bytes']
s=json.loads((D/'chunk7-ihp-pmos-source-app-pilot-2026-11-11.json').read_text());s.update(archive_sha256=sha((N/name).read_bytes()),archive_bytes=(N/name).stat().st_size,manifest_sha256=sha(payload['manifest.json']),payload_count_including_manifest=len(payload),portable_recovery=m['external_recovery']['portable_route']);(N/'chunk7-ihp-pmos-source-app-pilot-2026-11-11.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:s[k] for k in ['archive_sha256','archive_bytes','manifest_sha256','payload_count_including_manifest']},indent=2))
