# Optional corner-safe IHP resistor guard routing

For `rsil`, `rppd` or `rhigh`, set W/L to **2/7 µm**, then choose:

- Resistor terminal access: **Metal1**
- Body guard routing: **Corner-safe Metal2 body (2/7 um only)**

The default remains the existing native Metal1 body. The new option is a
separate corrected routing recipe, not unchanged native PDK masks. It adds
0.25 µm² of Metal2 at the guard corners and redistributes the vertical via
rows, changing 56 guard vias to 54. The three device models, horizontal vias,
contacts, resistor geometry and all other masks are unchanged. The body
access is Metal2; both resistor terminals remain Metal1.

Only the three exact 2/7 µm templates are supported. Other dimensions,
multiplicity/bend options or simultaneous Metal2 resistor-terminal access
are rejected. Changing the option or dimensions marks a linked footprint
stale; use regeneration/ECO and check connections. Existing routes and top
port labels stay at their coordinates when regenerating, so changing body
access can require moving/reassigning the body port and reconnecting routes.

Templates preserve the authenticated local native experiment's source,
contract, model, mask and tool identities. Original native all-side 100%
corner DRC failures remain recorded separately. The corrected profile passed
42 rotated layouts and 105 fault controls before app integration; those are
geometric source results, not installed-app acceptance or full-family signoff.

Source GUI lifecycle and backend transfer tests are additional checks. The
existing installed acceptance probe does **not** yet exercise this new option;
a new exact installed candidate and supported probe are still required.
