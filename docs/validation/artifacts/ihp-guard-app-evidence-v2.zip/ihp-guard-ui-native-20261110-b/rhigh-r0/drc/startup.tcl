tech load "/workspace/shared/ihp-guard-ui-probe-20261110-d/profile/9/pdks/ihp-sg13g2@cfb96b74cf33877e/libs.tech/magic/icstudio-ihp-sg13g2.tech"
drc euclidean on
