from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/workspace/shared/ic-design-studio-next2-diagnostics-v3-checks')
original=Path('/workspace/shared/next2-diagnostics-v3-feedback-20261110')
out=Path('/workspace/shared/next2-diagnostics-continuation-20261110');out.mkdir()
sys.path.insert(0,str(root))
from scripts import ci_feedback as ci
before=json.loads((original/'source-before.json').read_text())
prior=json.loads((original/'run/report.json').read_text())
assert before==prior['source_files_sha256']==ci.source_identity(root)
assert prior['status']=='running' and len(prior['stages'])==12
selected=ci.stages(out/'run')
assert [s['name'] for s in prior['stages']]==[n for n,_ in selected[:12]]
assert all(s['returncode']==0 for s in prior['stages'])
(out/'run').mkdir()
report={'schema':1,'status':'running','scope':'Same-source selected stage coverage across interrupted run and bounded continuation; not an uninterrupted framework run or installed acceptance.','installed_acceptance':False,'original_report_sha256':hashlib.sha256((original/'run/report.json').read_bytes()).hexdigest(),'original_completed_stages':prior['stages'],'source_files_sha256':before,'continuation_stages':[],'interruption':'Execution-service session recovery disconnected after 12 completed stages. Original running report and partial stage13 output preserved unchanged.'}
start=time.monotonic(); env={k:v for k,v in os.environ.items() if not k.upper().startswith('GIT_')};env.update(QT_QPA_PLATFORM='offscreen',PYTHONPATH=str(root/'tests'),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
def save():
 report['elapsed_seconds']=time.monotonic()-start
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 for name,command in selected[12:]:
  t=time.monotonic()
  with (out/'run'/f'{name}.log').open('wb') as log:
   process=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  record={'name':name,'command':command,'returncode':process.returncode,'elapsed_seconds':time.monotonic()-t};report['continuation_stages'].append(record);save()
  assert process.returncode==0,name
  if name=='ihp-guard-corner-smoke':
   readback=ci.check_ihp_guard_gui_output(out/'run/ihp-guard-corner',command[command.index('--execution-id')+1])
   (out/'run/ihp-guard-corner-readback.json').write_text(json.dumps(readback,indent=2)+'\n')
 after=ci.source_identity(root);live=ci.source_identity(Path('/workspace/shared/ic-design-studio-next2'))
 report['snapshot_unchanged']=after==before;report['live_source_unchanged']=live==before
 assert after==live==before
 assert len(prior['stages'])+len(report['continuation_stages'])==14
 report['status']='PASS_SELECTED_STAGES_WITH_EXPLICIT_CONTINUATION'
except BaseException as exc:
 report['status']='FAILED_CONTINUATION';report['error']=repr(exc);raise
finally:
 save(); print(json.dumps({k:v for k,v in report.items() if k not in ('source_files_sha256','original_completed_stages')},indent=2),flush=True)
