from pathlib import Path
import json, hashlib, subprocess, sys, os, time
src=Path('/workspace/shared/ic-design-studio-next2')
dst=Path('/workspace/shared/ic-design-studio-next2-diagnostics-v3-checks')
proof=Path('/workspace/shared/next2-diagnostics-v3-feedback-20261110')
proof.mkdir()
sys.path.insert(0,str(src))
from scripts.ci_feedback import source_identity
sha='eb0018c9c024588358b3f4f12f0af6a0581da937'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=dst,text=True).strip()==sha
assert not subprocess.check_output(['git','status','--porcelain'],cwd=dst)
before=source_identity(src)
(proof/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
names=set(before)
for args in (['git','diff','--name-only'],['git','ls-files','--others','--exclude-standard']):
    names.update(subprocess.check_output(args,cwd=src,text=True).splitlines())
files={}
for name in sorted(names):
    p=src/name; assert p.is_file() and not p.is_symlink(), name
    b=p.read_bytes(); q=dst/name; q.parent.mkdir(parents=True,exist_ok=True); q.write_bytes(b)
    assert q.read_bytes()==b
    files[name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
assert source_identity(src)==before==source_identity(dst)
(proof/'copy-manifest.json').write_text(json.dumps({'base_commit':sha,'source':str(src),'snapshot':str(dst),'source_identity_count':len(before),'files':files},indent=2)+'\n')
command=[sys.executable,str(dst/'scripts/ci_feedback.py'),'--output',str(proof/'run')]
start=time.monotonic()
with (proof/'launcher.log').open('wb') as log:
    child=subprocess.run(command,cwd=dst,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
after=source_identity(src); snapshot=source_identity(dst)
(proof/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
(proof/'snapshot-after.json').write_text(json.dumps(snapshot,indent=2)+'\n')
copy_ok=all((dst/n).is_file() and hashlib.sha256((dst/n).read_bytes()).hexdigest()==v['sha256'] for n,v in files.items())
report=json.loads((proof/'run/report.json').read_text())
result={'command':command,'cwd':str(dst),'returncode':child.returncode,'process_seconds':time.monotonic()-start,'source_identity_count':len(before),'source_unchanged':after==before,'snapshot_unchanged':snapshot==before,'all_copied_paths_unchanged':copy_ok,'report_identities_match':report['source_files_sha256']==before,'report_status':report['status']}
(proof/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
assert child.returncode==0 and after==before==snapshot==report['source_files_sha256'] and copy_ok and report['status']=='passed'
