LI array dynamic compact retained evidence

This is intentionally PARTIAL. It contains all 30 native result.raw/input.cir/circuit.spice/console.log sets, final run/audit/contract/recovery records, exact frozen sources and selected historical originals/layouts/receipts. It omits authenticated duplicate engine and historical package/model trees. BUNDLE-MANIFEST.json records every included and omitted member SHA256/size and its precise recovery source.

Do not run the unchanged full auditor against this partial tree and treat missing inputs as waived. It requires the original downloaded historical ZIP, complete runtime/model closure, original absolute execution context and Linux dependencies. No relocation-independent replay, fresh physical extraction, installed acceptance or full-family qualification is asserted.

The original 28.6 MB full evidence ZIP remains unchanged locally, SHA256 acbf6656cb2ea261f585031a66f74e3b4b67de4452370b1a766866a933376bce.

All standalone licenses, COPYING/copyright notices and modification notices from the full evidence ZIP are retained in this compact bundle, even for omitted binaries. Complete upstream source and embedded component notices remain recoverable from the authenticated source archives.
