from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
R=Path('/workspace/shared/ihp-pmos-mna-capture');sys.path.insert(0,str(R));from analyze import parse,value
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=json.loads((R/'capture-run/on/run.json').read_text());report=json.loads((R/'captured-analysis.json').read_text());root=R/'capture-run/on'
for group in ['input_hashes','outputs']:
 for p,s in run[group].items():assert h(root/p)==s
c=json.loads((R/'run-contract.json').read_text())
for p,s in c['bindings'].items():assert h(Path(p))==s
assert run['timed_out'] and run['post_identity_pass']; assert b'Values:' not in (root/'result.raw').read_bytes()
checks=[];solutions=[]
for snap,rep in zip(parse(root/'console.log'),report['snapshots']):
 ids=sorted(snap['node_names']);n=len(ids);idx={v:i for i,v in enumerate(ids)};A=[[F(0) for _ in ids] for _ in ids];b=[snap['vectors'][i][0] for i in ids]
 for _,_,er,ec,bits in snap['entries']:A[idx[er]][idx[ec]]=value(bits)
 # Independent unnormalized forward elimination followed by back substitution.
 M=[row[:]+[v] for row,v in zip(A,b)]
 for k in range(n):
  p=next(i for i in range(k,n) if M[i][k]);M[k],M[p]=M[p],M[k]
  for i in range(k+1,n):
   q=M[i][k]/M[k][k]
   for j in range(k,n+1):M[i][j]-=q*M[k][j]
 x=[F(0)]*n
 for i in range(n-1,-1,-1):x[i]=(M[i][n]-sum(M[i][j]*x[j] for j in range(i+1,n)))/M[i][i]
 assert all(sum(a*y for a,y in zip(row,x))==v for row,v in zip(A,b))
 for i,row in enumerate(rep['rows']):
  assert row['external_id']==ids[i] and F(row['exact_solution'])==x[i]
  native=[snap['vectors'][j][2] for j in ids]
  residual=sum(a*y for a,y in zip(A[i],native))-b[i]
  assert F(row['assembled_residual'])==residual
  assert row['nearest_exact_hex']==float(x[i]).hex()
 solutions.append((snap,ids,x));checks.append({'iteration':snap['iteration'],'rank':n,'entries':len(snap['entries']),'exact_solutions_and_residuals_match':True})
for entry in report['delta_decomposition']:
 k=solutions[0][1].index(entry['external_id']);a,bb=solutions
 delta=bb[2][k]-a[2][k];native=bb[0]['vectors'][entry['external_id']][2]-a[0]['vectors'][entry['external_id']][2]
 assert F(entry['exact_system_solution_delta'])==delta and F(entry['native_delta'])==native and F(entry['solve_error_delta'])==native-delta
out={'status':'INDEPENDENT_EXACT_READBACK_PASS','native_runs_by_reviewer':0,'timeout_seconds':run['seconds'],'snapshots':checks,'bindings':{x:h(R/x) for x in ['captured-analysis.json','capture-run/on/run.json','capture-run/on/console.log','capture-run/on/result.raw']},'method':'Independent unnormalized rational forward elimination/back substitution, exact A*x=b and all retained native residuals/delta decompositions checked. Original parser separately reviewed.','finding':'Both assembled systems differ, and Sparse solution errors also differ. This is not evidence of a Sparse-only cause. Exact-system GP rounds to the same binary64 value in both; sampled native GP differs. No full sweep or convergence acceptance.','scope':'No GP helper status inference, no unique root-cause or proposed fix claim. High-precision crosscheck code reviewed; its runs not repeated because independent exact rational solve is stronger here.'}
(R/'independent-captured-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));print('SHA',h(R/'independent-captured-review.json'))
