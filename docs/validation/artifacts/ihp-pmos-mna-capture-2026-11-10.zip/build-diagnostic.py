from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).parent;old=Path('/workspace/shared/ihp-psp-engine-investigation');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();c=json.loads((old/'build-contract.json').read_text());env=c['environment'];src=r/'source';manifest=json.loads((r/'source-manifest.json').read_text())
def filemap(p):return {x.relative_to(p).as_posix():sha(x) for x in p.rglob('*') if x.is_file()}
assert sha(old/'build-contract.json')=='9ae0a95ae4d0b2f1cbfbc3b37f62f7ea2d712b8f7ef48899626c85367b1ba9b2'
assert filemap(src)==manifest
for p,v in c['toolchain'].items():
 assert sha(p)==v['sha256']
 for name,h in v['dependencies'].items():assert sha(name)==h
b=r/'build';b.mkdir();rec={'qualified':False,'status':'building','instrumentation_sha256':sha(r/'instrumentation.patch'),'source_manifest_sha256':sha(r/'source-manifest.json'),'parent_build_contract_sha256':sha(old/'build-contract.json'),'environment':env,'commands':[]}
commands=[[str(src/'configure'),'--prefix='+str(old/'install'),*c['configure_options']],['make','-j4']]
try:
 for i,cmd in enumerate(commands):
  start=time.monotonic()
  with (b/f'stage-{i}.log').open('wb') as f:p=subprocess.run(cmd,cwd=b,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
  rec['commands'].append(dict(command=cmd,returncode=p.returncode,seconds=time.monotonic()-start,log_sha256=sha(b/f'stage-{i}.log')));assert p.returncode==0
 assert filemap(src)==manifest
 exe=b/'src/ngspice';rec['executable_sha256']=sha(exe);config=(b/'src/include/ngspice/config.h').read_text();rec['features']={k:('#define '+k+' ') in config for k in ['OSDI','XSPICE','KLU','PREDICTOR']};assert all(rec['features'].values())
 p=subprocess.run(['ldd',str(exe)],env=env,capture_output=True,text=True,timeout=10);assert p.returncode==0 and 'not found' not in p.stdout+p.stderr;(b/'ldd.log').write_text(p.stdout+p.stderr)
 rec['dependencies']={s:sha(s) for line in p.stdout.splitlines() for s in line.split() if s.startswith('/') and Path(s).is_file()};assert rec['dependencies']==json.loads((old/'build-baseline/receipt.json').read_text())['dependencies']
 rec['status']='built-not-executed'
except BaseException as e:rec['status']='failed';rec['error']=repr(e);raise
finally:(b/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
print(rec['status'],rec['executable_sha256'])
