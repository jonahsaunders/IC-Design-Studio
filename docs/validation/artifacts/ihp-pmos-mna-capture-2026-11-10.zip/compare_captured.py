from pathlib import Path
from fractions import Fraction as F
import json,hashlib,mpmath as mp
from analyze import parse,analyze,value,solve
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 run=json.loads((R/'capture-run/on/run.json').read_text());assert 'seconds' in run and run['post_identity_pass']
 log=R/'capture-run/on/console.log';cs=parse(log);reports=[analyze(c) for c in cs]
 def matrix(c):return {(er,ec):value(bits) for ir,ic,er,ec,bits in c['entries']}
 a,b=map(matrix,cs);adelta=[dict(row=k[0],col=k[1],before=str(a.get(k,F())),after=str(b.get(k,F())),delta=str(b.get(k,F())-a.get(k,F()))) for k in sorted(a.keys()|b.keys()) if a.get(k,F())!=b.get(k,F())]
 bdelta=[dict(external_id=i,name=cs[0]['node_names'].get(i),before=str(cs[0]['vectors'][i][0]),after=str(cs[1]['vectors'][i][0]),delta=str(cs[1]['vectors'][i][0]-cs[0]['vectors'][i][0])) for i in cs[0]['vectors'] if cs[0]['vectors'][i][0]!=cs[1]['vectors'][i][0]]
 cross=[]
 for c in cs:
  ids=sorted(c['node_names']);mat=matrix(c);A=[[mat.get((i,j),F()) for j in ids] for i in ids];rhs=[c['vectors'][i][0] for i in ids];exact=solve(A,rhs);assert exact['status']=='unique'
  for precision in [80,160]:
   with mp.workdps(precision):
    cv=lambda x:mp.mpf(x.numerator)/x.denominator
    x=mp.lu_solve(mp.matrix([[cv(v) for v in row] for row in A]),mp.matrix([cv(v) for v in rhs]));errors=[]
    for m,v in zip(x,exact['x']):
     sign,man,exp,_=m._mpf_;rat=F((-1 if sign else 1)*man)*F(2)**exp;errors.append(abs(rat-v))
    cross.append(dict(iteration=c['iteration'],decimal_precision=precision,max_absolute_error_vs_exact=str(max(errors)),max_error_decimal=mp.nstr(cv(max(errors)),10)))
 decomposition=[]
 for ra,rb in zip(reports[0]['rows'],reports[1]['rows']):
  assert ra['external_id']==rb['external_id']
  exact_delta=F(rb['exact_solution'])-F(ra['exact_solution']);native_delta=F(rb['native'])-F(ra['native']);error_delta=F(rb['native_minus_exact'])-F(ra['native_minus_exact']);assert native_delta==exact_delta+error_delta
  decomposition.append(dict(external_id=ra['external_id'],name=ra['node_name'],native_delta=str(native_delta),exact_system_solution_delta=str(exact_delta),solve_error_delta=str(error_delta)))
 result=dict(status='EXACT_CAPTURED_SYSTEMS_SOLVED',run_sha256=sha(R/'capture-run/on/run.json'),log_sha256=sha(log),source_analyzer_sha256=sha(R/'analyze.py'),comparison_sha256=sha(Path(__file__)),snapshots=reports,delta_decomposition=decomposition,matrix_changes=adelta,rhs_changes=bdelta,high_precision_crosschecks=cross,qualified=False,interpretation=['Both rounded assembled systems have unique exact solutions. They are not identical systems.','GP-row assembled RHS changes materially relative to current tolerance; this is not explained merely by externalG final-RHS helper non-engagement.','Returned Sparse solution differs from each exact-system solution; nearest exact GP is same binary64 in both captures, while actual Sparse GP flips at iteration99.','This separates observed assembly/state-dependent differences and factor/solve rounding error, but does not identify GP helper fallback or a unique model/compiler/solver defect.','No settings/model changes or further native runs are authorized by this analysis.'])
 (R/'captured-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(sha(R/'captured-analysis.json'))
if __name__=='__main__':main()
