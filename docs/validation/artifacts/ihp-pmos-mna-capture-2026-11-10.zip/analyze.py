"""Read-only exact arithmetic on retained binary64 Sparse snapshots."""
from pathlib import Path
from fractions import Fraction as F
import struct,re,math,json
HEX=re.compile(r'[0-9a-f]{16}')
def value(bits):
 x=struct.unpack('>d',int(bits).to_bytes(8,'big'))[0]
 if not math.isfinite(x):raise ValueError('nonfinite snapshot')
 return F(x)
def parse(path):
 snapshots=[];current=None;factor={};total=0;lines=0;names={99:{},100:{}};last_factor_id=0
 for raw in Path(path).read_bytes().splitlines(keepends=True):
  match=re.match(rb'ICEQ unknown call=1 iter=(99|100) .* node=(\d+) name=(\S+) type=(\d+) old=(\S+) new=(\S+)',raw)
  if match:
   it,id=int(match[1]),int(match[2]);entry=(match[3].decode('ascii'),int(match[4]),F(float(match[5])));assert id not in names[it];names[it][id]=entry
  if not raw.startswith(b'ICMNA'):continue
  assert raw.endswith(b'\n'),'truncated capture';total+=len(raw);lines+=1;assert total<=262144 and lines<=4096
  tokens=raw.decode('ascii').rstrip('\n').split(' ');assert len(tokens)>=3 and tokens[0]=='ICMNA' and all(HEX.fullmatch(x) for x in tokens[2:])
  kind=tokens[1];v=[int(x,16) for x in tokens[2:]]
  if kind=='FACTOR':
   assert len(v)==5 and v[0] not in factor and v[0]>last_factor_id and 1<=v[0]<=4 and len(factor)<4;last_factor_id=v[0];factor[v[0]]=v
  elif kind=='BEGIN':
   assert current is None and len(v)==10
   id,call,it,mode,n,ne,maximum,route,gmin,status=v
   assert call==1 and it in [99,100] and 1<=n<=32 and ne<=512 and maximum<=64 and route in (0,1) and status==0
   assert factor.get(id)==[id,call,it,0,1]
   current=dict(id=id,call=call,iteration=it,mode=mode,n=n,ne=ne,maximum=maximum,route=route,gmin=value(gmin),maps={},entries=[],vectors={})
  elif kind=='MAP':
   assert current is not None and len(v)==4 and v[0]==current['id'];_,i,r,c=v;assert i not in current['maps'] and 1<=i<=current['n'];current['maps'][i]=(r,c)
  elif kind=='A':
   assert current is not None and len(v)==6 and v[0]==current['id'];current['entries'].append(v[1:])
  elif kind=='V':
   assert current is not None and len(v)==5 and v[0]==current['id'];_,i,b,old,x=v;assert i not in current['vectors'];current['vectors'][i]=(value(b),value(old),value(x))
  elif kind=='END':
   assert current is not None and v==[current['id'],current['ne']]
   c=current;assert set(c['maps'])==set(range(1,c['n']+1));rs=[x[0] for x in c['maps'].values()];cs=[x[1] for x in c['maps'].values()]
   assert len(set(rs))==len(rs) and set(rs)==set(cs) and min(rs)>0 and max(rs)==c['maximum']
   assert set(c['vectors'])==set(range(c['maximum']+1)) and len(c['entries'])==c['ne'];seen=set()
   for ir,ic,er,ec,bits in c['entries']:
    assert ir in c['maps'] and ic in c['maps'] and c['maps'][ir][0]==er and c['maps'][ic][1]==ec
    assert (er,ec) not in seen;seen.add((er,ec));value(bits)
   snapshots.append(c);assert len(snapshots)<=4;current=None
  else:raise ValueError('invalid/unsupported capture '+kind)
 assert current is None,'unfinished snapshot'
 assert len({c['id'] for c in snapshots})==len(snapshots)
 assert {k for k,v in factor.items() if v[3]==0 and v[4]==1}=={c['id'] for c in snapshots},'unpaired successful factor'
 assert len(snapshots)==2 and [c['iteration'] for c in snapshots]==[99,100],'missing selected systems'
 for c in snapshots:
  needed={x[0] for x in c['maps'].values()};nm=names[c['iteration']]
  assert needed<=set(nm) and len({nm[i][0] for i in needed})==len(needed),'missing or ambiguous external node names'
  assert all(c['vectors'][i][1]==nm[i][2] for i in needed),'ICEQ old vector differs'
  c['node_names']={i:nm[i][:2] for i in needed}
 assert snapshots[0]['node_names']==snapshots[1]['node_names'],'node identity changed'
 return snapshots

def solve(A,b):
 n=len(b);a=[list(row)+[v] for row,v in zip(A,b)];piv=[];r=0
 for col in range(n):
  p=next((i for i in range(r,n) if a[i][col]),None)
  if p is None:continue
  a[r],a[p]=a[p],a[r];q=a[r][col];a[r]=[x/q for x in a[r]]
  for i in range(n):
   if i!=r and a[i][col]:q=a[i][col];a[i]=[x-q*y for x,y in zip(a[i],a[r])]
  piv.append(col);r+=1
 if any(not any(row[:n]) and row[n] for row in a):return dict(status='inconsistent',rank=r)
 if r<n:return dict(status='singular',rank=r)
 x=[F()]*n
 for i,col in enumerate(piv):x[col]=a[i][n]
 assert all(sum((aij*xj for aij,xj in zip(row,x)),F())==v for row,v in zip(A,b))
 return dict(status='unique',rank=r,x=x)

def analyze(c):
 ids=sorted({x[0] for x in c['maps'].values()});index={id:i for i,id in enumerate(ids)};n=len(ids);A=[[F()]*n for _ in ids]
 for ir,ic,er,ec,bits in c['entries']:A[index[er]][index[ec]]=value(bits)
 b=[c['vectors'][i][0] for i in ids];native=[c['vectors'][i][2] for i in ids];r=solve(A,b)
 if r['status']!='unique':return dict(iteration=c['iteration'],**r)
 x=r.pop('x');out=[]
 try:
  rounded=[float(v) for v in x]
 except OverflowError:return dict(iteration=c['iteration'],status='unsupported_binary64_solution_overflow',rank=n)
 if not all(math.isfinite(v) for v in rounded):return dict(iteration=c['iteration'],status='unsupported_binary64_solution_overflow',rank=n)
 for k,id in enumerate(ids):
  residual=sum((a*v for a,v in zip(A[k],native)),F())-b[k];den=abs(b[k])+sum((abs(a)*abs(v) for a,v in zip(A[k],native)),F())
  out.append(dict(external_id=id,node_name=c['node_names'][id][0],node_type=c['node_names'][id][1],exact_solution=str(x[k]),native=str(native[k]),native_hex=float(native[k]).hex(),nearest_exact_hex=float(x[k]).hex(),native_minus_exact=str(native[k]-x[k]),assembled_residual=str(residual),componentwise_backward_error=str(abs(residual)/den) if den else ('0' if residual==0 else 'undefined_nonzero_over_zero')))
 return dict(iteration=c['iteration'],status='unique',rank=n,rows=out,scope='Exact solution of captured rounded A,b only; no model accuracy or next-iteration convergence claim')
if __name__=='__main__':
 import sys
 print(json.dumps([analyze(c) for c in parse(sys.argv[1])],indent=2))
