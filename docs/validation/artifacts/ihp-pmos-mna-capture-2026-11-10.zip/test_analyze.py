import unittest,tempfile,struct
from pathlib import Path
from fractions import Fraction as F
from analyze import solve,parse,analyze
bits=lambda x:int.from_bytes(struct.pack('>d',x),'big')
def line(kind,*v):return 'ICMNA '+kind+''.join(' %016x'%x for x in v)+'\n'
def capture(it,id):
 s=line('FACTOR',id,1,it,0,1)+line('BEGIN',id,1,it,1088,2,4,5,0,bits(0),0)
 s+=line('MAP',id,1,5,2)+line('MAP',id,2,2,5)
 for ir,ic,er,ec,x in [(1,1,5,2,1.),(1,2,5,5,2.),(2,1,2,2,3.),(2,2,2,5,1.)]:s+=line('A',id,ir,ic,er,ec,bits(x))
 for i in range(6):s+=line('V',id,i,bits(5. if i in [2,5] else 0.),bits(0.),bits({2:1.,5:2.}.get(i,0.)))
 return s+line('END',id,4)+f'ICEQ unknown call=1 iter={it} mode=1088 node=2 name=g type=3 old=0 new=1\nICEQ unknown call=1 iter={it} mode=1088 node=5 name=gp type=3 old=0 new=2\n'
class Tests(unittest.TestCase):
 def test_known_noncontiguous_permuted(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'log';p.write_text(capture(99,1)+capture(100,2));c=parse(p);r=analyze(c[0]);self.assertEqual([x['exact_solution'] for x in r['rows']],['1','2']);self.assertTrue(all(x['assembled_residual']=='0' for x in r['rows']))
 def test_singular(self):self.assertEqual(solve([[F(1),F(2)],[F(2),F(4)]],[F(1),F(2)])['status'],'singular')
 def test_inconsistent(self):self.assertEqual(solve([[F(1),F(2)],[F(2),F(4)]],[F(1),F(3)])['status'],'inconsistent')
 def test_truncation(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'log';p.write_text(capture(99,1)+capture(100,2).split('ICMNA END')[0]);self.assertRaises(AssertionError,parse,p)
 def test_failed_factor(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'log';p.write_text((capture(99,1)+capture(100,2)).replace(line('FACTOR',1,1,99,0,1),line('FACTOR',1,1,99,1,1)));self.assertRaises(AssertionError,parse,p)
 def test_wrong_old_vector(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'log';p.write_text((capture(99,1)+capture(100,2)).replace('old=0 new=1','old=1 new=1'));self.assertRaises(AssertionError,parse,p)
 def test_missing_names(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'log';p.write_text(''.join(x+'\n' for x in (capture(99,1)+capture(100,2)).splitlines() if not x.startswith('ICEQ')));self.assertRaises(AssertionError,parse,p)
 def test_unpaired_success(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'log';p.write_text(capture(99,1)+capture(100,2)+line('FACTOR',3,1,100,0,1));self.assertRaises(AssertionError,parse,p)
 def test_overflow_explicit(self):
  c={'iteration':99,'maps':{1:(2,2)},'vectors':{2:(F(1e308),F(),F())},'entries':[(1,1,2,2,bits(1e-300))],'node_names':{2:('g',3)}}
  self.assertEqual(analyze(c)['status'],'unsupported_binary64_solution_overflow')
if __name__=='__main__':unittest.main()
