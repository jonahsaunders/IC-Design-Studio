"""One offline iterative-refinement arithmetic experiment on each retained system.
Exact residual is an oracle, not an implemented simulator residual routine.
"""
from pathlib import Path
from fractions import Fraction as F
import json,copy,sys
from replay_sparse import replay
from analyze import parse,value,analyze
R=Path(__file__).resolve().parent
cs=parse('/workspace/shared/ihp-pmos-mna-capture/capture-run/on/console.log');reports=[]
for c in cs:
 native=replay(c);A={(er,ec):value(bits) for ir,ic,er,ec,bits in c['entries']};ids=sorted(native)
 residual={i:c['vectors'][i][0]-sum((A.get((i,j),F())*F(native[j]) for j in ids),F()) for i in ids}
 corr=copy.deepcopy(c)
 for i in ids:b,old,x=corr['vectors'][i];corr['vectors'][i]=(F(float(residual[i])),old,x)
 delta=replay(corr);refined={i:native[i]+delta[i] for i in ids}
 exact={r['external_id']:F(r['exact_solution']) for r in analyze(c)['rows']}
 reports.append(dict(iteration=c['iteration'],rows=[dict(id=i,name=c['node_names'][i][0],native=native[i].hex(),refined=refined[i].hex(),nearest_exact=float(exact[i]).hex(),refined_error=str(F(refined[i])-exact[i])) for i in ids]))
(R/'offline-refinement.json').write_text(json.dumps(dict(status='OFFLINE_ONE_STEP_EXACT_RESIDUAL_ORACLE_EXPERIMENT',reports=reports,limitations=['No native execution/solver change','Exact Fraction residual is not yet deployable native algorithm','Assembly differences remain; refined solutions of different systems need not converge']),indent=2)+'\n')
for r in reports:print(r['iteration'],[(x['name'],x['refined'],x['nearest_exact']) for x in r['rows'] if x['name'] in ['vg#branch','n.xdut.nsg13_lv_pmos#GP']])
