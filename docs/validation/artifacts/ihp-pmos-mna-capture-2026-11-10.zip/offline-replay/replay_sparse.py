"""Offline source-derived fixed-order Sparse factor/solve replay, no simulator run.
Closed captured structure required; follows separate binary64 mul/sub operations.
"""
from pathlib import Path
import sys,json,hashlib
from fractions import Fraction as F
sys.path.insert(0,'/workspace/shared/ihp-pmos-mna-capture')
from analyze import parse,value
R=Path(__file__).resolve().parent

def replay(c,convert=float):
 n=c['n'];a={(ir,ic):convert(value(bits)) for ir,ic,er,ec,bits in c['entries']}
 columns={j:[ir for ir,ic,er,ec,bits in c['entries'] if ic==j] for j in range(1,n+1)}
 assert all(v==sorted(set(v)) for v in columns.values())
 assert all((i,i) in a for i in range(1,n+1))
 a[1,1]=convert(1)/a[1,1]
 for step in range(2,n+1):
  for row in columns[step]:
   if row>=step:break
   a[row,step]=a[row,step]*a[row,row]
   multiplier=a[row,step]
   for lower in columns[row]:
    if lower<=row:continue
    assert (lower,step) in a,'captured structural fill closure missing'
    a[lower,step]=a[lower,step]-multiplier*a[lower,row]
  assert a[step,step]!=0;a[step,step]=convert(1)/a[step,step]
 x={i:convert(c['vectors'][c['maps'][i][0]][0]) for i in range(1,n+1)}
 for i in range(1,n+1):
  temp=x[i]
  if temp!=0:
   temp=temp*a[i,i];x[i]=temp
   for row in columns[i]:
    if row>i:x[row]=x[row]-temp*a[row,i]
 for i in range(n,0,-1):
  temp=x[i]
  for col in range(i+1,n+1):
   if (i,col) in a:temp=temp-a[i,col]*x[col]
  x[i]=temp
 return {c['maps'][i][1]:v for i,v in x.items()}

def main():
 path=Path('/workspace/shared/ihp-pmos-mna-capture/capture-run/on/console.log');cs=parse(path);reports=[]
 for c in cs:
  f=replay(c);exact=replay(c,F);rows=[]
  for id in sorted(f):
   native=float(c['vectors'][id][2]);rows.append(dict(id=id,name=c['node_names'][id][0],native_hex=native.hex(),replay_hex=f[id].hex(),match=native.hex()==f[id].hex(),exact_fixed_order=str(exact[id])))
  reports.append(dict(iteration=c['iteration'],all_native_bits_match=all(x['match'] for x in rows),rows=rows))
 result=dict(status='OFFLINE_SOURCE_DERIVED_FIXED_ORDER_REPLAY',log_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),reports=reports,limitations=['No simulator/native model run','Captured topology/order is closed; no repivot/fill insertion is attempted','Direct/indirect factor branches use same scalar product/update sequence for this closed pattern; exact runtime branch flags were not captured','Only these two systems; no future conditioning guarantee'])
 (R/'replay-result.json').write_text(json.dumps(result,indent=2)+'\n');print([(r['iteration'],r['all_native_bits_match']) for r in reports])
if __name__=='__main__':main()
