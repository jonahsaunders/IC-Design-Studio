"""Completed final transport SOURCE lane only. Does not run tests/native jobs."""
from pathlib import Path
import hashlib,json,re,zipfile
R=Path('/workspace/shared');OUT=R/'chunk7-wsl-transport-validation-package';LANE=R/'chunk7-wsl-transport-source-20261111';SNAP=R/'ic-design-studio-wsl-transport-source-checks'
def H(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def J(p):return json.loads(Path(p).read_bytes())
def need(x,m):
 if not x:raise ValueError(m)
def main():
 launch=J(LANE/'launcher-report.json');need(launch['status']=='passed' and launch['returncode']==0,'Refuse provisional/nonpass lane')
 before=J(LANE/'source-before.json');need(before==J(LANE/'source-after.json')==J(LANE/'snapshot-after.json'),'Lane mutation');need(len(before)==launch['source_identity_count']==2547,'Identity count')
 need(launch['source_unchanged'] and launch['snapshot_unchanged'] and launch['all_copied_files_unchanged'],'Launcher guards');need(H(LANE/'console.log')==launch['console_sha256'],'Console changed');need(H(LANE/'launcher.py')==launch['launcher_source_sha256']=='9db3ffe59e8675e17e897d9ca344dde97371b391d007cd1ad457f8da8f89f4a2','Prelaunch driver identity')
 copied=J(LANE/'snapshot-manifest.json')['files']
 for n,v in copied.items():
  if v=={'deleted':True}:need(not(SNAP/n).exists(),'Deleted path reappeared');continue
  need(H(SNAP/n)==v['sha256'] and (SNAP/n).stat().st_size==v['bytes'],'Copied bytes differ')
 for n,h in before.items():need(H(SNAP/n)==h,'Snapshot source changed')
 oldpath=R/'chunk7-wsl-final-source-20261111/source-before.json';old=J(oldpath);reviewpath=R/'ihp-wsl-payload-transport-review/integrated-validation.json';review=J(reviewpath);changed={n for n in old.keys()|before.keys() if old.get(n)!=before.get(n)}
 need(changed==set(review['files']) and len(changed)==15,'Unreviewed delta');need(all(before[n]==h for n,h in review['files'].items()),'Reviewed delta bytes differ')
 feedback=J(LANE/'run/report.json');need(feedback['status']=='passed' and not feedback['release_acceptance'] and feedback['source_files_sha256']==before,'Feedback scope/identity');stages=feedback['stages'];need(len(stages)==len({s['name'] for s in stages})==14 and all(s['returncode']==0 for s in stages),'Stage completeness')
 tests=skips=0
 for s in stages:
  text=(LANE/'run'/(s['name']+'.log')).read_text();matches=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s\s*\n\s*OK(?: \(skipped=(\d+)\))?\s*$',text,re.M)
  if re.search(r'^Ran \d+ tests? in ',text,re.M):need(bool(matches),'Unsuccessful test log')
  tests+=sum(int(x[0]) for x in matches);skips+=sum(int(x[2] or 0) for x in matches)
 payload={};omitted=[]
 for p in sorted(LANE.rglob('*')):
  need(not p.is_symlink(),'Linked evidence')
  if not p.is_file():continue
  rel=p.relative_to(LANE);name='source/'+rel.as_posix();keep=len(rel.parts)==1 or (len(rel.parts)==2 and rel.parts[0]=='run' and p.suffix in ('.log','.json')) or p.name in ('report.json','files.json','inventory.json','readback.json')
  if keep:payload[name]=p.read_bytes()
  else:omitted.append({'path':name,'bytes':p.stat().st_size,'sha256':H(p),'reason':'Omitted bulky GUI/project/layout/staging payload, report/inventory retained; not standalone replay'})
 for inventory in (LANE/'run').rglob('files.json'):
  for n,h in J(inventory).items():need((inventory.parent/n).resolve().is_relative_to(inventory.parent.resolve()) and H(inventory.parent/n)==h,'GUI inventory changed')
 for folder in ('menu-audit','project-hub-evidence'):
  for p in (SNAP/'build'/folder).glob('*.json'):payload['gui/'+folder+'/'+p.name]=p.read_bytes()
 for n in sorted(changed):payload['reviewed-delta/'+n]=(SNAP/n).read_bytes()
 payload['delta/integrated-validation.json']=reviewpath.read_bytes();payload['delta/prior-source-before.json']=oldpath.read_bytes()
 evidence=J(OUT/'focused-inputs.json');need(any(n.startswith('independent-10') for n in evidence),'Independent10 evidence not retained yet')
 for n,row in evidence.items():
  p=Path(row['path']);need(H(p)==row['sha256'],'Focused evidence changed');payload['focused/'+n]=p.read_bytes()
 prior=R/'chunk7-wsl-validation-package/chunk7-wsl-source-core-validation-2026-11-11.zip';prior_sha=H(prior);need(prior_sha=='3efc7f172159dc761bd291ec4f4186da3302af7c150ff669507cc4a137e32915','Historical archive identity differs')
 payload['package.py']=Path(__file__).read_bytes();payload['focused-inputs.json']=(OUT/'focused-inputs.json').read_bytes()
 manifest={'schema':1,'scope':'FINAL_TRANSPORT_SOURCE_ONLY_NO_CURRENT_CORE_OR_NATIVE_ACCEPTANCE','installed_acceptance':False,'qualified':False,'files':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in payload.items()},'omitted':omitted,'historical_pretransport':{'archive':prior.name,'sha256':prior_sha,'source_tests':1865,'source_skips':18,'core_tests':4963,'core_skips':81,'identities':2539,'covers_current_transport':False,'retained_prior_failures':'Original focused/environment failures remain in this separately retained archive; not overwritten or duplicated.'},'limitations':['Current evidence is SOURCE lane only. Prior core predates exact15path transport delta and MUST NOT be described as current-transport core acceptance.','No installed/Windows/WSL/native/model execution is established by these tests.','Compact reports/logs/inventories with explicit hashed omissions, not standalone replay.','Source snapshot includes integrated uncommitted changes; basecommit alone is not tested content identity.']}
 payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();archive=OUT/'chunk7-wsl-transport-source-validation-2026-11-11.zip';need(not archive.exists(),'Never overwrite prior archive')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(payload.items()):z.writestr(n,b)
 with zipfile.ZipFile(archive) as z:
  need(z.testzip() is None and set(z.namelist())==set(payload),'Archive structure')
  for n,b in payload.items():need(z.read(n)==b,'Payload readback')
 summary={'schema':1,'status':'FINAL_TRANSPORT_SOURCE_PASS','installed_acceptance':False,'qualified':False,'current_transport_core_run':False,'tests':tests,'skips':skips,'stages':14,'source_identities':2547,'syntax_files':feedback['syntax_files'],'feedback_seconds':feedback['elapsed_seconds'],'launcher_seconds':launch['elapsed_seconds'],'reviewed_changed_paths':15,'affected_focused_tests':review['affected_tests'],'archive':archive.name,'archive_sha256':H(archive),'archive_bytes':archive.stat().st_size,'manifest_sha256':hashlib.sha256(payload['MANIFEST.json']).hexdigest(),'files':len(payload),'omitted_files':len(omitted),'historical_pretransport':manifest['historical_pretransport'],'limitations':manifest['limitations']}
 (OUT/'chunk7-wsl-transport-source-validation-2026-11-11.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
