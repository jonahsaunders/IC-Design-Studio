"""Local validation only. Never publishes or changes qualification thresholds."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time,re,signal
from datetime import datetime,timezone
p=argparse.ArgumentParser();p.add_argument('--lane',choices=('source','core'),required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--snapshot',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True);p.add_argument('--stop-at',required=True);a=p.parse_args()
stop=datetime.fromisoformat(a.stop_at.replace('Z','+00:00'));assert stop.tzinfo is not None
def remaining():return (stop-datetime.now(timezone.utc)).total_seconds()
assert remaining()>0,'User stop boundary already reached'
src=a.source.resolve();dst=a.snapshot.resolve();proof=a.evidence.resolve()
assert not dst.exists() and not proof.exists()
proof.mkdir(parents=True)
launcher_bytes=Path(__file__).read_bytes();(proof/'launcher.py').write_bytes(launcher_bytes)
sys.path.insert(0,str(src));from scripts.ci_feedback import source_identity
sha=lambda b:hashlib.sha256(b).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()
with (proof/'snapshot-checkout.log').open('wb') as log:
 subprocess.run(['git','worktree','add','--detach',str(dst),base],cwd=src,stdout=log,stderr=subprocess.STDOUT,check=True)
before=source_identity(src);names=set(before)
for command in (['git','diff','--name-only'],['git','diff','--cached','--name-only'],['git','ls-files','--others','--exclude-standard']):names.update(subprocess.check_output(command,cwd=src,text=True).splitlines())
files={}
for n in sorted(names):
 s=src/n
 if not s.exists():
  assert n=='.github/workflows/recover-pw2dn-once.yml' and (dst/n).is_file(),n
  (dst/n).unlink();files[n]={'deleted':True};continue
 assert s.is_file() and not s.is_symlink(),n
 b=s.read_bytes();d=dst/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);assert d.read_bytes()==b
 files[n]={'bytes':len(b),'sha256':sha(b)}
assert before==source_identity(src)==source_identity(dst)
write=lambda n,j:(proof/n).write_text(json.dumps(j,indent=2)+'\n')
write('snapshot-manifest.json',{'base_commit':base,'source':str(src),'snapshot':str(dst),'source_identity_count':len(before),'files':files})
write('source-before.json',before)
env={k:v for k,v in os.environ.items() if not k.upper().startswith('GIT_')};env.update(PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',PYTHONUTF8='1',PYTHONPATH=str(dst/'tests'))
command=[sys.executable,str(dst/'scripts/ci_feedback.py'),'--output',str(proof/'run')] if a.lane=='source' else [sys.executable,'-m','unittest','discover','-s','tests','-v']
start=time.monotonic();report={'schema':1,'lane':a.lane,'base_commit':base,'command':command,'cwd':str(dst),'status':'running','installed_acceptance':False,'source_identity_count':len(before),'launcher_source_sha256':sha(launcher_bytes),'user_stop_at_utc':stop.isoformat()};write('launcher-report.json',report)
def stop_signal(signum,frame):raise KeyboardInterrupt('Validation interrupted by signal '+str(signum))
signal.signal(signal.SIGTERM,stop_signal)
def cleanup_owned(child):
 # The validated child starts a private session/group. Kill that group even if
 # its leader has already exited; leader completion is not descendant cleanup.
 try:os.killpg(child.pid,signal.SIGTERM)
 except ProcessLookupError:pass
 time.sleep(2)
 try:os.killpg(child.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 return child.wait(timeout=5)
code=None;boundary_reached=False;interrupted=False
try:
 with (proof/'console.log').open('wb') as log:
  # Original feedback child limits remain; absolute user stop is not acceptance.
  if remaining()<=0:
   boundary_reached=True
   raise RuntimeError('User stop boundary reached during snapshot preparation')
  child=subprocess.Popen(command,cwd=dst,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=max(0.001,remaining()))
  except subprocess.TimeoutExpired:
   boundary_reached=True;code=cleanup_owned(child)
  except BaseException:
   interrupted=True;code=cleanup_owned(child)
   raise
finally:
 after=source_identity(src);snapshot=source_identity(dst);write('source-after.json',after);write('snapshot-after.json',snapshot)
 copy_ok=all(not (dst/n).exists() if d.get('deleted') else (dst/n).is_file() and sha((dst/n).read_bytes())==d['sha256'] for n,d in files.items())
 text=(proof/'console.log').read_text(errors='replace')
 report.update(returncode=code,elapsed_seconds=round(time.monotonic()-start,3),source_unchanged=before==after,snapshot_unchanged=before==snapshot,all_copied_files_unchanged=copy_ok,console_sha256=sha((proof/'console.log').read_bytes()))
 if a.lane=='core':
  matches=re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$',text,re.M);report['test_summary']=matches[-1] if matches else None
  skips=re.findall(r'^OK(?: \(skipped=(\d+)\))?$',text,re.M);report['skips']=int(skips[-1] or 0) if skips else None
 else:
  rpath=proof/'run/report.json'
  if rpath.is_file():
   r=json.loads(rpath.read_text());report.update(feedback_status=r['status'],feedback_identities_match=r['source_files_sha256']==before)
  else:report.update(feedback_status='no_terminal_report',feedback_identities_match=False)
 report['status']='passed' if code==0 and before==after==snapshot and copy_ok and (a.lane=='core' or report.get('feedback_status')=='passed' and report.get('feedback_identities_match')) else 'failed'
 if interrupted:report['status']='interrupted_and_owned_group_cleaned'
 if boundary_reached:report['status']='interrupted_at_user_stop_boundary'
 report['launcher_unchanged']=sha(Path(__file__).read_bytes())==report['launcher_source_sha256']
 if not report['launcher_unchanged']:report['status']='failed_launcher_identity'
 write('launcher-report.json',report);print(json.dumps(report,indent=2),flush=True)
assert report['status']=='passed'
