import argparse,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('mode',choices=['source','core']);a=p.parse_args()
root=Path('/workspace/shared/icstudio-wsl-v2-validation');out=Path('/workspace/shared/chunk7-wsl-v2-validation')/a.mode;out.mkdir(exist_ok=False)
sys.path.insert(0,str(root));from scripts.ci_feedback import source_identity
before=source_identity(root);(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
launcher=Path(__file__);launcher_sha=hashlib.sha256(launcher.read_bytes()).hexdigest()
cmd=[sys.executable,'scripts/ci_feedback.py','--output',str(out/'run')] if a.mode=='source' else [sys.executable,'-m','unittest','discover','-s','tests','-v']
record={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'mode':a.mode,'command':cmd,'launcher_sha256_before':launcher_sha,'source_count':len(before),'status':'running','installed_acceptance':False,'native_qualification':False};(out/'launcher-report.json').write_text(json.dumps(record,indent=2)+'\n')
child=None;t=time.monotonic()
def stop(sig,frame): raise KeyboardInterrupt
signal.signal(signal.SIGTERM,stop)
try:
 with (out/'console.log').open('wb') as log:
  env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONUNBUFFERED='1')
  child=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  record['pid']=child.pid
  while child.poll() is None:
   if time.monotonic()-t>3600: raise TimeoutError('Outer safety limit; no per-stage timeout changed')
   time.sleep(1)
  record['returncode']=child.returncode;record['status']='passed' if child.returncode==0 else 'failed'
except BaseException as e:
 record.update(status='interrupted' if isinstance(e,KeyboardInterrupt) else 'failed',error_type=type(e).__name__,error=str(e))
 if child is not None:
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  time.sleep(2)
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait()
finally:
 after=source_identity(root);(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');record['source_unchanged']=before==after;record['elapsed_seconds']=round(time.monotonic()-t,3);record['launcher_unchanged']=launcher_sha==hashlib.sha256(launcher.read_bytes()).hexdigest()
 if not record['source_unchanged'] or not record['launcher_unchanged']: record['status']='failed'
 (out/'launcher-report.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
sys.exit(0 if record['status']=='passed' else 1)
