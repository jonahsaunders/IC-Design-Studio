import json,hashlib,re,zipfile,subprocess
from pathlib import Path
root=Path('/workspace/shared/chunk7-wsl-v2-validation');repo=Path('/workspace/shared/icstudio-wsl-v2-validation');out=root/'package';out.mkdir(exist_ok=True)
reports={x:json.loads((root/x/'launcher-report.json').read_text()) for x in ('source','core')}
assert all(r['status']=='passed' and r['source_unchanged'] and r['launcher_unchanged'] for r in reports.values())
framework=json.loads((root/'source/run/report.json').read_text());assert framework['status']=='passed' and len(framework['stages'])==14 and all(s['returncode']==0 for s in framework['stages'])
selected={}
for lane in ['source','core']:
 for p in (root/lane).rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=p.relative_to(root).as_posix()
  if len(p.relative_to(root).parts)<=2 or p.suffix=='.log' or p.name in ('report.json','files.json','result.json','checks.json','menus.json','tabs.json'):selected[rel]=p.read_bytes()
for n in ['run_validation.py','package_validation.py']:selected[n]=(root/n).read_bytes()
paths=set()
for f in ['/workspace/shared/ihp-wsl-reconstruction-validation/ihp-wsl-build-reconstruction-source-v2.zip','/workspace/shared/ihp-wsl-reconstruction-validation/ihp-wsl-build-reconstruction-v2-activation-delta.zip']:
 with zipfile.ZipFile(f) as z:paths.update(json.loads(z.read('MANIFEST.json'))['files'])
paths.update(['scripts/recover_pw2dn_diagnostics.py','tests/test_recover_pw2dn_diagnostics.py'])
for n in sorted(paths):selected['source-overlay/'+n]=(repo/n).read_bytes()
manifest={'schema':1,'scope':'RECONSTRUCTED_BUILD_ONLY_WSL_PLUS_ZIP_FULL_LOCAL_SOURCE_CORE','base_commit':'62c6930a820ee9c9ccb1040e38d1dd7394d9108e','complete_source_overlay_paths':sorted(paths),'native_app_draft_excluded':True,'docker_apt_native_executed':False,'installed_acceptance':False,'files':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in selected.items()},'omitted_gui_payloads':{}}
for p in (root/'source').rglob('*'):
 if p.is_file() and p.relative_to(root).as_posix() not in selected:
  b=p.read_bytes();manifest['omitted_gui_payloads'][p.relative_to(root).as_posix()]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
name='ihp-wsl-build-reconstruction-v2-local-validation-2026-11-11.zip';dest=out/name
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
 for n,b in sorted(selected.items()):z.writestr(n,b)
def counts(log):
 s=log.read_text();return sum(map(int,re.findall(r'^Ran (\d+) tests? in ',s,re.M))),sum(map(int,re.findall(r'^OK \(skipped=(\d+)\)',s,re.M)))
sc=[counts(root/'source/run'/f"{s['name']}.log") for s in framework['stages']]
summary={'schema':1,'snapshot_date':'2026-11-11','scope':manifest['scope'],'base_commit':manifest['base_commit'],'artifact':{'filename':name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str(dest.stat().st_size).encode()+b'\0'+dest.read_bytes()).hexdigest(),'payloads':len(selected),'complete_source_overlay_paths':len(paths),'omitted_gui_payloads':len(manifest['omitted_gui_payloads'])},'source':{'stages':14,'tests':sum(x[0] for x in sc),'skips':sum(x[1] for x in sc),**reports['source']},'core':{'tests':counts(root/'core/console.log')[0],'skips':counts(root/'core/console.log')[1],**reports['core']},'limits':['Native app adapter/auditor draft is excluded from this snapshot.','No actual Docker/APT host preparation, native PMOS execution or installed acceptance.','The complete 37-file source overlay plus published base reconstructs all tested source; omitted GUI payloads are separately hashed and not a full raw-output replay.','Publication in a later candidate still requires exact source/tree readback; no qualification status is promoted.']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
