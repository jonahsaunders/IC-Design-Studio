"""Reconstructed source-only project/readback controls; no GUI/native launch."""
import json,tempfile,unittest
from pathlib import Path
from scripts.materialize_ihp_pmos_measured_v3 import materialize
from scripts.prepare_ihp_wsl_research_projects import prepare,split_deck,LIB
from icstudio.model import load_project
from icstudio.native_analysis import deck
class Projects(unittest.TestCase):
 def test_all_original_twenty_projects_and_protocol(self):
  repo=Path(__file__).resolve().parents[1]
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);e=root/'e';materialize(repo/'docs/qualification/ihp-pmos-measured-reference-v3/evidence-compact.zip',repo/'packaging/ngspice/ngspice-linux47-corrected-v1.zip',e)
   out=root/'projects';r=prepare(e,out);old=e/'measured-v3/attempt-1';original=json.loads((old/'run.json').read_text())
   self.assertEqual([x['case'] for x in r['cases']],[f"{x['route']}-{x['gate_index']}" for x in original['runs']]);self.assertEqual(len(r['cases']),20)
   for row in r['cases']:
    p=load_project(out/row['project']);sources,statements=split_deck((old/'runs'/row['case']/'input.cir').read_text())
    self.assertEqual(p['cells'][0]['spice_statements'],statements);self.assertNotIn('simulation_runtime',p)
    self.assertEqual(p['analysis']['timeout'],90);self.assertFalse(p['analysis']['dc_startup'])
    text,_=deck(p,p['top'],p['analysis'],root/'not-run')
    science=[x for x in text.splitlines() if x and not x.startswith('*') and x!='.end']
    rendered=[' '.join(x.split()[:3])+' DC '+x.split()[3]+' AC 0' for x in sources]
    self.assertEqual(science,statements+rendered+['.temp 27','.dc VD 0 -1.35 -0.05'])
   with self.assertRaises(ValueError):prepare(e,out)
 def test_unexpected_controls_and_accuracy_rejected(self):
  for text in ['.control\npre_osdi evil\n.endc','invalid',' .option loosened']:
   with self.assertRaises(ValueError):split_deck(text)
if __name__=='__main__':unittest.main()
