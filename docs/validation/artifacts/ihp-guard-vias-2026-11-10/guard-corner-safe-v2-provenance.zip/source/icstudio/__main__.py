import sys

def main():
    if len(sys.argv)>1 and sys.argv[1] in ('--worker','--cli','--digital-setup','--collaboration-server','--campaign','--esd-acceptance','--ihp-resistor-acceptance','--ihp-cmim-acceptance','--device-class-acceptance','--pw2dn-acceptance'):
        from .windows_stdio import connect
        connect()
    if '--digital-setup' in sys.argv:
        from .digital_runtime import main as setup
        return setup()
    if len(sys.argv)>1 and sys.argv[1]=='--collaboration-server':
        from .live_server import main as server
        return server(sys.argv[2:])
    if len(sys.argv)>1 and sys.argv[1]=='--campaign':
        from .verification_campaigns import main as campaigns
        return campaigns(sys.argv[2:])
    if len(sys.argv)>1 and sys.argv[1]=='--worker':
        from .worker import main as worker
        return worker(sys.argv[2],sys.argv[3])
    if len(sys.argv)>1 and sys.argv[1]=='--cli':
        from .cli import main as cli
        return cli(sys.argv[2:])
    if '--release-test' in sys.argv:
        from .release_probe import main as probe
        return probe(sys.argv[sys.argv.index('--release-test')+1])
    if '--physical-acceptance' in sys.argv:
        from .physical_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--physical-acceptance')+1:])
    if '--metal-parallel-acceptance' in sys.argv:
        from .metal_resistor_parallel_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--metal-parallel-acceptance')+1:])
    if '--metal-resistor-acceptance' in sys.argv:
        from .metal_resistor_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--metal-resistor-acceptance')+1:])
    if '--ihp-resistor-acceptance' in sys.argv:
        from .ihp_resistor_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--ihp-resistor-acceptance')+1:])
    if '--ihp-cmim-acceptance' in sys.argv:
        from .ihp_cmim_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--ihp-cmim-acceptance')+1:])
    if '--device-class-acceptance' in sys.argv:
        from .device_class_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--device-class-acceptance')+1:])
    if '--mim-acceptance' in sys.argv:
        from .mim_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--mim-acceptance')+1:])
    if '--esd-acceptance' in sys.argv:
        from .esd_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--esd-acceptance')+1:])
    if '--pw2dn-acceptance' in sys.argv:
        from .pw2dn_desktop_probe import main as probe
        return probe(sys.argv[sys.argv.index('--pw2dn-acceptance')+1:])
    if '--vga-test' in sys.argv:
        from .vga_probe import main as probe
        return probe(sys.argv[sys.argv.index('--vga-test')+1])
    if '--desktop-acceptance' in sys.argv:
        from .desktop_acceptance import main as acceptance
        return acceptance(sys.argv[sys.argv.index('--desktop-acceptance')+1])
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QTimer, Qt
    from .gui import Studio
    QApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
    app=QApplication(sys.argv);app.setApplicationName('IC Design Studio');app.setOrganizationName('ICDesignStudio');app.setStyle('Fusion');window=Studio(recover=False)
    if '--project' in sys.argv:
        from .model import load_project
        path=sys.argv[sys.argv.index('--project')+1]
        if path.lower().endswith('.sch'):
            from .xschem_compat import review_project
            from .xschem_project import apply_review
            window.set_project(apply_review(review_project(path)))
        else:window.set_project(load_project(path),path)
    from PySide6.QtGui import QIcon
    from pathlib import Path
    app.setWindowIcon(QIcon(str(Path(__file__).parent/'assets/app.svg')))
    window.setWindowIcon(app.windowIcon())
    window.show()
    if '--join' in sys.argv:
        index=sys.argv.index('--join')
        link=sys.argv[index+1] if index+1<len(sys.argv) else ''
        QTimer.singleShot(100,lambda:window.guard(lambda:window.live_join_dialog(link)))
    if '--project' not in sys.argv and '--smoke-test' not in sys.argv and '--join' not in sys.argv:
        def welcome():
            window.offer_recovery()
            if not window._recovered_from and window.path is None and window.settings.value('onboarding/show', True, type=bool):
                window.start_here()
            from .digital_setup_ui import startup
            startup(window)
        QTimer.singleShot(100, welcome)
    if '--smoke-test' in sys.argv:
        from .model import digest
        window.saved_hash=digest(window.project)
        QTimer.singleShot(600,app.quit)
    elif '--project' in sys.argv:
        def digital_setup():
            from .digital_setup_ui import startup
            startup(window)
        QTimer.singleShot(200,digital_setup)
    return app.exec()
if __name__=='__main__':raise SystemExit(main())
