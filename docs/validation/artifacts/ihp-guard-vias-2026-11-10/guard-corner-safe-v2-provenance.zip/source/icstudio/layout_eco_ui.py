"""Hierarchy-wide selectable schematic-to-layout review."""
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QCheckBox, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFormLayout, QLineEdit, QHBoxLayout,
    QAbstractItemView, QWidget)
from .model import clone, design_digest


def show(studio, missing=False):
    if not studio.idle_edit(): return
    from .layout_eco_hierarchy import inventory, propose
    from .layout_development_ui import point, nm
    cid = studio.cid; dlg = QDialog(studio); dlg.setWindowTitle('Schematic-driven layout'); dlg.resize(1050,680)
    layout = QVBoxLayout(dlg)
    note = QLabel('Select the changes to preview. Shared cell masters are updated once. Missing devices use declared recipes; unsupported devices need an explicit physical implementation.'); note.setWordWrap(True); layout.addWidget(note)
    scope = QCheckBox('Include schematic hierarchy'); scope.setChecked(True); layout.addWidget(scope)
    variants=QPushButton('Resolve parameter variants…');layout.addWidget(variants)
    def specialize():
        try:
            from .physical_hierarchy_ui import materialize_dialog
            materialize_dialog(studio,cid);dlg.accept()
        except Exception as exc:error.setText(str(exc))
    variants.clicked.connect(specialize)
    table = QTableWidget(0, 5); table.setHorizontalHeaderLabels(['Apply', 'Cell / device', 'State', 'Action', 'Details']); table.horizontalHeader().setSectionResizeMode(4,QHeaderView.Stretch); layout.addWidget(table,1)
    table.setAccessibleName('Schematic-driven layout changes'); state = {}
    table.setSelectionBehavior(QAbstractItemView.SelectRows);table.setSelectionMode(QAbstractItemView.SingleSelection)
    impact=QLabel('Select a device to inspect its schematic, physical implementation and connected nets.');impact.setWordWrap(True);impact.setAccessibleName('Selected device change impact');layout.addWidget(impact)
    inspect_row=QHBoxLayout();schematic_button=QPushButton('Show in schematic');physical_button=QPushButton('Show in layout')
    inspect_row.addWidget(schematic_button);inspect_row.addWidget(physical_button);layout.addLayout(inspect_row)
    def selected_row():
        index=table.currentRow()
        return state['report']['devices'][index] if 0<=index<len(state['report']['devices']) else None
    def inspect():
        row=selected_row();schematic_button.setEnabled(False);physical_button.setEnabled(False)
        if not row:return
        from .layout_eco_review import device_impact
        info=device_impact(studio.project,row['cell_id'],row['device_id']);state['impact']=info
        impact.setText(info['summary']);schematic_button.setEnabled(bool(info['device']))
        physical_button.setEnabled(bool(info['layout_objects']))
    def navigate(mode):
        try:
            if not studio.flush_inspector():return
            row=selected_row()
            if row is None:return
            from .layout_eco_review import device_impact
            info=device_impact(studio.project,row['cell_id'],row['device_id'])
            studio.cid=row['cell_id'];studio.selection=[];studio.mode_combo.setCurrentIndex(0 if mode=='schematic' else 1);studio.refresh(True)
            schematic_ids=[row['device_id']] if info['device'] else []
            studio.select(schematic_ids if mode=='schematic' else info['layout_objects'],mode)
            # Each editor's command selection contains only its own objects.
            # Keep the linked view highlighted without mixing IDs into edits.
            studio.schematic.selection=schematic_ids;studio.schematic.update()
            studio.layout.selection=info['layout_objects'];studio.layout.update()
            studio.statusBar().showMessage(info['summary'],15000)
        except Exception as exc:error.setText(str(exc))
    table.itemSelectionChanged.connect(inspect)
    schematic_button.clicked.connect(lambda:navigate('schematic'));physical_button.clicked.connect(lambda:navigate('layout'))
    def populate():
        state['report'] = inventory(studio.project,cid,scope.isChecked()); rows = state['report']['devices']; table.setRowCount(len(rows))
        for i,row in enumerate(rows):
            check = QTableWidgetItem(); check.setFlags(Qt.ItemIsEnabled|Qt.ItemIsUserCheckable if row['action'] else Qt.NoItemFlags); check.setCheckState(Qt.Unchecked); table.setItem(i,0,check)
            for j,value in enumerate((row['cell']+' / '+row['name'],row['status'],row['action'],row['detail']),1):
                item=QTableWidgetItem(value);item.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable);table.setItem(i,j,item)
        table.resizeColumnsToContents()
        if rows:table.selectRow(0)
    scope.toggled.connect(populate); populate()
    summary=QLabel();summary.setWordWrap(True);layout.addWidget(summary)
    select_missing=QPushButton('Select missing and changed devices');layout.addWidget(select_missing)
    def select_actionable():
        for i,row in enumerate(state['report']['devices']):
            table.item(i,0).setCheckState(Qt.Checked if row['action'] in ('add','update','rebind') else Qt.Unchecked)
    select_missing.clicked.connect(select_actionable)
    select_all=QPushButton('Select all missing devices');layout.addWidget(select_all)
    def select_unplaced():
        rows=state['report']['devices']
        for i,row in enumerate(rows):table.item(i,0).setCheckState(Qt.Checked if row['action']=='add' else Qt.Unchecked)
        count=sum(r['action']=='add' for r in rows);unsupported=sum(r['status']=='unsupported' for r in rows)
        summary.setText(f'{count} missing devices ready for placement; {unsupported} unsupported. Existing placements stay in place. Review unsupported rows for the required physical implementation. Sources and simulation-only components may have no layout.')
    select_all.clicked.connect(select_unplaced)
    if missing:
        dlg.setWindowTitle('Place schematic devices in layout');select_unplaced()
        scope.toggled.connect(lambda _:select_unplaced())

    form = QFormLayout(); origin=QLineEdit('0, 0'); pitch=QLineEdit('20');form.addRow('New footprint origin X, Y (µm)',origin);form.addRow('New footprint pitch (µm)',pitch);layout.addLayout(form)
    preserve=QCheckBox('Preserve attached routes and surviving terminal connectivity');preserve.setChecked(True);layout.addWidget(preserve)
    strict=QCheckBox('Require all analog and route constraints to pass');strict.setAccessibleName('Require clean layout constraints')
    strict.setToolTip('By default, an update may retain existing findings but cannot introduce or worsen them. Enable this to require a fully clean result.');layout.addWidget(strict)
    error=QLabel();error.setWordWrap(True);layout.addWidget(error);button=QPushButton('Preview selected changes');layout.addWidget(button)
    def preview():
        try:
            if state['report']['design_hash'] != design_digest(studio.project): raise ValueError('The project changed. Reopen this review.')
            chosen=[(r['cell_id'],r['device_id']) for i,r in enumerate(state['report']['devices']) if table.item(i,0).checkState()==Qt.Checked]
            candidate,report=propose(studio.project,cid,chosen,studio.layout.locked_layers,preserve.isChecked(),point(origin.text()),nm(pitch.text()),scope.isChecked(),strict_constraints=strict.isChecked())
            text='\n'.join(r['cell']+' / '+r['name']+': '+r['action'] for r in report['changes'])
            text+='\n\n'+str(len(report['affected_cells']))+' edited masters; '+str(len(report['adjusted_routes']))+' adjusted routes.\n'
            text+='\n'.join(next(c['name'] for c in candidate['cells'] if c['id']==k)+': '+str(len(v))+' connectivity findings' for k,v in report['connectivity'].items())
            text+='\n'+str(len(report.get('preserved_centers',[])))+' constrained device centers preserved.'
            text+='\n'+str(sum(len(v) for v in report.get('constraint_findings',{}).values()))+' remaining constraint findings; '+('all constraints must pass.' if strict.isChecked() else 'no new or worsened findings allowed.')
            text+='\n\nApply is one undoable transaction. Independent routes remain after orphan removal. Run full DRC/LVS after reviewing every affected parent.'
            from .layout_eco_review import proposal_summary
            text+='\n\n'+proposal_summary(studio.project,candidate,report)
            before=clone(studio.project)
            controls=QWidget();controls_layout=QHBoxLayout(controls);compare=QPushButton('Inspect geometry before and after');controls_layout.addWidget(compare)
            def comparison():
                from .team_review_ui import RevisionComparison
                studio._eco_comparison=RevisionComparison(studio._review_dialog,before,candidate);studio._eco_comparison.view_mode.setCurrentIndex(0);studio._eco_comparison.show()
            compare.clicked.connect(comparison)
            from .layout_eco import apply as apply_eco
            studio.review_dialog('Apply schematic-driven layout changes',lambda:(candidate,text),controls,
                                apply_candidate=lambda target,reviewed:apply_eco(target,reviewed,report));dlg.accept()
        except Exception as exc:error.setText(str(exc))
    def check_revision():
        stale=state['report']['design_hash']!=design_digest(studio.project)
        button.setEnabled(not stale);variants.setEnabled(not stale)
        if stale:error.setText('The design changed. Reopen this review before previewing changes.');timer.stop()
    # Cheap revision identity check during polling; the apply path still checks
    # the full design hash, including edits made by legacy metadata callers.
    starting=(id(studio.project),studio.project['revision'])
    timer=QTimer(dlg);timer.setInterval(300)
    timer.timeout.connect(lambda:check_revision() if starting!=(id(studio.project),studio.project['revision']) else None);timer.start()
    button.clicked.connect(preview);dlg.table=table;dlg.select_missing_button=select_all;dlg.summary=summary;dlg.preview_button=button;dlg.strict_constraints=strict;dlg.schematic_button=schematic_button;dlg.physical_button=physical_button;dlg.impact=impact;studio._layout_eco_dialog=dlg;dlg.show();return dlg
