"""Small real-network acceptance exercised inside installed/frozen application builds."""
from pathlib import Path
import tempfile
import threading
import time

from PySide6.QtTest import QTest
from PySide6.QtCore import Qt

from .layout import rect
from .live_client import LiveClient
from .live_protocol import invitation_link, parse_invitation
from .live_server import Server
from .live_store import Store
from .model import clone, device, example, uid


def run(window, output):
    previous, path = clone(window.project), window.path
    with tempfile.TemporaryDirectory(prefix='live-probe-', dir=output) as temp:
        root = Path(temp)
        store = Store(root / 'server.sqlite3', 'packaged-probe-key-' + 'x' * 32)
        server = Server(('127.0.0.1', 0), store)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = 'http://127.0.0.1:' + str(server.server_port)
        try:
            p = example('empty')
            p['cells'][0]['shapes'] = [rect('metal1', 0, 0, 1600, 900)]
            snapshot = store.create(store.create_key, p, 'Packaged editor')
            invitation = store.invite(snapshot['workspace'], snapshot['token'], 'view')
            link = invitation_link(url, snapshot['workspace'], invitation['invite'])
            assert parse_invitation(link) == (url, snapshot['workspace'], invitation['invite'])
            client = LiveClient(url, snapshot['workspace'], snapshot['token'], snapshot, root / 'session.json', window)
            window.live_attach(client)
            def wait(predicate):
                deadline = time.monotonic() + 12
                while not predicate() and time.monotonic() < deadline:
                    QTest.qWait(20)
                assert predicate(), client.message
            wait(lambda: not client.busy and client.connected)
            window.commit(lambda q: q['cells'][0]['shapes'].append(rect('metal2', 400, 1500, 1400, 700)), 'Packaged live edit')
            wait(lambda: client.pending is None and client.revision == 1)
            assert len(window.cell['shapes']) == 2
            window.undo()
            wait(lambda: client.pending is None and client.revision == 2)
            assert len(window.cell['shapes']) == 1
            window.redo()
            wait(lambda: client.pending is None and client.revision == 3)
            assert len(window.cell['shapes']) == 2
            window.mode_combo.setCurrentIndex(0)
            window.commit(lambda q: q['cells'][0]['devices'].append(device('R','Rshared',0,0)), 'Packaged schematic edit')
            wait(lambda: client.pending is None and client.revision == 4)
            assert window.cell['devices'][0]['name'] == 'Rshared'
            from .team_review_ui import RevisionComparison
            review = RevisionComparison(window, p, window.project)
            review.show();QTest.qWait(50)
            assert review.view_mode.currentIndex() == 1 and all(v.scene_model.items() for v in review.views)
            assert review.grab().save(str(Path(output) / 'live-schematic-review.png'))
            review.close()
            window.undo()
            wait(lambda: client.pending is None and client.revision == 5)
            assert not window.cell['devices']
            window.mode_combo.setCurrentIndex(1)
            window.layout.fit()
            QTest.qWait(50)
            assert window.grab().save(str(Path(output) / 'live-collaboration.png'))
            # Exercise the bundled workflow worker and reviewer UI, not only
            # their source-tree imports.
            guide=window.design_workflow()
            wait(lambda:guide.analysis is not None)
            assert not guide.analysis.get('error'),guide.analysis
            guide.close()
            checkpoint=store.review(snapshot['workspace'],snapshot['token'],dict(action='create_checkpoint',id=uid(),revision=client.revision,name='Packaged review'))
            invitation=store.invite(snapshot['workspace'],snapshot['token'],'review')
            reviewer=store.join(snapshot['workspace'],invitation['invite'],'Packaged reviewer')
            window.live_leave()
            client=LiveClient(url,snapshot['workspace'],reviewer['token'],reviewer,root/'reviewer.json',window)
            window.live_attach(client);panel=window.collaboration_dashboard(3).review_panel
            wait(lambda:not panel.busy and panel.checkpoints.count()==1)
            panel.refresh_state();assert panel.comment_button.isEnabled() and not panel.add_button.isEnabled()
            panel.comment.setPlainText('Please inspect this checkpoint.');panel.comment_button.click()
            wait(lambda:not panel.busy and panel.comments.topLevelItemCount()==1)
            root_comment=panel.comments.topLevelItem(0).data(0,Qt.UserRole)
            store.review(snapshot['workspace'],snapshot['token'],dict(action='reply',id=uid(),checkpoint=checkpoint['id'],parent=root_comment['id'],text='Inspected in the installed application.'))
            wait(lambda:not panel.busy and panel.comments.topLevelItem(0).childCount()==1)
            panel.comments.setCurrentItem(panel.comments.topLevelItem(0));panel.start_reply()
            panel.comment.setPlainText('Unsent packaged reply');assert panel.flush_draft();panel.hide()
            from .team_review_ui import TeamReviewPanel
            restored=TeamReviewPanel(window);restored.show();restored.refresh_state()
            wait(lambda:not restored.busy and restored.loaded_version is not None)
            assert restored.comment.toPlainText()=='Unsent packaged reply' and restored.reply_to==root_comment['id']
            assert len(store.review(snapshot['workspace'],reviewer['token'],dict(action='list'))['comments'])==2
            restored.comment.clear();assert restored.flush_draft();restored.close()
            panel.comment.clear();assert panel.flush_draft()
            from .live_protocol import LiveError
            try:client.editable()
            except LiveError:pass
            else:raise AssertionError('A packaged reviewer could edit the design.')
        finally:
            if window.live_client:
                window.live_leave()
            QTest.qWait(100)
            server.shutdown()
            server.server_close()
            thread.join(5)
            store.close()
            window.set_project(previous, path)
    return 'packaged live HTTP editing/undo, automatic workflow, reviewer authorization, threaded discussions and unsent reply recovery without auto-posting'
