"""Mapped implementation, timing and equivalence on immutable worker inputs."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from .model import atomic_write, clone, design_digest, digest, file_digest, io_path, now
from .digital_design import config as cell_config


def logic_identity(config):
    from .digital_identity import logic_key
    return logic_key(config)


def capture_upstream(project,cid,directory):
    from .job_store import read_result
    root=Path(directory).resolve();result=read_result(root/'result.json',project['id'])
    if result['cell_id']!=cid:raise ValueError('The upstream result belongs to a different cell.')
    data=result['digital_result']
    if data.get('logic_hash')!=logic_identity(cell_config(project,cid)):
        raise ValueError('RTL, definitions or technology changed. Run mapped synthesis for the current inputs.')
    if 'netlist' not in data['artifacts'] or not data.get('mapped'):raise ValueError('Choose a technology-mapped upstream result.')
    return {'root':str(root),'result_sha256':file_digest(root/'result.json'),'logic_hash':data['logic_hash'],
            'source_hash':data['source_hash'],'stage':data['stage'],'artifacts':clone(data['artifacts'])}


def verify_upstream(record):
    root=io_path(record['root']).resolve()
    if file_digest(root/'result.json')!=record['result_sha256']:raise ValueError('The upstream result changed after this job was queued.')
    from .digital_flow import validate_result
    result=json.loads((root/'result.json').read_text());validate_result(result,root)
    if record['artifacts']!=result['digital_result']['artifacts']:raise ValueError('The upstream artifact binding changed.')
    return result


def quote(value):
    return '"'+str(value).replace('\\','\\\\').replace('"','\\"')+'"'


def tcl_word(value):
    from .engines import tcl_word as word
    return word(str(value))


def structural_verilog(text):
    """Remove signed declaration qualifiers after all arithmetic is mapped.

    OpenSTA's structural reader does not accept them. Widths, bit selections,
    cell connections and constants are unchanged; this is never applied to RTL.
    """
    return re.sub(r'(?m)^([ \t]*(?:wire|input|output|inout)) signed(?=[ \t])',r'\1',text)


class Runner:
    def __init__(self,job,directory,progress):
        from .digital_flow import child_environment,environment,stage_sources
        self.job=job;self.config=cell_config(job['project'],job['cell']);self.settings=job['settings'];self.tools=self.settings['tools'];self.progress=progress
        if environment(job)!=job.get('environment'):raise ValueError('The digital toolchain or platform changed. Prepare a new run.')
        self.root=Path(directory).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.sources=self.root/'sources';self.sources.mkdir();stage_sources(self.config,self.sources)
        self.tmp=self.root/'tmp';self.tmp.mkdir();self.log=self.root/'engine.log';atomic_write(self.log,'Digital '+self.settings['stage']+'\n')
        self.env=child_environment(self.tmp,self.tools)
        self.commands=[];self.artifacts={};self.versions={};self.platform=self.config.get('platform')
        if self.platform:
            from .digital_platform import stage
            stage(self.platform,self.root/'platform')
        from .digital import input_manifest
        atomic_write(self.root/'inputs.json',json.dumps(input_manifest(self.config),indent=2))

    def command(self,args,message,cwd=None,fraction=.2,allow_failure=False):
        from .engines import execute
        cwd=Path(cwd or self.sources)
        self.commands.append({'argv':[str(a) for a in args],'cwd':cwd.relative_to(self.root).as_posix()})
        atomic_write(self.root/'commands.json',json.dumps(self.commands,indent=2));self.progress(fraction,message)
        def line(text):
            with self.log.open('a',encoding='utf-8') as output:output.write(text+'\n')
            self.progress(fraction,text[:1000])
        try:return execute(args,cwd,timeout=self.config.get('timeout',60),on_line=line,env=self.env)
        except (RuntimeError,subprocess.TimeoutExpired) as exc:
            line(str(exc))
            if not allow_failure:raise
            return str(exc)

    def add_artifact(self,key,path,allow_empty=False):
        from .digital_flow import artifact
        self.artifacts[key]=artifact(self.root,Path(path),allow_empty=allow_empty)

    def save_json(self,key,data,filename):
        atomic_write(self.root/filename,json.dumps(data,indent=2));self.add_artifact(key,self.root/filename)

    def libraries(self, corner=None):
        from .digital_platform import liberty_files
        corner = corner or getattr(self, 'timing_corner', None) or self.platform['corner']
        paths=liberty_files(self.platform,self.root/'platform',self.root/'liberty',corner)
        for path in paths:
            if path.parent==self.root/'liberty':self.add_artifact('liberty_'+path.stem,path)
        return paths

    def versions_check(self):
        for name,path in self.tools.items():
            flag='-V' if name in ('iverilog','vvp','yosys') else '-version' if name in ('sta','openroad') else '-v' if name=='klayout' else '--version'
            args=[path,'-c','version'] if name=='yosys-abc' else [path,flag]
            self.versions[name]=self.command(args,'Checking '+name,fraction=.01).strip()[:12000]

    def constraints(self):
        files=[f for f in self.config['files'] if f['role']=='constraint']
        if len(files)!=1:raise ValueError('Mark exactly one SDC source as Constraint.')
        return self.sources/files[0]['path']


def mapped(runner):
    r=runner;upstream=r.settings.get('upstream')
    if upstream:
        verify_upstream(upstream)
        for key,name in (('netlist','netlist.v'),('hierarchy','netlist.json'),('statistics','statistics.json'),('netlist_index','netlist_index.json')):
            if key in upstream['artifacts']:
                shutil.copy2(Path(upstream['root'])/upstream['artifacts'][key]['path'],r.root/name);r.add_artifact(key,r.root/name)
        if 'hierarchy' not in r.artifacts:
            # Physical tools may change names/cells; regenerate a JSON view of that exact netlist.
            script='\n'.join('read_liberty -lib -ignore_miss_func '+quote(p) for p in r.libraries())+'\n'
            script+='read_verilog ../netlist.v\nhierarchy -check -top '+r.config['top']+'\nwrite_json ../netlist.json\ntee -o ../statistics.json stat -json\n'
            atomic_write(r.root/'import_netlist.ys',script);r.command([r.tools['yosys'],'-s',str(r.root/'import_netlist.ys')],'Indexing the captured mapped netlist')
            r.add_artifact('hierarchy',r.root/'netlist.json');r.add_artifact('statistics',r.root/'statistics.json')
    else:
        from .digital_flow import read_rtl
        libs=r.libraries()
        if len(libs)!=1:raise ValueError('Mapped synthesis currently requires one merged Liberty library per corner.')
        script='read_liberty -lib -ignore_miss_func '+quote(libs[0])+'\n'
        script+=read_rtl(r.config)+'\nhierarchy -check -top '+r.config['top']+'\nsynth -noabc -flatten -top '+r.config['top']+'\n'
        # ABC's retained workspace uses short relative paths, including in deeply nested jobs folders.
        from .digital_constraints import synthesis_settings
        intent = synthesis_settings(r.config)
        abc = 'abc -nocleanup -liberty ' + quote(libs[0])
        if 'delay_ns' in intent:
            abc += ' -D ' + str(intent['delay_ns'] * 1000)
        if intent.get('driving_cell'):
            constraint = r.root/'abc.constr'
            atomic_write(constraint, 'set_driving_cell ' + intent['driving_cell'] + '\nset_load ' + str(intent.get('load_pf', 0) * 1000) + '\n')
            abc += ' -constr ' + quote(constraint)
            r.add_artifact('synthesis_constraints', constraint)
        if intent.get('mapping')=='speed':
            from .digital_mapping import speed_script, SOURCE
            path=r.root/'abc_speed.script';atomic_write(path,speed_script(intent.get('delay_ns')))
            abc+=' -script '+quote(path);r.add_artifact('mapping_script',path)
            r.save_json('mapping_recipe',{'source':SOURCE,'script_sha256':file_digest(path),
                'delay_ns':intent.get('delay_ns'),'mapping':'speed'},'mapping_recipe.json')
        r.save_json('synthesis_intent', intent, 'synthesis_intent.json')
        script += 'dfflibmap -liberty ' + quote(libs[0]) + '\n' + abc + '\nclean\n'
        from .digital_platform import ORFS_PROFILES
        # Preserve legacy SKY130 manifests; other profiles carry explicit ties.
        ties=r.platform.get('tie_cells',ORFS_PROFILES['sky130hd']['tie_cells'] if r.platform['name']=='sky130hd' else {})
        if ties:script+='hilomap -singleton -hicell '+' '.join(ties['high'])+' -locell '+' '.join(ties['low'])+'\n'
        script+='delete t:$scopeinfo\ncheck -assert\nwrite_verilog -noattr -noexpr ../netlist.v\nwrite_json ../netlist.json\n'
        script+='tee -o ../statistics.json stat -json -liberty '+quote(libs[0])+'\n'
        atomic_write(r.root/'mapped.ys',script);r.command([r.tools['yosys'],'-s',str(r.root/'mapped.ys')],'Mapping '+r.config['top']+' to '+r.platform['name'])
        hierarchy=json.loads((r.root/'netlist.json').read_text())
        if any(c['type'].startswith('$') for c in hierarchy['modules'][r.config['top']].get('cells',{}).values()):
            raise ValueError('Technology mapping left unsupported cells. Inspect the retained synthesis logs.')
        original=(r.root/'netlist.v').read_text();normalized=structural_verilog(original)
        if normalized!=original:
            atomic_write(r.root/'netlist_yosys.v',original);r.add_artifact('synthesis_netlist',r.root/'netlist_yosys.v')
            atomic_write(r.root/'netlist.v',normalized)
        for key,name in (('netlist','netlist.v'),('hierarchy','netlist.json'),('statistics','statistics.json')):r.add_artifact(key,r.root/name)
    from .digital_reports import netlist_index
    data=json.loads((r.root/'netlist.json').read_text());index=netlist_index(data,r.config['files'])
    if upstream and (r.root/'netlist_index.json').is_file():
        retained={(i['module'],i['kind'],i['name']):i for i in json.loads((r.root/'netlist_index.json').read_text())}
        for item in index:
            old=retained.get((item['module'],item['kind'],item['name']),{})
            if not item['locations']:item['locations']=old.get('locations',[]);item['mapping']=old.get('mapping','unmapped')
    r.save_json('netlist_index',index,'netlist_index.json')
    module=data['modules'][r.config['top']]
    unmapped=[name for name,c in module.get('cells',{}).items() if c['type'].startswith('$')]
    if unmapped:raise ValueError('Technology mapping left unsupported cells: '+', '.join(unmapped[:10]))
    stats=json.loads((r.root/'statistics.json').read_text())
    area=stats.get('design',{}).get('area')
    if area is None:
        area=next((m.get('area') for name,m in stats.get('modules',{}).items() if name.lstrip('\\')==r.config['top']),None)
    return {'mapped':True,'statistics':{'cells':len(module.get('cells',{})),'area_um2':area},
            'summary':'Mapped synthesis complete · '+r.platform['name']+' / '+r.platform['corner']}


def timing_script(r):
    lines=['set_cmd_units -time ns -capacitance pF',
           'sta::redirect_file_begin '+tcl_word(r.root/'timing_load.txt')]
    lines += ['read_liberty '+tcl_word(p) for p in r.libraries()]
    lines += ['read_verilog '+tcl_word(r.root/'netlist.v'),'link_design '+r.config['top'],
              'read_sdc '+tcl_word(r.constraints())]
    upstream=r.settings.get('upstream',{})
    key=getattr(r,'timing_spef_key','spef')
    if key in upstream.get('artifacts',{}):
        if not hasattr(r,'timing_spef_key'):verify_upstream(upstream)
        target=r.root/('parasitics.spef' if key=='spef' else 'parasitics/'+key+'.spef')
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(Path(upstream['root'])/upstream['artifacts'][key]['path'],target)
        r.add_artifact(key,target)
        factor='-coupling_reduction_factor 1.0 ' if 'fill' in upstream.get('artifacts',{}) else ''
        lines.append('read_spef '+factor+tcl_word(target))
        lines.append('set_propagated_clock [all_clocks]')
    lines.append('sta::redirect_file_end')
    if key in upstream.get('artifacts',{}):
        lines += ['report_parasitic_annotation -report_unannotated > '+tcl_word(r.root/'parasitic_annotation.txt'),
                  'set out [open '+tcl_word(r.root/'disconnected_outputs.txt')+' w]',
                  '''foreach pin [get_pins -hierarchical * -filter {direction == output}] {
  set nets [get_nets -quiet -of_objects $pin]
  if {$nets eq "NULL" || ![llength $nets]} {puts $out [get_full_name $pin]}
}
close $out''']
    # An SDC can set its own input units. Normalize only after interpreting it,
    # so every saved path, total and UI label uses the declared output units.
    lines += ['set_cmd_units -time ns -capacitance pF',
              'sta::redirect_file_begin '+tcl_word(r.root/'timing_units.txt'),
              'report_units','sta::redirect_file_end',
              'check_setup -verbose > '+tcl_word(r.root/'timing_checks.txt'),
              'report_checks -path_delay min_max -group_count 50 -format full_clock_expanded > '+tcl_word(r.root/'timing_full.txt'),
              'report_power > '+tcl_word(r.root/'power.txt'),
              'report_tns -max > '+tcl_word(r.root/'timing_totals.txt'),
              'report_tns -min > '+tcl_word(r.root/'timing_hold_totals.txt'),
              'report_check_types -max_slew -max_capacitance -max_fanout -violators > '+tcl_word(r.root/'electrical_checks.txt'),
              'set out [open '+tcl_word(r.root/'timing_paths.tsv')+' w]',
              '''foreach {kind delay} {setup max hold min} {
  foreach path [find_timing_paths -path_delay $delay -group_path_count 50 -sort_by_slack] {
    set start [get_property [get_property $path startpoint] full_name]
    set end [get_property [get_property $path endpoint] full_name]
    set pins {}
    foreach point [get_property $path points] {lappend pins [get_property [get_property $point pin] full_name]}
    puts $out "$kind\\t$start\\t$end\\t[get_property $path slack]\\t[join $pins |]"
  }
}
close $out''']
    return 'if {[catch {\n'+'\n'.join(lines)+'\n} message]} {puts stderr $message; exit 1}\nexit 0\n'


def timing(r):
    from .digital_reports import timing_report
    data=mapped(r);corners=r.config.get('timing_corners',[r.platform['corner']]);reports=[];powers=[]
    from .digital_reports import power_report
    from .digital_rc import timing_sources
    sources=timing_sources(r)
    outputs=('timing_load.txt','timing_full.txt','timing_checks.txt','timing_units.txt','timing_paths.tsv',
             'timing_totals.txt','timing_hold_totals.txt','electrical_checks.txt','power.txt',
             'parasitic_annotation.txt','disconnected_outputs.txt')
    for i,corner in enumerate(corners):
        for j,(rc_corner,spef_key) in enumerate(sources):
            scenario=corner+(' / '+rc_corner if rc_corner else '')
            r.timing_corner=corner;r.timing_spef_key=spef_key
            # Missing output from this scenario cannot borrow a previous pass.
            for name in outputs:(r.root/name).unlink(missing_ok=True)
            atomic_write(r.root/'timing.tcl',timing_script(r))
            r.command([r.tools['sta'],'-no_init','-exit',str(r.root/'timing.tcl')],'Analyzing setup and hold · '+scenario,fraction=.6)
            report=timing_report(r.root,require_parasitics=bool(spef_key));report.update(corner=corner,rc_corner=rc_corner,scenario=scenario)
            report['parasitics']='extracted SPEF' if spef_key else 'No extracted interconnect; pre-layout estimate'
            for path in report['paths']:path.update(corner=corner,rc_corner=rc_corner,scenario=scenario)
            reports.append(report);powers.append({'corner':corner,'rc_corner':rc_corner,'scenario':scenario,**power_report(r.root/'power.txt')})
            folder=r.root/'timing-corners'/corner
            if rc_corner:folder=folder/rc_corner
            folder.mkdir(parents=True)
            prefix='corner_'+corner if not rc_corner else 'scenario_'+str(i)+'_'+str(j)
            names=['timing.tcl','timing_load.txt','timing_full.txt','timing_checks.txt','timing_units.txt','timing_paths.tsv','timing_totals.txt','timing_hold_totals.txt','electrical_checks.txt','power.txt']
            if spef_key:names += ['parasitic_annotation.txt','disconnected_outputs.txt']
            for name in names:
                if (r.root/name).is_file():
                    shutil.copy2(r.root/name,folder/name);r.add_artifact(prefix+'_'+name.replace('.','_'),folder/name,allow_empty=True)
    r.timing_corner=None
    report=clone(reports[0]);report['corners']=reports;report['paths']=[p for c in reports for p in c['paths']]
    report.pop('rc_corner',None);report.pop('scenario',None);report.pop('parasitic_annotation',None)
    states={c['status'] for c in reports};report['status']=next((s for s in ('FAIL','INCOMPLETE') if s in states),'PASS')
    report['unconstrained']=any(c['unconstrained'] for c in reports)
    report['incomplete_reasons']=[c['scenario']+': '+reason for c in reports for reason in c['incomplete_reasons']]
    report['electrical_status']=next((status for status in ('FAIL','Unavailable')
        if any(c['electrical_status']==status for c in reports)),'No reported violations')
    report['summary']={key:min(values) for key in ('setup_worst_slack_ns','hold_worst_slack_ns') if (values:=[c['summary'][key] for c in reports if c['summary'].get(key) is not None])}
    for key in ('setup_reported_violations','hold_reported_violations'):
        report['summary'][key]=sum(c['summary'].get(key,0) for c in reports)
    for kind in ('setup','hold'):
        key=kind+'_total_negative_slack_ns';totals=[c['summary'][key] for c in reports if key in c['summary']]
        if totals:report['summary'][key]=min(totals)
    report['rc_corners']=[name for name,key in sources if name]
    report['scope']='Every selected library corner crossed with each captured interconnect extraction. Legacy single-SPEF and pre-layout results retain their narrower scope.'
    r.save_json('timing',report,'timing.json');r.add_artifact('timing_full',r.root/'timing_full.txt',allow_empty=True);r.add_artifact('power_report',r.root/'power.txt')
    data['power']={**powers[0],'corners':powers}
    upstream=r.settings.get('upstream',{})
    if 'layout_preview' in upstream.get('artifacts',{}):
        verify_upstream(upstream)
        shutil.copy2(Path(upstream['root'])/upstream['artifacts']['layout_preview']['path'],r.root/'layout_preview.json')
        r.add_artifact('layout_preview',r.root/'layout_preview.json')
    detail=' · '+report['incomplete_reasons'][0] if report['incomplete_reasons'] else ''
    rc_detail=' · RC '+', '.join(report['rc_corners']) if report['rc_corners'] else ''
    return {**data,'timing':report,'verdict':report['status'],'summary':'Timing '+report['status']+' · '+', '.join(corners)+rc_detail+' · '+report['parasitics']+detail}


def proof_strategies(timeout):
    # Keep induction for simple partitions and try reachability-based PDR when
    # induction cannot establish their invariants. Both use formal X propagation;
    # neither inserts a reset assumption or accepts bounded simulation as proof.
    budget=max(1,timeout//2)
    return ('[strategy smtbmc]\nuse sby\nengine smtbmc bitwuzla\nxprop on\ndepth 30\ntimeout '+str(budget)+'\n'
            '\n[strategy pdr]\nuse sby\nengine abc pdr\nxprop on\ntimeout '+str(budget)+'\n')


def equivalence(r):
    from .digital_flow import read_rtl
    from .digital_reports import eqy_report
    data=mapped(r)
    if any(c.isspace() for c in str(r.root)) or any(' ' in f['path'] for f in r.config['files']):
        raise ValueError('EQY requires run and source paths without spaces. Use a space-free jobs folder.')
    gold=read_rtl(r.config)+'\n'
    gate='\n'.join('read_liberty -ignore_miss_func '+quote(p) for p in r.libraries())
    # Lower memories before xprop. Follow EQY's synthesized-NERV recipe: retain
    # ports and direct FF outputs as match points, hiding combinational aliases.
    # Otherwise count and fifo.count can become inconsistent independent cuts.
    # State boundaries let induction establish FIFO memory/pointer invariants;
    # each boundary is itself proved, with all output logic retained.
    normalize='\nmemory_map\nopt_clean\n'
    state_points='rename -hide t:$*dff* %co x:* %% w:* %D\n'
    script='[gold]\n'+gold+'prep -top '+r.config['top']+' -flatten'+normalize+state_points+'\n[gate]\n'+gate+'\nread_verilog ../netlist.v\n'
    script+='hierarchy -check -top '+r.config['top']+'\nflatten\ntechmap -autoproc -map +/simcells.v\nprep -top '+r.config['top']+normalize
    # Carry the proved gold state definitions into consuming partitions. Memory
    # optimizations can duplicate an address register without preserving its
    # name; those gates still need the history behind a matched pointer/count.
    script+='\n[partition *]\namend *\n'
    # Encode undefined state explicitly; EQY's SAT strategy can prove this case vacuously.
    script+='\n'+proof_strategies(r.config.get('timeout',60))
    atomic_write(r.root/'equivalence.eqy',script)
    r.env['PATH']=str(Path(r.tools['eqy']).parent)+os.pathsep+r.env.get('PATH','')
    r.env['YOSYS']=r.tools['yosys']
    r.env['ABC']=r.tools['yosys-abc']
    r.command([r.tools['eqy'],'--yosys',r.tools['yosys'],'-f','-d','../proof','../equivalence.eqy'],
              'Proving the captured mapped netlist',fraction=.6,allow_failure=True)
    report=eqy_report(r.root/'proof');r.save_json('equivalence',report,'equivalence.json')
    for name in ('logfile.txt','partition.list','matched.ids'):
        if (r.root/'proof'/name).is_file():r.add_artifact('proof_'+name.replace('.','_'),r.root/'proof'/name)
    for i,name in enumerate(report['counterexamples']):r.add_artifact('counterexample_'+str(i),r.root/'proof'/name)
    if report['status']=='ERROR':raise ValueError('EQY could not complete a proof strategy. Inspect the retained proof logs.')
    return {**data,'equivalence':report,'verdict':report['status'],'summary':'Equivalence '+report['status']+' · captured mapped netlist'}


def run(job,directory,progress):
    from .digital_flow import validate_result
    from .digital import source_hash
    r=Runner(job,directory,progress);r.versions_check();stage=job['settings']['stage']
    if stage=='regression':
        from .digital_regression import execute
        data=execute(r)
    elif stage=='mapped':data=mapped(r)
    elif stage=='timing':data=timing(r)
    elif stage=='equivalence':data=equivalence(r)
    else:
        from .digital_physical import execute
        data=execute(r)
    r.add_artifact('log',r.log)
    from .digital_reports import diagnostics
    from .digital_identity import fingerprints, stage_key
    data.update(stage=stage,source_hash=source_hash(r.config),logic_hash=logic_identity(r.config),
                fingerprints=fingerprints(r.config),input_key=stage_key(r.config,stage,r.settings.get('simulator','icarus')),
                platform={key:r.platform.get(key) for key in ('name','corner','revision','fingerprint')} if r.platform else None,
                versions=r.versions,environment=job['environment'],artifacts=r.artifacts,
                diagnostics=diagnostics(r.log.read_text(),r.config['files']))
    result={'schema':1,'result_type':'digital','created':now(),'engine':'digital','project_id':job['project']['id'],
            'cell_id':job['cell'],'revision':job['project']['revision'],'design_hash':design_digest(job['project']),
            'settings':clone(job['settings']),'digital_result':data}
    validate_result(result,r.root);progress(1,data['summary']);return result
