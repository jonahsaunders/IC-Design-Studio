"""PDK device identities, safe symbol metadata, and numeric model parameters.

Upstream Xschem scripts are never executed. Formula defaults use a small
arithmetic interpreter; unsupported symbols remain visible with a reason.
"""
from __future__ import annotations
import ast, math, operator, re
from functools import lru_cache
from .model import clone, device, scalar, PINS

IDENT = re.compile(r'^[A-Za-z_][A-Za-z0-9_.$-]{0,127}$')
PIN_IDENT = re.compile(r'^[A-Za-z_][A-Za-z0-9_.$!-]{0,127}$')


def binding_for(technology, instance):
    simulation = technology.get('simulation', {})
    ref = instance.get('model_ref')
    if ref:
        lock = technology.get('package_lock', {})
        if ref.get('pdk') != lock.get('id') or ref.get('revision') != lock.get('revision'):
            raise ValueError(instance['name'] + ': model belongs to a different PDK revision. Relink or replace this device explicitly.')
        binding = simulation.get('catalog', {}).get(ref.get('device'))
        if not binding:
            raise ValueError(instance['name'] + ': model is absent from the linked PDK catalog.')
        if binding.get('kind') != instance['kind']:
            raise ValueError('Device kind does not match its PDK model.')
        if binding.get('unavailable'):
            raise ValueError(binding['unavailable'])
        return binding
    if instance['kind'] == 'PDK':
        raise ValueError('A PDK device requires a stable model reference.')
    if instance.get('model_mode') == 'generic':
        return None
    return simulation.get('devices', {}).get(instance['kind'])


@lru_cache(maxsize=2048)
def _formula_tree(text):
    if len(text) > 1000:
        raise ValueError('Model expression is too long.')
    text = re.sub(r'(?<![\w.])(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?:meg|[tgkmunpf])\b',lambda m:repr(scalar(m[0])),text,flags=re.I)
    tree = ast.parse(text, mode='eval')
    if len(list(ast.walk(tree))) > 150:
        raise ValueError('Model expression is too complex.')
    return tree


def numeric_formula(text, context):
    text = str(text).strip().strip('\\\"\'{}').strip()
    try:
        return scalar(text)
    except ValueError:
        pass
    tree = _formula_tree(text)
    ops = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}
    functions = {'int': int, 'abs': abs, 'min': min, 'max': max, 'sqrt': math.sqrt}
    def visit(n):
        if isinstance(n, ast.Constant) and type(n.value) in (int, float): return n.value
        if isinstance(n, ast.Name) and n.id.lower() in context: return context[n.id.lower()]
        if isinstance(n, ast.BinOp) and type(n.op) in ops: return ops[type(n.op)](visit(n.left), visit(n.right))
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)): return visit(n.operand) * (-1 if isinstance(n.op, ast.USub) else 1)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in functions and not n.keywords and 1 <= len(n.args) <= 4: return functions[n.func.id](*[visit(a) for a in n.args])
        raise ValueError('Unsupported or unresolved model expression: ' + text)
    value = float(visit(tree.body))
    if not math.isfinite(value): raise ValueError('Nonfinite model parameter.')
    return value


def _check_parameter(key, val, rule):
    if not math.isfinite(val):raise ValueError(key+' must be finite.')
    if 'fixed' in rule:
        expected=scalar(rule['fixed'])
        # Unit conversion can round the last bit (29.41u * 1e6). This is
        # numerical normalization, not a range of supported geometries.
        if not math.isclose(val,expected,rel_tol=1e-12,abs_tol=0):
            raise ValueError(key+' is fixed at '+str(rule['fixed'])+' by this PDK model; geometry scaling is unsupported.')
        val=expected
    if rule.get('choices') and val not in rule['choices'].values():
        # Unit conversion can round a numeric choice just as it can a fixed
        # geometry above. Return the unique canonical choice; never pick an
        # ambiguous neighbour or allow an absolute tolerance around zero.
        matches = {choice for choice in rule['choices'].values()
                   if math.isclose(val, choice, rel_tol=1e-12, abs_tol=0)}
        if len(matches) != 1:
            raise ValueError(key+' must be one of '+', '.join(rule['choices']))
        val = matches.pop()
    if rule.get('positive') and val<=0:raise ValueError(key+' must be positive.')
    if rule.get('integer') and val!=int(val):raise ValueError(key+' must be a whole number.')
    for bound,op in (('minimum',operator.lt),('maximum',operator.gt),('exclusive_minimum',operator.le)):
        if bound in rule and op(val,scalar(rule[bound])):raise ValueError(key+' is outside its PDK '+bound+' of '+str(rule[bound])+'.')
    return val


def parameter_values(binding, instance):
    definitions = binding.get('parameters', {})
    overrides = instance.get('model_params', {})
    if set(overrides) - set(definitions):
        raise ValueError('Unknown PDK parameter: ' + ', '.join(sorted(set(overrides) - set(definitions))))
    for key in overrides:
        if definitions[key].get('computed'):
            raise ValueError(key + ' is computed from its PDK parameters and cannot be overridden.')
    pending = {k: overrides.get(k, v['default']) for k, v in definitions.items()}
    resolved = {}
    if instance['kind'] in ('NMOS', 'PMOS'):
        for key in ('w', 'l'):
            resolved[key] = _check_parameter(key,scalar(instance['params'][key]) * binding.get('parameter_scale', {}).get(key, 1),definitions.get(key,{}))
            pending.pop(key, None)
    for _ in range(len(pending) + 1):
        for key, raw in list(pending.items()):
            rule = definitions[key]
            raw = rule.get('choices',{}).get(str(raw),raw)
            try: val = numeric_formula(raw, resolved)
            except (ValueError, SyntaxError, ZeroDivisionError): continue
            resolved[key] = _check_parameter(key,val,rule); del pending[key]
        if not pending:
            # A symbol may call its multiplier "mf" or another alias. Apply
            # the existing positive-m contract to the emitted SPICE parameter,
            # so changing its source-field name cannot bypass that contract.
            for emitted, source in binding.get('emit_parameters', {}).items():
                if emitted.casefold() == 'm':
                    _check_parameter(source, resolved[source], {'positive': True})
            return resolved
    raise ValueError('Cannot resolve PDK parameters: ' + ', '.join(pending))


def parameter_details(binding, instance):
    values=parameter_values(binding,instance);rows=[]
    for key,rule in binding.get('parameters',{}).items():
        intrinsic=instance['kind'] in ('NMOS','PMOS') and key in ('w','l')
        override=key in instance.get('model_params',{}) and not intrinsic
        raw=instance['params'][key] if intrinsic else instance.get('model_params',{}).get(key,rule['default'])
        rows.append({'name':key,'expression':str(raw),'value':values[key],
                     'source':'device dimension' if intrinsic else 'override' if override else 'default',
                     'unit':rule.get('unit','model units'),'derived':bool(rule.get('derived'))})
    return rows


def create_device(technology, key, name, x=0, y=0):
    entry = technology.get('simulation', {}).get('catalog', {}).get(key)
    if entry is None: raise ValueError('Unknown PDK catalog device.')
    if entry.get('unavailable'): raise ValueError(entry['unavailable'])
    lock = technology.get('package_lock', {})
    d = device(entry['kind'], name, x, y, nets={pin: 'open_' + name + '_' + pin for pin in entry['pin_order']},
               model_ref={'pdk': lock['id'], 'revision': lock['revision'], 'device': key}, model_params={})
    if entry.get('symbol'):
        d['symbol'] = clone(entry['symbol'])
        # Older locked catalogs exposed the hidden body graphically but retained
        # the original three-pin artwork order. Repair the new instance only.
        if any(str(note).startswith('Hidden body net exposed as terminal ') for note in entry.get('notes',[])) and set(d['symbol']['pins'])==set(entry['pin_order']):
            d['symbol']['pin_order']=list(entry['pin_order'])
    if d['kind'] in ('NMOS', 'PMOS'):
        for param in ('w', 'l'):
            d['params'][param] = f"{scalar(entry['parameters'][param]['default']) / entry.get('parameter_scale', {}).get(param, 1) * 1e6:.12g}u"
        from .sky130_defaults import initial_dimensions
        initial=initial_dimensions(technology,key,entry)
        if initial:
            d['params'].update({param:f'{value}u' for param,value in initial.items()})
    parameter_values(entry, d)
    return d


def import_emitted_parameters(binding, instance, values):
    """Retain live defaults on unchanged round trips; record real external edits."""
    mapping=binding.get('emit_parameters',{});derived={}
    for key,raw in values.items():
        key=key.lower()
        if key not in mapping:raise ValueError('Unknown PDK parameter '+key)
        source=mapping[key]
        if binding['parameters'][source].get('derived'):derived[source]=raw
        elif source in ('w','l') and instance['kind'] in ('NMOS','PMOS'):
            instance['params'][source]=str(scalar(raw)/binding.get('parameter_scale',{}).get(source,1))
        else:instance.setdefault('model_params',{})[source]=raw
    for source,raw in derived.items():
        current=parameter_values(binding,instance)[source]
        if not math.isclose(scalar(raw),current,rel_tol=1e-10,abs_tol=0):
            instance.setdefault('model_params',{})[source]=raw


def validate_catalog(tech):
    catalog = tech.get('simulation', {}).get('catalog', {})
    if not isinstance(catalog, dict) or len(catalog) > 10000: raise ValueError('Invalid PDK catalog.')
    for key, entry in catalog.items():
        if not isinstance(key, str) or len(key) > 256: raise ValueError('Invalid catalog identity.')
        if entry.get('unavailable'): continue
        if entry.get('kind') not in ('PDK', 'NMOS', 'PMOS', 'R', 'C', 'L'): raise ValueError('Unsupported catalog kind.')
        if not IDENT.fullmatch(entry.get('model', '')): raise ValueError('Invalid PDK model name.')
        if entry.get('prefix') not in ('X', 'M', 'R', 'C', 'L', 'D', 'Q'): raise ValueError('Invalid model prefix.')
        pins = entry.get('pin_order', [])
        if not pins or len(pins) > 128 or len(set(pins)) != len(pins) or any(not PIN_IDENT.fullmatch(p) for p in pins): raise ValueError('Invalid model terminals.')
        if entry['kind'] in PINS and set(pins) != set(PINS[entry['kind']]): raise ValueError('Model terminal mismatch.')
        for k in entry.get('parameters', {}):
            if not IDENT.fullmatch(k): raise ValueError('Invalid model parameter.')
            rule=entry['parameters'][k]
            if 'computed' in rule and (type(rule['computed']) is not bool or rule['computed'] and not rule.get('derived')):
                raise ValueError('Computed PDK parameters must use a derived expression: '+k)
            for bound in ('minimum','maximum','exclusive_minimum','fixed'):
                if bound in rule:scalar(rule[bound])
            if 'fixed' in rule:
                _check_parameter(k,scalar(rule['fixed']),rule)
                _check_parameter(k,scalar(rule['default']),rule)
            if 'minimum' in rule and 'maximum' in rule and scalar(rule['minimum'])>scalar(rule['maximum']):raise ValueError('PDK parameter minimum exceeds maximum: '+k)
            if 'exclusive_minimum' in rule and 'maximum' in rule and scalar(rule['exclusive_minimum'])>=scalar(rule['maximum']):raise ValueError('Empty PDK parameter interval: '+k)
        for key, source in entry.get('emit_parameters', {}).items():
            if not IDENT.fullmatch(key) or source not in entry.get('parameters', {}): raise ValueError('Invalid netlist parameter mapping.')


def link_technology(project, technology):
    """Transactional caller supplies a clone; never silently remap existing devices."""
    for cell in project['cells']:
        for d in cell['devices']:
            if d.get('model_ref'): binding_for(technology, d)
            elif binding_for(project['pdk'], d):
                if binding_for(technology, d) != binding_for(project['pdk'], d):
                    raise ValueError('Existing legacy PDK devices use a different binding. Convert or replace them before changing PDK.')
    used = {s['layer'] for c in project['cells'] for s in c['shapes']} | {s['layer'] for c in project['cells'] for s in c.get('layout_pins', [])+c.get('layout_texts', [])}
    old = {l['name']: l for l in project['pdk']['layers']}; new = {l['name']: l for l in technology['layers']}
    mapping={}
    for name in used:
        pair=(old[name]['gds'],old[name]['datatype']);matches=[l['name'] for l in technology['layers'] if (l['gds'],l['datatype'])==pair]
        if not matches or (name in new and (new[name]['gds'],new[name]['datatype'])!=pair):
            raise ValueError('Layout layer ' + name + ' needs an explicit technology mapping before changing PDK.')
        mapping[name]=name if name in matches else matches[0]
    for cell in project['cells']:
        for shape in cell['shapes']+cell.get('layout_pins',[])+cell.get('layout_texts',[]):
            if shape['layer'] in mapping:shape['layer']=mapping[shape['layer']]
    project['pdk'] = clone(technology)
    project['analysis']['corner'] = 'nominal'
