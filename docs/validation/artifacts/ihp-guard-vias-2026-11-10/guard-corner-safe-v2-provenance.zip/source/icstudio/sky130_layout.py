"""Editable, one-to-eight-finger SKY130 MOS layouts in integer nanometres.

This is a bounded Studio generator, not the upstream Magic PCell generator.
Actual DRC and extracted LVS are separate gates, including after manual edits.
"""
from .model import clone, digest, scalar, uid, validate, example, device
from .catalog import binding_for, parameter_values, create_device, link_technology
from .layout import rect

MASKS = {'diff': (65,20), 'tap': (65,44), 'nwell': (64,20),
         'nsdm': (93,44), 'psdm': (94,20), 'poly': (66,20),
         'npc': (95,20), 'licon': (66,44), 'li': (67,20),
         'mcon': (67,44), 'm1': (68,20), 'via': (68,44),
         'm2': (69,20), 'm1label': (68,5), 'm2label': (69,5)}
MODELS = {'NMOS': 'sky130_fd_pr__nfet_01v8', 'PMOS': 'sky130_fd_pr__pfet_01v8'}
THRESHOLD_MASKS = {'sky130_fd_pr__nfet_01v8_lvt': (125,44),
                   'sky130_fd_pr__pfet_01v8_lvt': (125,44),
                   'sky130_fd_pr__pfet_01v8_hvt': (78,44),
                   'sky130_fd_pr__nfet_03v3_nvt': (125,44),
                   'sky130_fd_pr__nfet_05v0_nvt': (125,44)}
VOLTAGE_MODELS = ('sky130_fd_pr__nfet_g5v0d10v5', 'sky130_fd_pr__pfet_g5v0d10v5',
                  'sky130_fd_pr__nfet_03v3_nvt', 'sky130_fd_pr__nfet_05v0_nvt')
# Nominal per-finger W/L bin centers in the bundled native model definitions.
# This recipe uses centers only; the surrounding numerical bin windows are not
# an independently qualified continuous geometry envelope.
NATIVE_SIZES = {
    'sky130_fd_pr__nfet_03v3_nvt': ((10000,500),(1000,500),(1000,600),(4000,500),
        (420,500),(420,600),(420,800),(700,500),(700,600)),
    'sky130_fd_pr__nfet_05v0_nvt': ((10000,2000),(10000,4000),(10000,900),
        (1000,25000),(1000,2000),(1000,4000),(1000,8000),(1000,900),(420,1000),(420,900),(700,900)),
}
API = 1


def resolved(p,cid,d):
    from .design_ops import resolved_device,parameters
    cell=next(c for c in p['cells'] if c['id']==cid)
    return resolved_device(d,parameters(cell.get('parameters',{}),parameters(p.get('parameters',{}))))


def layers(tech):
    if tech.get('package_lock',{}).get('id') != 'sky130A':
        raise ValueError('This generator requires a linked SKY130A PDK.')
    by = {(l['gds'], l['datatype']): l['name'] for l in tech['layers']}
    missing = [k for k,v in MASKS.items() if v not in by]
    if missing: raise ValueError('PDK is missing required masks: '+', '.join(missing))
    return {k: by[v] for k,v in MASKS.items()}


def specification(tech, d):
    if d['kind']=='PDK':
        from .sky130_devices import specification as passive_specification
        return passive_specification(tech,d)
    layers(tech)
    b = binding_for(tech,d)
    from .process_mos import SKY130_MODELS
    if not b or b['model'] not in SKY130_MODELS.get(d['kind'], ()) or set(d['nets']) != {'d','g','s','b'}:
        raise ValueError(d['name']+': select a supported four-terminal SKY130 MOS.')
    mask = THRESHOLD_MASKS.get(b['model'])
    if mask and not any((v['gds'],v['datatype'])==mask for v in tech['layers']):
        raise ValueError('PDK is missing the required threshold implant mask.')
    if b['model'] in VOLTAGE_MODELS:
        required={(75,20)}
        if d['kind']=='NMOS':required.add((125,20))
        if b['model']=='sky130_fd_pr__nfet_03v3_nvt':required.add((81,60))
        if not required<={(v['gds'],v['datatype']) for v in tech['layers']}:
            raise ValueError('PDK is missing required voltage or native-identification masks.')
    values = parameter_values(b,d)
    from .process_mos import dimensions
    geometry = dimensions(tech, d, b)
    nf=values.get('nf',1)
    if nf!=int(nf) or not 1<=nf<=8 or geometry['multiplicity']>16:
        raise ValueError(d['name']+': this layout supports 1–8 fingers and 1–16 parallel copies.')
    size = {}
    minimum_length = (900 if b['model']=='sky130_fd_pr__nfet_05v0_nvt' else
                      500 if b['model'] in VOLTAGE_MODELS else
                      350 if b['model']=='sky130_fd_pr__pfet_01v8_lvt' else 150)
    for k, minimum in (('w',420),('l',minimum_length)):
        maximum=(30000 if k=='w' else 25000 if b['model']=='sky130_fd_pr__nfet_05v0_nvt' else 10000)
        raw = (geometry['total_width'] if k == 'w' else geometry['length'])*1e9
        value = round(raw)
        if abs(raw-value)>1e-6 or value%5 or not minimum<=value<=maximum:
            raise ValueError(d['name']+f': {k.upper()} must be on the 5 nm grid, from {minimum/1000:g} to {maximum/1000:g} µm.')
        size[k]=value
    if size['w']%int(nf) or size['w']//int(nf)<420 or (size['w']//int(nf))%5:
        raise ValueError(d['name']+': total W divided by nf must be at least 0.42 µm on the 5 nm grid.')
    if b['model'] in NATIVE_SIZES and (size['w']//int(nf),size['l']) not in NATIVE_SIZES[b['model']]:
        raise ValueError(d['name']+': native MOS layout requires a supported nominal per-finger W/L model bin.')
    if size['l']>10000 and nf!=1:
        raise ValueError(d['name']+': the 25 µm native recipe requires one finger; use separate parallel copies.')
    # The shared contract resolves the catalog's explicit per-finger W * nf
    # template to total W. Geometry and netlisting now use the same dimensions.
    result={'api':API,'model_ref':clone(d.get('model_ref')),'model':b['model'],
            'kind':d['kind'],'dimensions_nm':size,'values':values,'nets':clone(d['nets'])}
    if geometry['multiplicity']>1:result['multiplicity']=geometry['multiplicity']
    if d.get('physical_body_tie'):
        if d['physical_body_tie']!='source' or d['nets']['s']!=d['nets']['b']:
            raise ValueError('A source body tie requires source and body on the same explicit schematic net.')
        result['body_tie']='source'
    if d.get('physical_dummy'):
        if len(set(d['nets'].values()))!=1:raise ValueError('A physical MOS dummy requires every terminal tied to the same reference net.')
        result['dummy']=True
    return result


def threshold_geometry(tech,d,data):
    """Add the drawn Vt implant around every channel, before parallel copying.

    Public lvtn.4b/hvtp.3 enclose the channel by 180 nm. A single rectangle
    spans shared fingers. PMOS LVT additionally retains 380 nm of NWell above
    the implant (lvtn.10). Ordinary MOS output is unchanged.
    """
    pair=THRESHOLD_MASKS.get(data['record']['spec']['model'])
    if pair is None:return data
    from .layout import kdb,polygon
    ls=layers(tech);db=kdb();active=db.Region();poly=db.Region()
    for shape in data['shapes']:
        if shape['layer']==ls['diff']:active.insert(polygon(shape))
        elif shape['layer']==ls['poly']:poly.insert(polygon(shape))
    channels=active & poly
    if channels.is_empty():raise ValueError('Threshold implant requires physical MOS channels.')
    bounds=channels.bbox().enlarged(180)
    layer=next(v['name'] for v in tech['layers'] if (v['gds'],v['datatype'])==pair)
    shape=rect(layer,bounds.left,bounds.bottom,bounds.width(),bounds.height(),d['id'])
    shape.update(generated_device=d['id'],generator_role='threshold_implant')
    data['shapes'].append(shape)
    if d['kind']=='PMOS' and pair==(125,44):
        # Only the upper well edge needs enlargement for the existing generator.
        for well in data['shapes']:
            if well['layer']==ls['nwell']:
                high=max(y for x,y in well['points'])
                well['points']=[[x,max(y,bounds.top+380) if y==high else y] for x,y in well['points']]
    return data


def voltage_geometry(tech,d,data):
    """Retain explicit thick oxide, N-tip implant and 3.3 V native identity.

    HVI encloses active/tap by 180 nm (hvdifftap.22); for PMOS it coincides
    with the existing NWell to satisfy hvi.5. HVNTM encloses NMOS active by
    185 nm (hvntm.3). The locked Magic mapping uses 81/60 around the channel
    to distinguish the 3.3 V native model; this marker is not an extra mask.
    """
    model=data['record']['spec']['model']
    if model not in VOLTAGE_MODELS:return data
    from .layout import kdb,polygon
    ls=layers(tech);db=kdb();regions={}
    spec=data['record']['spec']
    if model=='sky130_fd_pr__nfet_05v0_nvt' and spec['dimensions_nm']['l']>10000:
        # LU.2 requires a P-tap within 15 um of each N-diffusion. The 25 um
        # native model needs a second contacted body tap at the drain end.
        # Its separate metal rail connects to the original body access.
        body=next(p['point'] for p in data['pins'] if p['pin']=='b')
        ox,oy=data['record']['origin'];length=spec['dimensions_nm']['l']
        width=spec['dimensions_nm']['w']//int(spec['values'].get('nf',1))
        nf=int(spec['values'].get('nf',1));px=ox+(nf-1)*(length+1000)+length+2200;py=body[1]
        for key,half in [('tap',250),('psdm',380),('licon',85),('li',170),('mcon',85),('m1',170)]:
            shape=rect(ls[key],px-half,py-half,2*half,2*half,d['id'],d['nets']['b'] if key in ('li','m1') else '')
            shape.update(generated_device=d['id'],generator_role='long_channel_body_'+key);data['shapes'].append(shape)
        rail=oy+width+1500
        data['shapes'].append(dict(id=uid(),kind='path',layer=ls['m1'],points=[clone(body),[body[0],rail],[px,rail],[px,py]],
            width=340,net=d['nets']['b'],device_id=d['id'],generated_device=d['id'],generator_role='long_channel_body_rail'))
    for key in ('diff','tap','poly','nwell'):
        regions[key]=db.Region([polygon(s) for s in data['shapes'] if s['layer']==ls[key]])
    by={(v['gds'],v['datatype']):v['name'] for v in tech['layers']}
    def add(pair,bounds,role):
        shape=rect(by[pair],bounds.left,bounds.bottom,bounds.width(),bounds.height(),d['id'])
        shape.update(generated_device=d['id'],generator_role=role);data['shapes'].append(shape)
    bounds=(regions['nwell'].bbox() if d['kind']=='PMOS' else
            (regions['diff']|regions['tap']).bbox().enlarged(180))
    add((75,20),bounds,'thick_oxide')
    if d['kind']=='NMOS':add((125,20),regions['diff'].bbox().enlarged(185),'high_voltage_ntip')
    if model=='sky130_fd_pr__nfet_03v3_nvt':
        add((81,60),(regions['diff']&regions['poly']).bbox().enlarged(100),'native_3v3_identifier')
    return data


def mos(tech,d,x=0,y=0):
    if d['kind']=='PDK':
        from .sky130_devices import geometry
        return geometry(tech,d,x,y)
    spec=specification(tech,d);ls=layers(tech);w,l=(spec['dimensions_nm'][k] for k in ('w','l'))
    if any(type(v) is not int or v%5 for v in (x,y)):raise ValueError('Placement must be on the 5 nm grid.')
    if int(spec['values'].get('nf',1))>1:
        from .sky130_fingers import generate
        from .sky130_devices import finish_mos, parallel_geometry
        return parallel_geometry(tech,d,finish_mos(tech,d,voltage_geometry(tech,d,threshold_geometry(tech,d,generate(tech,d,x,y,spec)))),spec.get('multiplicity',1))
    shapes=[];pins=[]
    def box(key,a,b,c,e,net=''):
        s=rect(ls[key],x+a,y+b,c-a,e-b,d['id'],net);s['generated_device']=d['id'];shapes.append(s)
    # Wide access regions deliberately leave room for manual routing and labels.
    box('diff',-800,0,l+800,w)
    implant='psdm' if d['kind']=='PMOS' else 'nsdm'
    box(implant,-930,-130,l+930,w+130)
    box('poly',0,-800,l,w+300)
    gate=5*round(l/10);cy=5*round(w/10)
    box('poly',gate-220,-820,gate+220,-380)
    box('npc',gate-320,-920,gate+320,-280)
    box('tap',-2450,cy-250,-1950,cy+250)
    box('nsdm' if d['kind']=='PMOS' else 'psdm',-2580,cy-380,-1820,cy+380)
    if d['kind']=='PMOS':box('nwell',-2820,-1200,l+1180,max(w+400,cy+620))
    for pin,px,py in [('s',-500,cy),('d',l+500,cy),('g',gate,-600),('b',-2200,cy)]:
        net=d['nets'][pin]
        for key,half in [('licon',85),('li',170),('mcon',85),('m1',170)]:
            box(key,px-half,py-half,px+half,py+half,net if key in ('li','m1') else '')
        pins.append({'id':uid(),'device_id':d['id'],'pin':pin,'layer':ls['m1'],'point':[x+px,y+py]})
    from .layout_eco import roles
    from .sky130_devices import finish_mos, parallel_geometry
    return parallel_geometry(tech,d,finish_mos(tech,d,voltage_geometry(tech,d,threshold_geometry(tech,d,roles({'shapes':shapes,'pins':pins,'record':{'device_id':d['id'],'spec':spec,'origin':[x,y]}})))),spec.get('multiplicity',1))


def install_mos(p,cid,did,x=0,y=0):
    c=next(c for c in p['cells'] if c['id']==cid);d=resolved(p,cid,next(d for d in c['devices'] if d['id']==did))
    data=mos(p['pdk'],d,x,y)
    old=next((r for r in c.get('pdk_layouts',[]) if r['device_id']==did),None)
    if old:
        raise ValueError('This device already has generated geometry. Use Regenerate linked layout to review replacement.')
    c['shapes'].extend(data['shapes']);c.setdefault('layout_pins',[]).extend(data['pins']);c.setdefault('pdk_layouts',[]).append(data['record'])
    configure_connectivity(p['pdk']);return data


def configure_connectivity(tech):
    ls=layers(tech)
    cfg=tech.setdefault('connectivity',{})
    cfg['conductors']=list(dict.fromkeys(cfg.get('conductors',[])+[ls['li'],ls['m1'],ls['m2']]))
    for row in [[ls['li'],ls['mcon'],ls['m1']],[ls['m1'],ls['via'],ls['m2']]]:
        if row not in cfg.setdefault('vias',[]):cfg['vias'].append(row)
    # Full indexed SKY130 technologies include the MiM masks; minimal legacy
    # fixtures retain their MOS-only connectivity mapping.
    if any((v['gds'],v['datatype'])==(89,44) for v in tech['layers']):
        from .sky130_devices import configure_connectivity as configure_devices
        configure_devices(tech)


def regenerate_mos(p,cid,did):
    from .layout_eco import regenerate
    return regenerate(p,cid,did)


def inverter_devices(p,cid):
    c=next(c for c in p['cells'] if c['id']==cid)
    if len(c['devices'])!=2 or {d['kind'] for d in c['devices']}!={'NMOS','PMOS'}:
        raise ValueError('Select an inverter cell containing exactly one NMOS and one PMOS; keep sources and load in a separate testbench.')
    n=resolved(p,cid,next(d for d in c['devices'] if d['kind']=='NMOS'));q=resolved(p,cid,next(d for d in c['devices'] if d['kind']=='PMOS'))
    for d in (n,q):specification(p['pdk'],d)
    a,b=n['nets'],q['nets']
    if not (a['d']==b['d'] and a['g']==b['g'] and a['s']==a['b'] and b['s']==b['b'] and len({a['d'],a['g'],a['s'],b['s']})==4):
        raise ValueError('Inverter needs common gates/input and drains/output, with each body tied to its own source supply.')
    if set(c['ports'])!={a['g'],a['d'],a['s'],b['s']}:
        raise ValueError('Expose the inverter input, output, power and ground as four cell ports.')
    return n,q


def generate_inverter(p,cid,replace=False):
    c=next(c for c in p['cells'] if c['id']==cid);n,q=inverter_devices(p,cid);ls=layers(p['pdk'])
    if c['shapes'] or c.get('layout_instances'):
        if not replace:raise ValueError('This cell already contains layout. Review regeneration before replacing it.')
        if not c.get('inverter_layout'):raise ValueError('Regeneration only replaces a cell previously created by the inverter generator.')
    c['shapes']=[];c['layout_pins']=[];c['layout_texts']=[];c['layout_ports']=[];c['pdk_layouts']=[];c['layout_instances']=[]
    ns=specification(p['pdk'],n);nw=ns['dimensions_nm']['w'];py=nw+5000
    if ns.get('multiplicity',1)>1:
        from .layout import polygon
        py=max(py,max(polygon(shape).bbox().top for shape in mos(p['pdk'],n)['shapes'])+5000)
    for d,y in ((n,0),(q,py)):install_mos(p,cid,d['id'],0,y)
    pins={(r['device_id'],r['pin']):r['point'] for r in c['layout_pins']}
    def wire(key,points,net):
        c['shapes'].append({'id':uid(),'kind':'path','layer':ls[key],'points':points,'width':340,'net':net,'device_id':'','generated_route':True})
    for d in (n,q):wire('m1',[pins[d['id'],'b'],pins[d['id'],'s']],d['nets']['s'])
    nd,pd=pins[n['id'],'d'],pins[q['id'],'d'];right=max(nd[0],pd[0])+1000
    wire('m1',[nd,[right,nd[1]],[right,pd[1]],pd],n['nets']['d'])
    ng,pg=pins[n['id'],'g'],pins[q['id'],'g']
    wire('m2',[ng,[ng[0],pg[1]],pg] if ng[0]!=pg[0] else [ng,pg],n['nets']['g'])
    for px,yy in (ng,pg):
        for key,half in [('via',75),('m2',170)]:c['shapes'].append(rect(ls[key],px-half,yy-half,2*half,2*half,net=n['nets']['g'] if key=='m2' else ''))
    # Text uses actual PDK label datatypes, not decorative names on drawing layers.
    for net,key,pt in [(n['nets']['s'],'m1label',pins[n['id'],'b']), (q['nets']['s'],'m1label',pins[q['id'],'b']), (n['nets']['d'],'m1label',[right,nd[1]]), (n['nets']['g'],'m2label',ng)]:
        c['layout_texts'].append({'layer':ls[key],'text':net,'x':pt[0],'y':pt[1],'rotation':0})
    from .physical_cells import assign_port
    for net,key,pt in [(n['nets']['s'],'m1',pins[n['id'],'b']),(q['nets']['s'],'m1',pins[q['id'],'b']),(n['nets']['d'],'m1',[right,nd[1]]),(n['nets']['g'],'m2',ng)]:assign_port(p,cid,net,ls[key],pt)
    c['inverter_layout']={'api':API,'device_ids':[n['id'],q['id']]}
    c['layout_label_mode']='explicit'
    validate(p);return p


def audit(p,cid):
    c=next(c for c in p['cells'] if c['id']==cid);ds={d['id']:d for d in c['devices']};issues=[]
    for r in c.get('pdk_layouts',[]):
        d=ds.get(r['device_id']);message=''
        if d is None:message='Generated layout belongs to a deleted schematic device.'
        else:
            try:
                if specification(p['pdk'],resolved(p,cid,d))!=r['spec']:message=d['name']+': model, dimensions, parameters or nets changed. Regenerate and verify the layout.'
            except ValueError as e:message=str(e)
        if message:issues.append({'severity':'error','code':'PDK.STALE','object':r['device_id'],'message':message,'fingerprint':digest(message)})
    return issues


def reference_project(tech):
    layers(tech)
    p=example('empty');link_technology(p,tech);p['name']='Custom SKY130 inverter';top=p['cells'][0];top['name']='testbench'
    c={'id':uid(),'name':'custom_inverter','ports':['A','Y','VPWR','VGND'],'devices':[],'shapes':[]}
    p['cells'].append(c)
    catalog=tech['simulation']['catalog']
    for kind,name,width,supply in [('NMOS','MN1','1u','VGND'),('PMOS','MP1','2u','VPWR')]:
        key=next(k for k,b in catalog.items() if not b.get('unavailable') and b['model']==MODELS[kind] and b['pin_order']==['d','g','s','b'] and b.get('emit_parameters',{}).get('w')=='w')
        d=create_device(p['pdk'],key,name,350,400 if kind=='NMOS' else 180);d['params'].update(w=width,l='0.15u');d['nets']={'d':'Y','g':'A','s':supply,'b':supply};c['devices'].append(d)
    top['devices']=[device('V','VDD',140,180,value='1.8',nets={'p':'vdd','n':'0'}),device('V','VIN',140,400,nets={'p':'vin','n':'0'},source={'type':'pulse','low':'0','high':'1.8','period':'20n','delay':'2n','duty':'0.5','ac':'1'}),device('X','XINV',400,280,cell=c['id'],nets={'A':'vin','Y':'vout','VPWR':'vdd','VGND':'0'}),device('C','CL',650,280,value='5f',nets={'p':'vout','n':'0'})]
    p['analysis'].update(type='tran',step='20p',stop='62n',corner='nominal')
    from .wiring import migrate
    for cell in p['cells']:migrate(cell,p)
    return validate(p),c['id']
