"""Revision-based team review inside the existing Tools collaboration dashboard."""
import uuid
from PySide6.QtCore import Qt, QRectF, QTimer
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QComboBox,QPushButton,
    QTreeWidget,QTreeWidgetItem,QPlainTextEdit,QCheckBox,QInputDialog,QFileDialog,QDialog,QHeaderView,QMessageBox)
from .model import clone,save_project,digest


class RevisionComparison(QDialog):
    def __init__(self,parent,before,after):
        super().__init__(parent)
        from .collaboration_dashboard import note
        from .collaboration_review_ui import GeometryView,description,show_schematics,object_title
        from .collaboration_document import diff, SCHEMATIC_FIELDS, STRUCTURE
        self.setWindowTitle('Compare design revisions');self.resize(1000,650)
        root=QVBoxLayout(self);root.addWidget(note('Changed geometry and objects. The left view is the saved checkpoint; the right view is the comparison revision.'))
        rows=diff(before,after)
        self.cells=QComboBox();self.cells.setAccessibleName('Changed cell');root.addWidget(self.cells)
        by={c['id']:c['name'] for c in before['cells']+after['cells']}
        for cid in dict.fromkeys(r['cell'] for r in rows):self.cells.addItem(by.get(cid,cid),cid)
        self.view_mode=QComboBox();self.view_mode.addItems(['Layout','Schematic']);self.view_mode.setAccessibleName('Comparison view')
        self.view_mode.setCurrentIndex(int(any(r['field'] in set(SCHEMATIC_FIELDS)|STRUCTURE for r in rows)));root.addWidget(self.view_mode)
        views=QHBoxLayout();self.views=[GeometryView('Checkpoint','#d58b2b'),GeometryView('Comparison','#427ce8')]
        for v in self.views:views.addWidget(v)
        root.addLayout(views,1);self.table=QTreeWidget();self.table.setHeaderLabels(['Object','Checkpoint','Comparison']);root.addWidget(self.table,1)
        self.table.setColumnWidth(0,200);self.table.setColumnWidth(1,340);self.table.header().setStretchLastSection(True)
        self.status=note('');root.addWidget(self.status)
        def draw():
            local=[r for r in rows if r['cell']==self.cells.currentData()];self.table.clear();groups=[[],[]]
            for r in local[:2000]:
                item=QTreeWidgetItem([object_title(r,before,after),description(r['before']),description(r['after'])])
                for col in range(3):item.setToolTip(col,item.text(col))
                item.setToolTip(0,item.text(0)+'\n'+str(r['key']))
                self.table.addTopLevelItem(item)
                if r['field']=='shapes':
                    for i,key in enumerate(('before','after')):
                        if r[key]:groups[i].append(r[key])
            if self.view_mode.currentIndex()==1:
                show_schematics(self.views,[before,after],self.cells.currentData(),local)
                self.status.setText(f'{len(local)} changed objects or settings. Complete cell schematics shown; first 2,000 changes listed.' if len(local)>2000 else f'{len(local)} changed objects or settings. Changed objects are highlighted; wheel to zoom and drag to pan.')
                return
            points=[p for g in groups for s in g for p in s['points']]
            if len(points)>60000:groups=[[],[]];points=[]
            if points:
                xs,ys=zip(*points);box=QRectF(min(xs),min(ys),max(xs)-min(xs),max(ys)-min(ys));margin=max(box.width(),box.height(),100)*.15;box=box.adjusted(-margin,-margin,margin,margin)
            else:box=QRectF(-100,-100,200,200)
            for view,group in zip(self.views,groups):view.show_shapes(group,box)
            self.status.setText(f'{len(local)} changed objects in this cell. '+('First 2,000 listed; export the checkpoint for complete inspection.' if len(local)>2000 else 'Wheel to zoom; drag to pan.'))
        self.cells.currentIndexChanged.connect(draw);self.view_mode.currentIndexChanged.connect(draw);draw()


class TeamReviewPanel(QWidget):
    def __init__(self,studio,parent=None):
        super().__init__(parent);self.studio=studio;self.busy=False;self.client=None;self.data={};self.failed_request=None;self.loaded_version=None;self.reply_to=None;self.filled_checkpoint=None
        from .collaboration_dashboard import note
        root=QVBoxLayout(self);self.note=note('Join a live workspace to save checkpoints, discuss objects, and review exact revisions.');root.addWidget(self.note)
        row=QHBoxLayout();self.checkpoints=QComboBox();self.checkpoints.setAccessibleName('Review checkpoint');row.addWidget(self.checkpoints,1)
        self.add_button=self.button('Save checkpoint…',self.create,row);self.button('Refresh',self.load,row);root.addLayout(row)
        row=QHBoxLayout();self.other=QComboBox();self.other.setAccessibleName('Compare checkpoint with');row.addWidget(self.other,1)
        self.button('Compare revisions',self.compare,row);self.button('Save checkpoint copy…',self.export_checkpoint,row);root.addLayout(row)
        self.decisions=note('');root.addWidget(self.decisions)
        self.comments=QTreeWidget();self.comments.setHeaderLabels(['Author / object','Comment','State']);self.comments.setAccessibleName('Checkpoint discussions');root.addWidget(self.comments,1)
        self.comments.setMinimumHeight(160);self.comments.setWordWrap(True)
        self.comments.header().setSectionResizeMode(0,QHeaderView.ResizeToContents);self.comments.header().setSectionResizeMode(1,QHeaderView.Stretch);self.comments.header().setSectionResizeMode(2,QHeaderView.ResizeToContents)
        self.comments.itemDoubleClicked.connect(lambda *_:self.call(self.read_comment))
        self.comment=QPlainTextEdit();self.comment.setPlaceholderText('Ask a question or explain the change…');self.comment.setAccessibleName('New review comment');self.comment.setMaximumHeight(85);root.addWidget(self.comment)
        self.drafts=None;self._loading_draft=False;self.draft_error=None
        self.comment.setEnabled(False)
        self.draft_note=note('Unsent text is saved locally for this checkpoint.');root.addWidget(self.draft_note)
        self.draft_timer=QTimer(self);self.draft_timer.setSingleShot(True);self.draft_timer.setInterval(150)
        self.draft_timer.timeout.connect(self.flush_draft);self.comment.textChanged.connect(self.draft_changed)
        self.reply_note=note('');root.addWidget(self.reply_note)
        row=QHBoxLayout();self.anchor=QCheckBox('Attach to current selection');row.addWidget(self.anchor,1)
        self.anchor_kind=QComboBox();self.anchor_kind.addItems(['Object','Terminal','Highlighted net','Electrical finding']);self.anchor_kind.setAccessibleName('Comment attachment type');row.addWidget(self.anchor_kind)
        root.addLayout(row);row=QHBoxLayout()
        self.comment_button=self.button('Post comment',self.post_comment,row);self.button('Read comment',self.read_comment,row);self.button('Go to object',self.navigate,row);root.addLayout(row)
        row=QHBoxLayout();self.reply_button=self.button('Reply to discussion',self.start_reply,row);self.cancel_reply_button=self.button('Cancel reply',self.cancel_reply,row);self.cancel_reply_button.hide()
        self.resolve_button=self.button('Resolve / reopen',self.resolve,row);root.addLayout(row)
        row=QHBoxLayout();self.decision=QComboBox();self.decision.setAccessibleName('Review decision')
        for label,value in [('Request review','review_requested'),('Approve checkpoint','approved'),('Request changes','changes_requested')]:self.decision.addItem(label,value)
        row.addWidget(self.decision,1);self.decision_button=self.button('Record decision',self.decide,row);root.addLayout(row)
        self.reports=QComboBox();self.reports.setAccessibleName('Shared verification result');root.addWidget(self.reports)
        row=QHBoxLayout();self.share_button=self.button('Share completed run…',self.share_report,row);self.button('Inspect result',self.inspect_report,row);self.button('Re-run saved input',self.rerun_report,row);root.addLayout(row)
        self.retry_button=self.button('Retry last action',self.retry,root);self.retry_button.hide()
        self.outbox=None
        self.pending_note=note('');root.addWidget(self.pending_note)
        self.discard_button=self.button('Discard saved review action…',self.discard_pending,root);self.discard_button.hide()
        self.checkpoints.currentIndexChanged.connect(lambda *_:self.call(self.fill))

    def draft_changed(self):
        if self._loading_draft:return
        self.draft_note.setText('Saving draft locally…' if self.drafts and self.filled_checkpoint else 'Select a checkpoint to save this draft.')
        self.draft_timer.start()

    def flush_draft(self):
        self.draft_timer.stop()
        if self._loading_draft:return True
        if not self.drafts or not self.filled_checkpoint:
            return not bool(self.comment.toPlainText())
        try:
            self.drafts.save(self.filled_checkpoint,self.comment.toPlainText(),self.reply_to)
            self.draft_error=None
            self.draft_note.setText('Draft saved locally · not posted' if self.comment.toPlainText() else 'Unsent text is saved locally for this checkpoint.')
            return True
        except (OSError,ValueError) as exc:
            self.draft_error=str(exc);self.draft_note.setText('Draft save failed. Text remains here; retry before closing. '+str(exc));return False

    def restore_draft(self):
        draft=self.drafts.get(self.filled_checkpoint) if self.drafts else dict(text='',reply='')
        self._loading_draft=True
        try:
            self.comment.setPlainText(draft['text']);self.cancel_reply()
            if draft['reply']:
                self.reply_to=draft['reply'];self.comment_button.setText('Post reply');self.cancel_reply_button.show()
                self.anchor.setEnabled(False);self.anchor_kind.setEnabled(False)
                self.reply_note.setText('Restored reply to the saved discussion. Reopen a resolved discussion before posting.')
            self.anchor.setChecked(False)
            self.comment.setEnabled(bool(self.filled_checkpoint) and self.drafts is not None)
            self.draft_note.setText('Draft recovery unavailable for this session.' if not self.drafts else 'Restored unsent draft · review attachments before posting' if draft['text'] else 'Unsent text is saved locally for this checkpoint.')
        finally:self._loading_draft=False

    def hideEvent(self,event):
        self.flush_draft();super().hideEvent(event)

    def button(self,label,fn,layout):
        button=QPushButton(label);button.clicked.connect(lambda _=False:self.call(fn));layout.addWidget(button);return button

    def call(self,fn):
        try:return fn()
        except Exception as exc:self.note.setText(str(exc))

    def update_permissions(self):
        client=self.studio.live_client
        edit=bool(client and client.connected and client.info['role'] in ('owner','edit'))
        review=bool(client and client.connected and client.info['role'] in ('owner','edit','review'))
        for b in (self.add_button,self.share_button):b.setEnabled(edit and not self.busy)
        for b in (self.comment_button,self.decision_button,self.resolve_button):b.setEnabled(review and not self.busy)
        self.reply_button.setEnabled(review and not self.busy and client.info.get('review_api',0)>=2)
        if hasattr(self,'outbox'):self.show_pending()

    def refresh_state(self):
        client=self.studio.live_client;self.update_permissions()
        if self.client is not client:
            if self.client and not self.flush_draft():return
            self._loading_draft=True;self.drafts=None;self.filled_checkpoint=None;self.comment.setEnabled(False)
            self.client=client;self.data={};self.loaded_version=None;self.checkpoints.clear();self.comments.clear();self.reports.clear();self.failed_request=None;self.retry_button.hide();self.cancel_reply()
            self.comment.clear();self._loading_draft=False
            self.outbox=None
            if client:
                from .review_outbox import ReviewOutbox
                from .review_drafts import ReviewDrafts
                try:self.drafts=ReviewDrafts(client.journal.with_suffix('.review-drafts'),client.server,client.workspace,client.info['actor'])
                except (ValueError,OSError) as exc:self.draft_note.setText('Draft recovery unavailable: '+str(exc))
                try:self.outbox=ReviewOutbox(client.journal.with_suffix('.review-outbox'),client.server,client.workspace,client.info['actor'])
                except (ValueError,OSError) as exc:self.pending_note.setText(str(exc));return
                if self.outbox.pending:self.failed_request=(self.outbox.pending,lambda _:self.load())
            self.show_pending()
        if client and self.isVisible() and not self.busy and self.loaded_version!=client.info.get('review_version'):
            self.call(self.load)

    def showEvent(self,event):
        super().showEvent(event);self.refresh_state()

    def request(self,data,callback,mutation=False):
        client=self.studio.live_client
        if client is None:raise ValueError('Share or join a live workspace first.')
        if self.client is not client:raise ValueError('Save the previous session draft before using this workspace.')
        if not client.info.get('review_api'):raise ValueError('This server needs the team-review update. Ask the host to update IC Design Studio.')
        if self.busy:raise ValueError('The previous review request is still running.')
        if mutation:
            if self.outbox is None:raise ValueError('Review recovery storage is unavailable. Reopen the collaboration dashboard before posting.')
            data.setdefault('id',uuid.uuid4().hex)
            self.outbox.stage(data)
            self.failed_request=(data,callback);self.show_pending()
        self.busy=True;self.update_permissions()
        def finished(status,result):
            self.busy=False;self.update_permissions()
            if self.studio.live_client is not client:return
            if status!=200:
                self.note.setText(result.get('error','Review request failed.'))
                if mutation:
                    self.call(lambda:self.outbox.failed(data['id'],result.get('error','Review request failed.')))
                    self.show_pending()
                return
            if mutation:
                if self.drafts:
                    try:self.drafts.acknowledge(data)
                    except (OSError,ValueError) as exc:
                        self.note.setText('Action accepted; draft cleanup failed. Retry safely: '+str(exc));self.show_pending();return
                try:self.outbox.acknowledge(data['id'])
                except OSError as exc:self.note.setText('Action accepted; local recovery cleanup failed. Retry safely: '+str(exc));self.show_pending();return
                if (data.get('action') in ('comment','reply','decide') and self.filled_checkpoint==data.get('checkpoint')
                        and self.comment.toPlainText()==data.get('text') and (self.reply_to or '')==data.get('parent','')):
                    self.draft_timer.stop();self._loading_draft=True
                    try:self.comment.clear();self.cancel_reply()
                    finally:self._loading_draft=False
                    self.draft_note.setText('Posted successfully. New unsent text will be saved locally.')
                self.failed_request=None;self.show_pending()
            self.loaded_version=client.info.get('review_version')
            self.call(lambda:callback(result))
        try:client.transport.post(client.server,client.path+'/review',client.token,data,finished)
        except Exception:self.busy=False;self.update_permissions();self.show_pending();raise

    def load(self):
        def loaded(data):
            self.loaded_version=data.get('review_version',self.loaded_version)
            selected=self.checkpoints.currentData();self.data=data;self.checkpoints.blockSignals(True);self.checkpoints.clear();self.other.clear();self.other.addItem('Compare with current design',None)
            for c in data['checkpoints']:
                label=c['name']+' · r'+str(c['revision']);self.checkpoints.addItem(label,c['id']);self.other.addItem(label,c['id'])
            self.checkpoints.setCurrentIndex(max(0,self.checkpoints.findData(selected)));self.checkpoints.blockSignals(False);self.fill()
            self.note.setText('Reviews belong to immutable checkpoints. New design edits do not inherit an earlier approval.')
        self.request({'action':'list'},loaded)

    def selected(self):
        key=self.checkpoints.currentData()
        if not key:raise ValueError('Save or select a checkpoint first.')
        return key

    def fill(self):
        if self._loading_draft:return
        key=self.checkpoints.currentData();current=self.comments.currentItem()
        selected=current.data(0,Qt.UserRole)['id'] if current else None
        if self.filled_checkpoint!=key:
            if self.filled_checkpoint and not self.flush_draft():
                self.checkpoints.blockSignals(True);self.checkpoints.setCurrentIndex(self.checkpoints.findData(self.filled_checkpoint));self.checkpoints.blockSignals(False);return
            self.filled_checkpoint=key;self.restore_draft()
        self.comments.clear();self.reports.clear()
        rows=[r for r in self.data.get('comments',[]) if r['checkpoint']==key];items={}
        for row in rows:
            item=QTreeWidgetItem([row['author']+(' · attached object' if row['object'] else ''),row['text'],row['status'] if not row.get('parent') else 'Reply'])
            item.setData(0,Qt.UserRole,row);item.setToolTip(0,row['object']);item.setToolTip(1,row['text']);items[row['id']]=item
        for row in rows:
            item=items[row['id']];parent=items.get(row.get('parent'))
            if parent:parent.addChild(item);parent.setExpanded(True)
            else:self.comments.addTopLevelItem(item)
            if row['id']==selected:self.comments.setCurrentItem(item)
        if self.reply_to and not any(r['id']==self.reply_to and r['status']=='open' for r in rows):
            self.reply_note.setText('This discussion is resolved or unavailable. Your reply draft is retained; reopen the discussion or cancel reply.')
        decisions=[r['author']+': '+r['status'].replace('_',' ')+((' · '+r['message']) if r['message'] else '') for r in self.data.get('decisions',[]) if r['checkpoint']==key]
        self.decisions.setText('\n'.join(decisions) or 'No review decision for this checkpoint yet.')
        for row in self.data.get('reports',[]):
            if row['checkpoint']==key:self.reports.addItem(row['name']+' · '+row['author'],row['id'])

    def create(self):
        client=self.studio.live_client
        if client is None:raise ValueError('Join a workspace first.')
        if client.pending or client.conflict or client.busy:raise ValueError('Wait for edits to synchronize before saving a checkpoint.')
        name,ok=QInputDialog.getText(self,'Save checkpoint','Checkpoint name',text='Design r'+str(client.revision))
        if ok:self.request(dict(action='create_checkpoint',revision=client.revision,name=name),lambda _:self.load(),True)

    def post_comment(self):
        if not self.flush_draft():raise ValueError('Save the draft locally before posting. '+(self.draft_error or 'Select a checkpoint first.'))
        data=dict(action='comment',checkpoint=self.selected(),text=self.comment.toPlainText(),cell='',object='')
        if self.reply_to:
            data=dict(action='reply',checkpoint=self.selected(),parent=self.reply_to,text=self.comment.toPlainText())
        elif self.anchor.isChecked():
            studio=self.studio;kind=self.anchor_kind.currentText()
            from .review_anchors import targets
            available=targets(studio.project,studio.cid,findings=kind=='Electrical finding')
            if kind=='Highlighted net':
                key='net:'+studio.net
                if key not in available:raise ValueError('Highlight a schematic net before attaching this comment.')
            elif kind in ('Terminal','Electrical finding'):
                prefix='terminal:' if kind=='Terminal' else 'finding:'
                choices={key:row for key,row in available.items() if key.startswith(prefix) and (kind!='Terminal' or any(i in studio.selection for i in row['objects']))}
                if not choices:raise ValueError('Select a component first.' if kind=='Terminal' else 'There are no electrical findings for this cell.')
                keys=list(choices);labels=[str(i+1)+' · '+choices[key]['label'] for i,key in enumerate(keys)]
                label,ok=QInputDialog.getItem(self,'Attach comment',kind,labels,0,False)
                if not ok:return
                key=keys[labels.index(label)]
            else:
                if len(studio.selection)!=1:raise ValueError('Select one object to attach the comment to.')
                key=studio.selection[0].removeprefix('pin:')
            data.update(cell=studio.cid,object=key)
        def posted(_):
            if (self.filled_checkpoint==data['checkpoint'] and self.comment.toPlainText()==data['text']
                    and (self.reply_to or '')==data.get('parent','')):
                self.comment.clear();self.cancel_reply();self.flush_draft()
            self.load()
        self.request(data,posted,True)

    def selected_comment(self):
        item=self.comments.currentItem()
        if item is None:raise ValueError('Select a comment first.')
        return item.data(0,Qt.UserRole)

    def resolve(self):
        row=self.discussion();status='open' if row['status']=='resolved' else 'resolved'
        self.request(dict(action='resolve_comment',comment=row['id'],version=row['version'],status=status),lambda _:self.load(),True)

    def discussion(self):
        row=self.selected_comment()
        return next((r for r in self.data.get('comments',[]) if r['id']==row.get('parent')),row)

    def start_reply(self):
        row=self.discussion()
        if row['status']!='open':raise ValueError('Reopen this discussion before replying.')
        self.reply_to=row['id'];self.reply_note.setText('Replying to '+row['author']+': '+row['text'][:160])
        self.comment_button.setText('Post reply');self.cancel_reply_button.show();self.anchor.setEnabled(False);self.anchor_kind.setEnabled(False);self.comment.setFocus()
        self.draft_changed()

    def cancel_reply(self):
        self.reply_to=None;self.reply_note.clear();self.comment_button.setText('Post comment');self.cancel_reply_button.hide();self.anchor.setEnabled(True);self.anchor_kind.setEnabled(True)
        self.draft_changed()

    def read_comment(self):
        row=self.selected_comment();self.studio.text_dialog('Comment by '+row['author'],row['text'])

    def navigate(self):
        row=self.selected_comment();studio=self.studio;cell=next((c for c in studio.project['cells'] if c['id']==row['cell']),None)
        if not studio.flush_inspector():return
        if cell is None or not row['object']:raise ValueError('This comment has no object available in the current design. Compare its checkpoint instead.')
        from .review_anchors import targets
        target=targets(studio.project,cell['id'],findings=row['object'].startswith('finding:')).get(row['object'])
        if target is None:raise ValueError('This object or finding changed after the checkpoint. Compare revisions to inspect it.')
        studio.cid=target.get('cell',cell['id']);studio.mode_combo.setCurrentIndex(0 if target['view']=='schematic' else 1);studio.net=target['net'];studio.refresh(True);studio.select(target['objects'],target['view'])

    def decide(self):
        if not self.flush_draft():raise ValueError('Save the draft locally before recording a decision.')
        self.request(dict(action='decide',checkpoint=self.selected(),status=self.decision.currentData(),text=self.comment.toPlainText()),lambda _:self.load(),True)

    def export_checkpoint(self):
        def received(data):
            path,_=QFileDialog.getSaveFileName(self,'Save checkpoint copy',data['name']+'.icproj','IC Studio project (*.icproj)')
            if path:save_project(data['project'],path)
        self.request(dict(action='checkpoint',checkpoint=self.selected()),received)

    def compare(self):
        other=self.other.currentData();current=clone(self.studio.project)
        def first(data):
            def show(after):self.comparison=RevisionComparison(self,data['project'],after);self.comparison.show()
            if other:self.request(dict(action='checkpoint',checkpoint=other),lambda second:show(second['project']))
            else:show(current)
        self.request(dict(action='checkpoint',checkpoint=self.selected()),first)

    def share_report(self):
        key=self.selected();rows=[r for r in self.studio.run_manager.rows if r['state']=='Complete' and r.get('result')]
        if not rows:raise ValueError('Complete a simulation before sharing its saved input and result.')
        choices=[str(i+1)+' · '+r['name'] for i,r in enumerate(rows)]
        name,ok=QInputDialog.getItem(self,'Share completed run','Run to share with this checkpoint',choices,0,False)
        if ok:
            row=rows[choices.index(name)];self.request(dict(action='share_report',checkpoint=key,name=row['name'][:100],job=row['job'],result=row['result']),lambda _:self.load(),True)

    def get_report(self,callback):
        key=self.reports.currentData()
        if not key:raise ValueError('Select a shared result first.')
        self.request(dict(action='report',report=key),callback)

    def inspect_report(self):
        def show(data):
            result=data['result'];specs=result.get('specifications',[]) or result.get('measurements',{}).get('measurements',[])
            text=data['name']+'\nSaved input: '+result.get('design_hash','')+'\nEngine: '+result.get('engine','')+'\n\n'
            text+='\n'.join(s['name']+': '+str(s.get('value',''))+' '+s.get('unit','')+' · '+s['status'] for s in specs)
            physical=result.get('silicon_report',{})
            text+='\n'+'\n'.join(s['name'].replace('_',' ')+': '+s['status']+(' · '+s['error'] if s.get('error') else '') for s in physical.get('stages',[]))
            text+='\n'+'\n'.join(m['name']+f": {m['before']:.6g} → {m['after']:.6g} {m['unit']}" for m in physical.get('comparison',[]))
            text+='\n\nShared by a teammate; the server stores provenance and does not independently run the verification.'
            self.studio.text_dialog('Shared verification result',text)
        self.get_report(show)

    def rerun_report(self):
        def run(data):
            original=data['job'];p=clone(original['project']);local=self.studio.project['pdk']
            if p['pdk'].get('package_lock')!=local.get('package_lock'):raise ValueError('Select the matching locked PDK revision before reproducing this run.')
            if local.get('package_root'):p['pdk']['package_root']=local['package_root']
            job=self.studio.prepare_simulation(original['settings'],original['engine'],p,original['cell'])
            if job['settings']['type']=='testbench':job['settings']['executable']=job['executable']
            job['shared_origin']={'input_hash':data['result']['design_hash'],'checkpoint':data['checkpoint']}
            self.studio.run_manager.enqueue(job,self.studio.jobs_dir,'Reproduce · '+data['name']);self.note.setText('Reproduction queued with the saved input and your local simulator.')
        self.get_report(run)

    def retry(self):
        if not self.failed_request:return
        data,callback=self.failed_request;self.request(data,callback,True)

    def show_pending(self):
        pending=self.outbox.pending if self.outbox else None
        self.retry_button.setVisible(bool(pending));self.discard_button.setVisible(bool(pending))
        self.retry_button.setEnabled(not self.busy);self.discard_button.setEnabled(not self.busy)
        self.pending_note.setText(('Saved '+pending['action'].replace('_',' ')+' · retained across restart. '+self.outbox.error) if pending else '')

    def discard_pending(self):
        if self.busy or not self.outbox or not self.outbox.pending:return
        if QMessageBox.question(self,'Discard saved review action','Discard the local retry? An action already accepted by the server remains in the discussion.',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        self.outbox.discard();self.failed_request=None;self.show_pending()
