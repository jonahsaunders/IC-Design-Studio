#!/bin/bash
set -euo pipefail
base=/workspace/shared/physical-native-local-v1
src=/workspace/shared/physical-tool-inspect/sources
sys=/workspace/shared/physical-tool-inspect/debian/sysroot
export PATH="$sys/usr/bin:$PATH"
export CPATH="$sys/usr/include:$sys/usr/include/tcl8.6:$sys/usr/include/freetype2:$sys/usr/include/libpng16:$sys/usr/include/pixman-1:$sys/usr/include/x86_64-linux-gnu"
export LIBRARY_PATH="$sys/usr/lib/x86_64-linux-gnu"
export PKG_CONFIG_PATH="$sys/usr/lib/x86_64-linux-gnu/pkgconfig:$sys/usr/share/pkgconfig"
export CFLAGS="-g -I$sys/usr/include -I$sys/usr/include/tcl8.6"
export LDFLAGS="-L$sys/usr/lib/x86_64-linux-gnu"
printf '%s\n' "$PATH" "$CPATH" "$LIBRARY_PATH" "$PKG_CONFIG_PATH" "$CFLAGS" "$LDFLAGS" > "$base/logs/build-environment.txt"
gcc --version > "$base/logs/compiler-version.txt"
sha256sum /usr/bin/x86_64-linux-gnu-gcc-14 /usr/bin/make /usr/bin/ld > "$base/logs/build-tools.sha256"
for name in magic netgen; do
 cd "$src/$name"
 git rev-parse HEAD > "$base/logs/$name-source.txt"
 timeout 180 ./configure --prefix="$base/installed" --with-tcl="$sys/usr/lib/x86_64-linux-gnu/tcl8.6" --with-tk="$sys/usr/lib/x86_64-linux-gnu/tk8.6" --with-tclincls="$sys/usr/include/tcl8.6" --with-tkincls="$sys/usr/include/tcl8.6" --with-tcllibs="$sys/usr/lib/x86_64-linux-gnu" --with-tklibs="$sys/usr/lib/x86_64-linux-gnu" > "$base/logs/$name-configure.log" 2>&1
 timeout 600 make -j2 > "$base/logs/$name-make.log" 2>&1
 timeout 120 make install > "$base/logs/$name-install.log" 2>&1
 mkdir -p "$base/licenses/$name"
 for f in COPYING Copying COPYRIGHT LICENSE LICENSE.txt; do [ ! -f "$f" ] || cp "$f" "$base/licenses/$name/"; done
done
