if {[catch {
gds read "/workspace/shared/physical-native-local-v1/guard-corner-safe-attempt-2/rhigh-bottom_minus50/reference-width/layout.gds"
load "coupon"
select top cell
box values 0 0 0 0
if {![port "R1" exists]} {error "Missing layout port R1"}
port "R1" index 1
if {![port "R2" exists]} {error "Missing layout port R2"}
port "R2" index 2
if {![port "B" exists]} {error "Missing layout port B"}
port "B" index 3
extract all
ext2spice lvs
ext2spice subcircuit top on
ext2spice renumber off
ext2spice global off
ext2spice hierarchy on
ext2spice blackbox off
ext2spice scale off
ext2spice merge none
ext2spice cthresh infinite
ext2spice rthresh infinite
ext2spice extresist off
ext2spice -o extracted.spice
puts STUDIO_MAGIC_COMPLETE
} err]} {puts stderr "STUDIO_MAGIC_ERROR $err"}
quit -noprompt
