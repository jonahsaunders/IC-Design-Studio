tech load "/workspace/shared/ic-design-studio-next/icstudio/assets/pdks/ihp-sg13g2/libs.tech/magic/icstudio-ihp-sg13g2.tech"
drc euclidean on
