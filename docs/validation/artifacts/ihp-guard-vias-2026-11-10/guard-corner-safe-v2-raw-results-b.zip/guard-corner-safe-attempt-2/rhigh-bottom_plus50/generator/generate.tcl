tech load {/workspace/shared/ic-design-studio-next/icstudio/assets/pdks/ihp-sg13g2/libs.tech/magic/ihp-sg13g2.tech}
source {/workspace/shared/ic-design-studio-next/icstudio/assets/pdks/ihp-sg13g2/libs.tech/magic/ihp-sg13g2.tcl}
load coupon -silent
box values 0 0 0 0
set parameters [dict merge [sg13g2::rhigh_defaults] [dict create w 2 l 7 doports 1 vias 0 viagb +50 viagt 0 viagl 0 viagr 0]]
if {[catch {sg13g2::rhigh_draw $parameters} err]} {puts stderr "GENERATOR_FAILED $err"; quit -noprompt}
select top cell
box select
save coupon
gds write coupon.gds
puts GENERATOR_COMPLETE
quit -noprompt
