if {[catch {
gds read "/workspace/shared/physical-native-local-v1/guard-corner-safe-attempt-2/rsil-top50/physical-90/layout.gds"
load "coupon"
select top cell
box values 0 0 0 0
if {![port "R1" exists]} {error "Missing layout port R1"}
port "R1" index 1
if {![port "R2" exists]} {error "Missing layout port R2"}
port "R2" index 2
if {![port "B" exists]} {error "Missing layout port B"}
port "B" index 3
snap internal
select top cell
box values {*}[select bbox]
box grow c 10um
drc style "drc(full)"
drc ignore none
drc check
drc catchup
puts "STUDIO_DRC_COUNT [drc list count total]"
puts "STUDIO_DRC_STYLE [drc list style]"
puts "STUDIO_MAGIC_SCALE [cif scale out]"
set f [open findings.tsv w]
foreach {reason boxes} [drc listall why] {foreach coords $boxes {puts $f "[string map {\t { } \n { }} $reason]\t[join $coords {,}]"}}
close $f

puts STUDIO_MAGIC_COMPLETE
} err]} {puts stderr "STUDIO_MAGIC_ERROR $err"}
quit -noprompt
