from pathlib import Path
import shutil,subprocess,json,hashlib,difflib
r=Path(__file__).parent;old=Path('/workspace/shared/ihp-psp-engine-investigation');src=r/'source';shutil.copytree(old/'pristine47/ngspice-47',src)
subprocess.run(['git','apply',str(old/'../ihp-pmos-measured-attempt-3/engine/sources/capacitor-multiplier.patch')],cwd=src,check=True)
base={p.relative_to(src).as_posix():p.read_bytes() for p in src.rglob('*') if p.is_file()}
p=src/'src/maths/ni/niiter.c';s=p.read_text();helper=r'''
/* Isolated diagnostic counters only; never write solver/model state. */
#include <stdarg.h>
static unsigned long icdiag_call, icdiag_iter, icdiag_events;
static size_t icdiag_bytes;
static unsigned long icdiag_failed_call;
static int icdiag_active;
static int icdiag_done(int result) { icdiag_active=0; return result; }
int icdiag_selected(void) {
    return icdiag_active && icdiag_call >= 1 && icdiag_call <= 5 && icdiag_iter >= 1 && (icdiag_iter <= 2 || icdiag_iter >= 99);
}
void icdiag_emit(const char *format, ...) {
    char line[768]; int n; va_list args;
    if (icdiag_events >= 1024 || icdiag_bytes >= 524288) return;
    va_start(args, format); n=vsnprintf(line,sizeof(line),format,args); va_end(args);
    if(n<=0 || (size_t)n>=sizeof(line) || icdiag_bytes+(size_t)n>524288) return;
    fwrite(line,1,(size_t)n,stderr); fflush(stderr);
    ++icdiag_events; icdiag_bytes+=(size_t)n;
}
void icdiag_osdi(const char *instance, const char *model, unsigned int flags, long mode) {
    if(icdiag_selected()) icdiag_emit("ICEQ osdi call=%lu iter=%lu instance=%s model=%s flags=%u mode=%ld\n",icdiag_call,icdiag_iter,instance,model,flags,mode);
}
void icdiag_failure(CKTcircuit *ckt, int index, int type, double old, double new, double tol) {
    if(!icdiag_active || icdiag_call<1 || icdiag_call>5 || icdiag_failed_call==icdiag_call) return;
    icdiag_failed_call=icdiag_call;
    icdiag_emit("ICEQ first-node-failure call=%lu iter=%lu mode=%ld node=%d name=%s type=%d old=%.17g new=%.17g tol=%.17g diff=%.17g\n",icdiag_call,icdiag_iter,(long)ckt->CKTmode,index,CKTnodName(ckt,index),type,old,new,tol,fabs(new-old));
}
static void icdiag_snapshot(CKTcircuit *ckt) {
    CKTnode *node; unsigned int count=0;
    if(!icdiag_selected()) return;
    for(node=ckt->CKTnodes;node && count<64;node=node->next,++count)
        icdiag_emit("ICEQ unknown call=%lu iter=%lu mode=%ld node=%d name=%s type=%d old=%.17g new=%.17g\n",icdiag_call,icdiag_iter,(long)ckt->CKTmode,node->number,CKTnodName(ckt,node->number),node->type,ckt->CKTrhsOld[node->number],ckt->CKTrhs[node->number]);
    if(node) icdiag_emit("ICEQ unknown-truncated call=%lu iter=%lu maximum=64\n",icdiag_call,icdiag_iter);
}
'''
s=s.replace('/* Limit the number',helper+'\n/* Limit the number',1)
s=s.replace('    int ipass = 0;','    int ipass = 0;\n    ++icdiag_call; icdiag_iter=0; icdiag_active=1;\n    if(icdiag_call<=5) icdiag_emit("ICEQ call=%lu mode=%ld maxIterRequested=%d\\n",icdiag_call,(long)ckt->CKTmode,maxIter);',1)
s=s.replace('        ckt->CKTnoncon = 0;','        icdiag_iter=(unsigned long)iterno+1;\n        ckt->CKTnoncon = 0;',1)
s=s.replace('            error = CKTload(ckt);','            error = CKTload(ckt);\n            if(icdiag_selected()) icdiag_emit("ICEQ post-load call=%lu iter=%lu mode=%ld noncon=%d error=%d\\n",icdiag_call,icdiag_iter,(long)ckt->CKTmode,ckt->CKTnoncon,error);',1)
s=s.replace('            if (iterno > maxIter) {','            icdiag_snapshot(ckt);\n            if (iterno > maxIter) {\n                if(icdiag_call<=5) icdiag_emit("ICEQ iteration-limit call=%lu iter=%lu noncon=%d\\n",icdiag_call,icdiag_iter,ckt->CKTnoncon);',1);
import re
head,body=s.split('int\nNIiter(',1);body=re.sub(r'return\s*\((error|OK|E_ITERLIM|E_INTERN)\);',r'return icdiag_done(\1);',body);s=head+'int\nNIiter('+body;p.write_text(s)
p=src/'src/maths/ni/niconv.c';s=p.read_text();s=s.replace('extern bool ft_ngdebug;','extern bool ft_ngdebug;\nextern void icdiag_failure(CKTcircuit *, int, int, double, double, double);',1)
s=s.replace('        if (isnan(new)) {','        if (isnan(new)) {\n            icdiag_failure(ckt,i,node->type,old,new,0.0);',1)
s=s.replace('            if (fabs(new-old) >tol ) {','            if (fabs(new-old) >tol ) {\n                icdiag_failure(ckt,i,node->type,old,new,tol);');p.write_text(s)
p=src/'src/osdi/osdiload.c';s=p.read_text();s=s.replace('#define NUM_SIM_PARAMS 10','extern void icdiag_osdi(const char *, const char *, unsigned int, long);\n\n#define NUM_SIM_PARAMS 10',1)
s=s.replace('eval_flags |= extra_inst_data->eval_flags;','icdiag_osdi(gen_inst->GENname,gen_model->GENmodName,extra_inst_data->eval_flags,(long)ckt->CKTmode);\n      eval_flags |= extra_inst_data->eval_flags;');p.write_text(s)
diff=[]
for name,a in base.items():
 b=(src/name).read_bytes()
 if a!=b:diff.extend(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(r/'instrumentation.patch').write_text(''.join(diff));manifest={p.relative_to(src).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*') if p.is_file()};(r/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(hashlib.sha256((r/'instrumentation.patch').read_bytes()).hexdigest())
