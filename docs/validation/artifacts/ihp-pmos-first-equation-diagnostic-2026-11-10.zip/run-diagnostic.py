from pathlib import Path
import hashlib,json,subprocess,shutil,time,uuid
r=Path(__file__).parent;old=Path('/workspace/shared/ihp-pmos-measured-attempt-3');previous=Path('/workspace/shared/ihp-psp-engine-investigation');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def files(p):return {x.relative_to(p).as_posix():sha(x) for x in p.rglob('*') if x.is_file()}
profile=json.loads((r/'build/receipt.json').read_text());assert profile['status']=='built-not-executed';assert profile['instrumentation_sha256']=='46c4e4af782f540ab0b0e473849114ed42411805b9814e654bc044ccf3711fbd'==sha(r/'instrumentation.patch');assert all(profile['features'].values());assert files(r/'source')==json.loads((r/'source-manifest.json').read_text());assert sha(r/'source-manifest.json')==profile['source_manifest_sha256']
exe=r/'build/src/ngspice';assert sha(exe)==profile['executable_sha256'];out=r/'one-gate';out.mkdir();historic=json.loads((old/'run.json').read_text())['files']
for prefix in ['pdk','runtime']:
 shutil.copytree(old/prefix,out/prefix);assert files(out/prefix)=={p[len(prefix)+1:]:h for p,h in historic.items() if p.startswith(prefix+'/')}
for src,name in [('engine/runtime/spinit','spinit'),('runs/nominal-3/input.cir','input.cir')]:shutil.copyfile(old/src,out/name);assert sha(out/name)==historic[src]
env={'PATH':'/usr/bin:/bin','HOME':str(out),'LANG':'C','LC_ALL':'C','TZ':'UTC','SPICE_SCRIPTS':str(out),'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':profile['environment']['LD_LIBRARY_PATH']}
def deps(exe):
 p=subprocess.run(['ldd',str(exe)],env=env,capture_output=True,text=True,timeout=10);assert p.returncode==0 and 'not found' not in p.stdout+p.stderr
 return {s:sha(s) for line in p.stdout.splitlines() for s in line.split() if s.startswith('/') and Path(s).is_file()}
before=deps(exe);assert before==profile['dependencies']==json.loads((previous/'build-baseline/receipt.json').read_text())['dependencies'];modules={p.name:deps(p) for p in (out/'runtime').iterdir()}
cmd=[str(exe),'-n','-D','filetype=ascii','-D','ngbehavior=hsa','-b','-r',str(out/'result.raw'),str(out/'input.cir')]
rec={'status':'RUNNING','qualified':False,'execution_id':uuid.uuid4().hex,'helper_sha256':sha(__file__),'build_receipt_sha256':sha(r/'build/receipt.json'),'engine_sha256':sha(exe),'input_files':files(out),'command':cmd,'cwd':str(out),'environment':env,'deadline_seconds':90,'returncode':None,'timed_out':False,'dependencies_before':before,'module_dependencies':modules}
def save():(out/'run.json').write_text(json.dumps(rec,indent=2)+'\n')
save();start=time.monotonic()
try:
 with (out/'console.log').open('wb') as f:p=subprocess.run(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
 rec['returncode']=p.returncode;rec['status']='DIAGNOSTIC_PROCESS_COMPLETE'
except subprocess.TimeoutExpired:rec['timed_out']=True;rec['status']='DIAGNOSTIC_TIMEOUT'
finally:
 rec['seconds']=time.monotonic()-start;rec['dependencies_after']=deps(exe);assert rec['dependencies_after']==before;assert sha(exe)==rec['engine_sha256'];assert all(sha(out/p)==h for p,h in rec['input_files'].items())
 events=[s for s in (out/'console.log').read_text().splitlines() if s.startswith('ICEQ ')];rec['trace_events']=len(events);rec['trace_bytes']=sum(len((s+'\n').encode()) for s in events);assert rec['trace_events']<=1024 and rec['trace_bytes']<=524288
 rec['outputs']={p:sha(out/p) for p in ['console.log','result.raw'] if (out/p).exists()};save()
print(rec['status'],rec['seconds'],rec['trace_events'])
