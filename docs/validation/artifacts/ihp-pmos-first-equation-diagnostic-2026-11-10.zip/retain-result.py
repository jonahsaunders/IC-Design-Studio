from pathlib import Path
from decimal import Decimal,localcontext
import json,hashlib,re,math,zipfile
r=Path(__file__).parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();run=json.loads((r/'one-gate/run.json').read_text());lines=(r/'one-gate/console.log').read_text().splitlines();events=[x for x in lines if x.startswith('ICEQ ')];failed=[x for x in events if 'first-node-failure' in x];osdi=[x for x in events if 'ICEQ osdi ' in x];post=[x for x in events if 'post-load' in x]
with localcontext() as c:
 c.prec=50;D=Decimal;delta=D('9.695e-8')*(1+D('-.03438')*D('.1'));L=D('1e-5')+delta;G=D('1e-5')*L/D('1e-12');R=1/G
 ratio=D('1.4210854715202004e-14')/D('1.5929351232225599e-16')
value={'schema':1,'status':'BOUNDED_DIAGNOSTIC_TIMEOUT_WITH_SELECTED_CONVERGENCE_CAUSE','qualified':False,'runtime_replaced':False,'native_runs':1,'deadline_seconds':90,'actual_seconds':run['seconds'],'engine_sha256':run['engine_sha256'],'instrumentation_sha256':sha(r/'instrumentation.patch'),'run_sha256':sha(r/'one-gate/run.json'),'trace_events':run['trace_events'],'trace_bytes':run['trace_bytes'],'raw_complete':False,
'first_rejected_unknowns':failed,'sampled_osdi_flags_all_zero':all('flags=0 ' in x for x in osdi),'sampled_postload_noncon_all_zero':all('noncon=0 ' in x for x in post),
'observations':[
'Call1 is direct DC-curve initialization (MODEDCTRANCURVE with INITJCT then INITFIX), not a completed measurement point. Its first rejected node vs#branch at iteration2 is a large ordinary initial update and is not identified as root cause.',
'At direct-initialization iterations99,100,101, gate-source branch current vg#branch alternates between5.929337021370884e-9 and5.9293512322255992e-9A; GP alternates between adjacent binary64 voltages−1.1239999999412742 and−1.123999999941274V.',
'OPtran calls2,3,4 (MODETRAN|MODEINITTRAN then MODETRAN|MODEINITFLOAT) first reject vg#branch at iteration2 and retain that same late-iteration two-cycle before E_ITERLIM. Those selected repeated failures are NIconvTest current-unknown convergence rejection, not sampled OSDI limiter rejection.',
'The gate-current difference is1.4210854715202004e-14A versus tolerance1.5929351232225599e-16A, about89.21times tolerance. Internal GP voltage difference is one binary64 ULP at this magnitude.',
'All sampled OSDI flags and postload noncon values are0. This excludes a limiter flag as explanation for these logged iterations, not every unlogged iteration or future call.',
'Trace is limited to first5NIiter calls. The earlier experiment observed later tiny-step progress, but this instrumentation does not establish its first-failure equation throughout that later phase.'],
'source_backed_conditioning_lead':{
'parameters':'Pinned sg13g2_lv_pmos_psp model: RINT1e-12 Ohm m²,RVPOLY0,LVARO9.695e-8m,LVARL−.03438,LVARW0,WVARO0; omitted RSHG/RGO use PSP0defaults. W=L10um,NF=M1.',
'equations':'PSP scaling uses iL=1um/L,delLPS=LVARO*(1+LVARL*iL);L_f=L+delLPS,W_f=W;RG=(RINT+RVPOLY)/(W_f*L_f) with zero other terms. Module ggate=1/RG and CollapsableR contributes MULT*ggate*V(G,GP).',
'calculated_Rg_ohm':str(R),'calculated_Gg_siemens':str(G),'gate_iteration_diff_over_tolerance':str(ratio),
'interpretation':'Approximately9.904mOhm series gate branch connects voltages near−1.124V while current is about5.93nA. Per-node observed one-ULP voltage cycling and current-unknown two-cycle support a finite-precision/conditioning lead. Actual matrix/residual assembly and factorization have not been traced; this is not proof of a specific compiler or solver bug.',
'no_unauthorized_remedy':'No gate short, RINT/model edit, tolerance loosening, offset voltage, initial-state change or longer deadline is justified or applied.'},
'next_proposal':'Before another native run, inspect the exact compiled OSDI gate-resistor residual/Jacobian and ngspice/KLU branch-current reconstruction for cancellation. A faithful numerical remedy would need equation-preserving assembly/scaling or higher-precision solve evidence, not changed device coefficients or relaxed convergence. Any new implementation/run requires separate review and authorization.',
'scope':'One Linux local diagnostic, not a140point measured comparison,20job interface acceptance,independent calibration,fullfamily or installed application qualification. Missing measured-data uncertainty and holdout provenance remain independent blockers.'}
# Retain source paths/hashes supporting the new physical-conditioning lead.
model=Path('/workspace/shared/ihp-measured-runtime-v1/model-sources/psp103');pdk=Path('/workspace/shared/ihp-pmos-measured-attempt-3/pdk/libs.tech/ngspice/models');value['conditioning_sources']={str(p):sha(p) for p in [model/'PSP103_scaling.include',model/'PSP103_macrodefs.include',model/'PSP103_module.include',model/'PSP103_parlist.include',pdk/'sg13g2_moslv_parm.lib',pdk/'sg13g2_moslv_mod.lib']}
(r/'result.json').write_text(json.dumps(value,indent=2)+'\n')
paths=[p for p in r.iterdir() if p.is_file() and p.suffix in ('.json','.py','.patch') and p.name!='bundle-manifest.json']
paths += [p for p in (r/'source-excerpts').rglob('*') if p.is_file()]
paths += [r/'build'/p for p in ['receipt.json','config.log','stage-0.log','stage-1.log','ldd.log']]
paths += [p for p in (r/'one-gate').rglob('*') if p.is_file()]
paths += [r/'source/COPYING']
paths += [p for prefix in ['runtime-provenance','retained-model-source'] for p in (r/prefix).rglob('*') if p.is_file()]
manifest={'files':{str(p.relative_to(r)):sha(p) for p in paths},'scope':'Partial diagnostic evidence bundle,not standalone or relocation-independent replay.','omitted':{'engine_sha256':run['engine_sha256'],'source':'Pinned archive and exact instrumentation/capacitor patch identities/manifests retained; complete source trees local.','toolchain':'Prior signed Debian package and compiler/dependency profile retained in ihp-psp-engine-investigation; current build receipt names exact prior contract.','source_provenance':'Model/module sources and licenses remain in the prior authenticated PMOS evidence; this bundle retains model package and module bytes copied for this run.'}}
(r/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(r/'first-equation-diagnostic-report.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths:z.write(p,str(p.relative_to(r)))
 z.write(r/'bundle-manifest.json','bundle-manifest.json')
print(json.dumps({'result_sha256':sha(r/'result.json'),'bundle_sha256':sha(r/'first-equation-diagnostic-report.zip'),'bundle_bytes':(r/'first-equation-diagnostic-report.zip').stat().st_size,'ratio':str(ratio),'Rg':str(R)},indent=2))
