from pathlib import Path
import importlib.util,json,hashlib,re,math
r=Path(__file__).parent;old=Path('/workspace/shared/ihp-pmos-measured-attempt-3');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
raw=module('raw_auditor',old/'sources/scripts/audit_sky130_li_linked.py');m=module('measured',old/'sources/scripts/ihp_pmos_measured_reference.py')
run=json.loads((r/'one-gate/run.json').read_text());assert run['returncode']==0 and not run['timed_out'] and run['klu_backend_observed'];log=(r/'one-gate/console.log').read_text();assert not re.search(r'(?im)^\s*(?:error|fatal|fatal error)\b|unknown (?:parameter|model)|simulation (?:aborted|failed)|no such file|could not load|failed to load',log)
values,axis=raw.raw(r/'one-gate/result.raw');assert len(axis)==28 and all(abs(v+i/20)<1e-12 for i,v in enumerate(axis));assert set(values)=={'v(v-sweep)','i(vd)','i(vg)','i(vs)','i(vb)'}
rows=[{t:-values['i(v'+t+')'][i] for t in ('d','g','s','b')} for i in range(28)];kcl=max(abs(sum(v.values()))/(1e-13+1e-6*sum(abs(i) for i in v.values())) for v in rows);assert kcl<=1
measured=m.parse((old/'measurement.mdm').read_bytes())[84:112];res=[]
for measure,actual in zip(measured,rows):
 result={}
 for terminal in ('d','g','s','b'):
  ref=float(measure['currents'][terminal]);delta=actual[terminal]-ref;result[terminal]=dict(measured_a=ref,simulated_a=actual[terminal],signed_residual_a=delta,absolute_residual_a=abs(delta),signed_relative_residual=delta/abs(ref) if ref else None)
 res.append(dict(vg=measure['vg'],vd=measure['vd'],terminals=result))
result={'status':'ONE_GATE_KLU_DIAGNOSTIC_COMPLETE','qualified':False,'independent_calibration':False,'installed_acceptance':False,'full_140_point_batch_complete':False,'full_20_job_interface_controls_complete':False,'points':28,'terminal_values':112,'returncode':run['returncode'],'seconds':run['seconds'],'positive_backend_readback':run['klu_backend_observed'],'numerical_consistency':{'kcl_max_normalized_error':kcl,'absolute_current_tolerance_a':1e-13,'relative_tolerance':1e-6},'measurement_residual_acceptance':None,'residuals':res,'maximum_absolute_residual_a':{t:max(p['terminals'][t]['absolute_residual_a'] for p in res) for t in ('d','g','s','b')},'identity':{'engine_sha256':run['engine_sha256'],'run_sha256':sha(r/'one-gate/run.json'),'raw_sha256':sha(r/'one-gate/result.raw'),'log_sha256':sha(r/'one-gate/console.log'),'raw_parser_sha256':sha(old/'sources/scripts/audit_sky130_li_linked.py'),'measurement_parser_sha256':sha(old/'sources/scripts/ihp_pmos_measured_reference.py')},'interpretation':'The same diagnostic executable that timed out on Sparse completed this one gate with only .option klu added. This demonstrates finite-case linear-solver-path sensitivity, not a general cure or compiler defect. It does not fill missing fifth gate,other routes,measurement uncertainty/holdout provenance or installed acceptance.'}
(r/'readback.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','seconds','points','numerical_consistency','maximum_absolute_residual_a']},indent=2))
