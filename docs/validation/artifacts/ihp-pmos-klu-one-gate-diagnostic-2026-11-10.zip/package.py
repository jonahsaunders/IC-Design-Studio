from pathlib import Path
import hashlib,json,zipfile,shutil
r=Path(__file__).parent;prior=Path('/workspace/shared/ihp-psp-first-equation-investigation');old=Path('/workspace/shared/ihp-pmos-measured-attempt-3');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ['runtime-provenance','retained-model-source']:shutil.copytree(prior/name,r/name)
ret=r/'frozen-provenance';ret.mkdir()
for src,name in [(prior/'build/receipt.json','build-receipt.json'),(prior/'instrumentation.patch','instrumentation.patch'),(prior/'source-manifest.json','source-manifest.json'),(prior/'source/COPYING','ngspice-COPYING'),(old/'measurement.mdm','measurement.mdm'),(old/'sources/scripts/ihp_pmos_measured_reference.py','measurement-parser.py'),(old/'sources/scripts/audit_sky130_li_linked.py','raw-parser.py'),(old/'sources/docs/qualification/ihp-pmos-measured-reference-v1/LICENSE','measurement-LICENSE'),(old/'sources/docs/qualification/ihp-pmos-measured-reference-v1/UPSTREAM-README.md','measurement-README.md'),(prior/'one-gate/run.json','baseline-run.json'),(prior/'one-gate/console.log','baseline-console.log')]:shutil.copyfile(src,ret/name)
paths=[p for p in sorted(r.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name!='bundle-manifest.json']
manifest={'scope':'One-gate alternative-solver diagnostic raw evidence,not standalone/relocation-independent replay or qualification.','files':{p.relative_to(r).as_posix():sha(p) for p in paths},'omitted':{'engine':{'path':str(prior/'build/src/ngspice'),'sha256':sha(prior/'build/src/ngspice')},'compiler_and_host_libraries':'Previously authenticated build-contract and exact runtime dependency identities are retained; binary bytes external.','full_ngspice_source':'Pinned47source archive and corrected capacitor source patch remain in earlier authenticated experiment; current complete source manifest and instrumentation patch included.','full_frozen_batch':'No full140point20job batch executed; this bundle contains only the one authorized KLU gate and previousSparse diagnostic receipts.'}}
(r/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=r/'klu-one-gate-diagnostic-report.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in paths:z.write(f,f.relative_to(r).as_posix())
 z.write(r/'bundle-manifest.json','bundle-manifest.json')
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None;assert set(z.namelist())==set(manifest['files'])|{'bundle-manifest.json'};assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest['files'].items())
print(json.dumps({'bundle_sha256':sha(p),'bytes':p.stat().st_size,'members':len(paths),'readback_sha256':sha(r/'readback.json')},indent=2))
