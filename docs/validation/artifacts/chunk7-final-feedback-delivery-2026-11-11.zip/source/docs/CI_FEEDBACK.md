# Hosted source groups, November 11

The hosted feedback matrix requires contracts and GUI groups on both Linux and
Windows. Each group retains the same ordered stages, complete source-identity
checks and 300-second child limits; each job still has its 15-minute cap. The
required aggregate succeeds only when all four matrix jobs succeed. Artifact
names include the group to prevent collisions. No test or GUI gate is omitted.

`python scripts/ci_feedback.py` still runs all 14 stages locally. Explicit
`--group contracts` or `--group gui` selects seven stages and records the group,
exact expected stage names and `full_stage_selection=false`; a subset pass is
not a full-lane pass or release acceptance. This orchestration change addresses
the retained Windows outer-job timeout without increasing deadlines. Hosted
validation of the new matrix remains separate from source-level contract tests.

# Source feedback and selected acceptance candidates

The November 11 [ZIP-reader reconstruction](validation/chunk7-zip-reconstructed-validation-2026-11-11.json)
retains all archive guards and fixes the Windows fixture so malformed names
reach the reader unchanged. The reader rejects original wire names that were
normalized or NUL-truncated. All 14 local source stages pass with 1,817 tests
and 18 skips; exhaustive core passes 4,915 tests with 81 skips. Both runs retain
2,492 unchanged bound source identities. Independent adversarial controls show
the original reader accepting the aliases that the repaired reader rejects.
Hosted Windows and installed acceptance remain separate. The reconstructed WSL
pipeline is retained as an inert, reviewed snapshot, not included in these counts.


The [November 11 final integrated local record](validation/chunk7-next3-source-core-validation-2026-11-11.json)
passes all 14 selected stages in one uninterrupted run: 1,814 tests, 18 explicit
skips and 2,492 unchanged source identities. Its separate exhaustive core run
passes 4,912 tests with 81 skips. The compact archive retains all stage logs and
identity maps, with hashed omissions and an explicitly post-run-bound launcher.
These results include the strict elapsed-clock repair, diagnostic retirement,
portable PMOS v3 readback and linked tap source tests. They do not replace fresh
hosted source feedback or exact-candidate installed acceptance. Earlier source
results below retain their original scope and failures.

The November 11 portable PMOS v3 readback joins the existing IHP test stage.
It binds the complete compact evidence, source-aware contract, compiler patch,
licenses and immutable historical inputs to source identity. It reconstructs
and authenticates 588 payloads before read-only numerical audit. The historical
multiplicity rejection and separately source-derived consistency pass remain
distinct; no native binary is executed and no runtime default is replaced.
All prior stages and 300-second child limits remain unchanged. Native Windows
reparse behavior and installed application acceptance remain separate checks.


The isolated Windows diagnostics follow-on adds a bounded, allowlisted failure
summary before the full installed checkpoint upload. Its tests join the existing
source-feedback runtime stage and both hosted release-tool lanes. The summary is
diagnostic context, never an acceptance authority; its CI steps preserve the
existing prohibition on ignored step failures. Original verifier commands,
deadlines, identity guards and full evidence remain required.
The PowerShell transcript wrapper still needs native Windows validation; local
source tests cannot establish that transcript capture is complete.
The [local source coverage record](validation/windows-failure-summary-source-2026-11-10.json)
retains 1,763 tests and 18 skips across all 14 selected stages with unchanged
identities. Twelve stages precede a service interruption and two complete in a
separate bounded continuation; no uninterrupted-run claim is made.

The isolated November 10 follow-on lane adds measured-reference parsing/runtime
contracts, guard-via raw and corner-safe routing contracts, and v3 lossless
inventory transport to the existing bounded selections. All exact measurement,
compiler provenance, raw-geometry fixtures and contracts join source identity.
The app integration adds a separate fourteenth stage for the opt-in IHP
corner-safe guard editor. It exercises six model/rotation cases, 18 controls and
two legacy projects. The parent checks the exact launch nonce and output root,
then independently reads the complete evidence inventory, lifecycle controls and
saved/streamed layout geometry. Pinned guard assets and the packaged producer
join source identity; all thirteen prior stages and every 300-second child
deadline remain unchanged.

These checks do not execute or qualify the external native engines; separately
retained native failures, corrected-profile runs and measured diagnostics remain
distinct from source feedback, installed acceptance and calibration. A separate
additive installed guard gate requires fresh managed native jobs on the exact
clean candidate; source feedback cannot satisfy that gate.

The [final local integrated snapshot](validation/chunk7-ihp-guard-integrated-validation-2026-11-10.json)
passes all 14 stages in 434.543 seconds: 1,725 selected tests, 18 explicit skips,
and unchanged identities for all 2,464 bound inputs. Its separate exhaustive
core run passes 4,823 tests with 81 skips. The compact transport retains all
stage logs and the complete new guard GUI output/readback; other historical
GUI raw outputs remain local and are explicitly omitted from that transport.
These results do not stand in for fresh hosted Windows/Linux or installed gates.

The subsequent isolated PMOS v2 path adds its source tests and complete versioned
contract/evidence folder to this same bounded lane, preserving v1 and every
existing deadline. V2 requires actual KLU backend readback in every native job.
Its production comparison currently remains incomplete after a numerical timeout;
passing source tests cannot relabel that partial batch as measured or calibrated
acceptance.

The November 10 exact-candidate repair adds the physical verifier's identity,
stale-output and executable-mutation regressions to the existing unit stage.
Linux and Windows callers provide an explicit selected commit, independently
checked against HEAD before and after the frozen probe. General UI source
identity lookup is no longer used as an acceptance authority. Clean/frozen
build checks, all prior stages and all timeouts remain required. The retained
failed Linux run is not converted into a pass by a source-only repair.

The November 7 source-inventory additions join the existing bounded unit stages.
Fast feedback checks declaration parsing, source changes, missing views and
misleading model matches; complete archive/blob audits remain separately
retained evidence. The exact upstream graph and release metadata are included
in before/after source identity. All original stages and deadlines remain.

The source-disposition follow-through also binds the authenticated companion
graphs and both reviewed declaration reports. Its bounded tests cover omitted
symbol/configuration formats, missing target dispositions, changed source links,
and quoted text that could be mistaken for declarations. Complete raw-source
replays remain separate; an unresolved production format cannot pass merely
because its filename was inventoried.

IRSIM device declarations and XCircuit library/configuration readers now join
these same bounded stages. Controls distinguish literal declarations from
comments, strings and unsupported executable constructs, retain template-pin
diagnostics, and verify source locations. No stage or deadline is relaxed.

CVC checker declarations and six exact pinned physical-layer/stack paths also
join the unit stage. Tests preserve literal values and duplicate declarations,
reject unsupported grammar or source routes, and keep runtime/physical claims
separate from declaration accounting.

The legacy-symbol reader adds bounded headerless Xschem and Qucs component
declarations to the same stage. Controls distinguish pins, bus references,
power attributes, model names and numeric tokens; unsupported source routes,
executable records and malformed input remain rejected. Complete raw-source
replay and qualification remain separate, with all stage deadlines unchanged.

Schematic inventory checks now preserve valid multiline version headers and
enumerate the reviewed generated/literal views. Tests retain all historical
orphan-header declarations and reject embedded-code or unreviewed properties,
wrong source identities and hidden records. The finite source allowlist does
not establish symbol/model equivalence or application importability.

The November 7 [release-archive repair](validation/chunk7-release-archive-repair-2026-11-07.json)
adds a real solver bytecode-mutation control to the required runtime stage and
binds the exact historical GF180 launcher snapshot into source feedback. Linux
distribution names retain case-sensitive identity; Windows alias rejection and
complete archive byte checks remain required. Local source success does not
replace fresh exact-candidate release-archive acceptance.

The November 6 [historical-source repair](validation/chunk7-retained-platform-source-repair-2026-11-06.json)
adds retained SKY130 catalog authentication and current platform-staging tests
to fast feedback. The historical baseline, audit and all 121 source/input paths
join the before/after source inventory. The standalone runner resolves its
repository imports without relying on an ambient Python import path.

Windows timing exposed two overfull stages. The complete ordered unit selection
now runs in four nonoverlapping groups: core, IHP, remaining physical contracts,
and device contracts. All tests still execute exactly once, and each child keeps
its original 300-second deadline. All 13 final local stages pass on both hosts;
the retained failed attempts remain failed. Hosted and installed acceptance are
separate requirements.

The November 3 [source repair](validation/chunk7-desktop-source-repair-2026-11-03.json)
adds the actual recovery-to-widget test order and the real long-path Yosys
regression to fast feedback. Linux digital children with Yosys use a deterministic
line width so ABC's persistent command protocol retains its complete source-path
echo. Both digital runners preserve the parent's environment, source/tool checks,
temporary-directory isolation and existing timeout. Historical qualification
continues to name its exact original source rather than inheriting this repair.

Pull requests and merge-queue groups run **Fast source feedback** on Windows and
Linux. The default checkout tests GitHub's synthetic merge commit, preserving
compatibility with the proposed base. The lane compiles application, script and
test Python sources before installing dependencies, then runs focused editing,
PDK, runtime, physical-interface and release-contract tests plus the menu,
project-hub and five-model SKY130 resistor editor and multiplicity GUI smoke
checks, plus the complete finite 60-case IHP resistor editor lifecycle. The IHP
source check includes registry installation, both terminal-access choices,
rotations, save/reopen, regeneration and legacy recovery. Its complete evidence
inventory is checked again after the child exits; the template and legacy
assets are included in the source identity. This is source GUI evidence; the
separate installed gate requires fresh managed native jobs.
The lane has no path filter, so documentation-only
PRs also report its stable aggregate check, **PR feedback**.

After the first hosted run passed on October 23, `main` was configured to require
**PR feedback** from GitHub Actions, with an up-to-date base and the default
administrator bypass. The [configuration receipt](validation/chunk7-integration-feedback-2026-10-23.json)
records the exact policy readback. A workflow file alone cannot configure that
requirement. Source feedback is not packaged desktop acceptance, native physical
qualification or foundry signoff.

Expensive desktop and qualification workflows run for version tags, selected
manual candidates, or as reusable gates of release preparation. They no longer
start independent copies on both branch pushes and pull requests. The included
digital-runtime workflow remains reusable or manually selectable. Each manual
workflow requires `candidate_sha`: the full lowercase 40-character commit of
the selected branch or tag. The early candidate check compares that input with
the immutable event commit and the actual checkout. If the branch advanced,
dispatch again with the intended matching ref and SHA; stale evidence is never
silently relabelled as the new candidate.

For example, obtain the exact current commit and launch a reviewed integration
candidate (GitHub CLI commands shown for an existing authenticated checkout):

```text
git rev-parse HEAD
gh workflow run build-desktop.yml --ref experimental -f candidate_sha=FULL_COMMIT_SHA
gh workflow run reference-compatibility.yml --ref experimental -f candidate_sha=FULL_COMMIT_SHA
gh workflow run ihp-inductor-qualification.yml --ref experimental -f candidate_sha=FULL_COMMIT_SHA
```

**Prepare desktop release** is explicitly dispatched with the same candidate
input and its existing `publish_release` choice. It still runs every existing
desktop, interoperability, physical, digital, VGA, statistical and reference
gate, then verifies current-commit evidence before draft/public publishing. Its
manual publication policy is unchanged. IHP coil qualification remains a
separate candidate suite; this change does not invent a new release gate or
claim that suite is covered by release preparation. Successful development
feedback cannot replace fresh release acceptance.

Windows desktop CI builds the native component before its retained full core
suite and requires it to load in the ordinary test environment. Packaging first
checks that the selected compiler, source inputs and tested binary are unchanged;
the installer then uses the already tested build. This removes the former second
build invocation and repeated full core suite inside the installer step. The standalone Windows
build still runs its original default checks. Hosted timing and actual compilation
on the revised candidate remain separate acceptance observations.

The source lane also selects the finite IHP capacitor producer/reader, release
boundary and Windows native-identity controls. The early release-tools job
installs the pinned KLayout 0.30.5 reader for actual saved GDS/OASIS checks;
its reader tests remain mandatory. These do not replace the new
[installed capacitor gate](IHP_CMIM_INSTALLED_ACCEPTANCE.md).

Each feedback artifact retains the checked-out commit, Python/workflow/dependency
source hashes, stage return codes,
elapsed time, first-failure time when applicable, logs and GUI results. Stage
timings exclude dependency installation and queue time. Use GitHub run/job
creation and start timestamps for those additional measurements. Compare time
to first useful failure and time to close a device family's remaining gates;
smaller test counts alone do not establish faster qualification or completion.

To reproduce the source lane locally, install `requirements.txt` and
`requirements-qualification.txt`, then run
`python scripts/ci_feedback.py`. Native external engines are deliberately outside
this lane; the selected acceptance workflows retain their existing commands,
fault controls, raw evidence and release gates.

For local Windows runs, use a short, writable temporary directory and the
ordinary user account. The junction-protection fixtures require the ability to
create junctions; a restricted sandbox can block them even when file creation
works. Check temporary write/cleanup and those fixture prerequisites before
launching the full lane. Do not skip the protection tests or request Windows
administrator privileges. Preserve environment failures separately from the
subsequent unchanged-source acceptance.

The [October 23 local integration check](validation/ci-feedback-integration-2026-10-23.json)
passes 211 focused tests on each host (14 Windows skips, two Linux skips),
release-document validation and both GUI probes. Final elapsed times are
67.3 seconds on Windows and 33.9 seconds on Linux, excluding environment setup.
These are local observations, not hosted CI timings. An earlier Linux run used
the Windows-mounted checkout: its test stage took 262 seconds, compared with
6.2 seconds from a verified Linux-local source copy. Use native Linux storage
for WSL test checkouts; retain source identities when copying, and remove
redundant copies after verified evidence retention. The earlier overall run
remains invalid because the LI auditor changed while it was running.

The first hosted run on integration candidate `43a04bb` passes on GitHub's actual
PR merge commit. Linux completes in 1:35 and Windows in 2:29 including setup;
the aggregate passes at 4:07 after a 91-second queue wait. The feedback commands
themselves take 54.0 and 80.9 seconds respectively. Both hosts discover 211 tests
(two Linux skips, 13 Windows skips); all required stages pass, and downloaded
artifacts match all 1,328 checkpoint source hashes. These timings are one observation,
not a measured long-term speedup or full acceptance. Merge-queue execution and
the new native shared-toolchain producer/consumers remain separate verification.

The [subsequent focused integration](validation/chunk7-focused-integration-2026-10-23.json)
adds the selected LI reuse and MiM passive-corner/auditor checks. All 260 tests
pass on both hosts (15 Windows skips, two Linux skips), alongside release
document validation and both GUI probes. The observed local totals are 72.9
seconds on Windows and 36.6 seconds on native Linux storage; environment setup
and hosted queue time are excluded. Every checked source identity is retained.

Candidate `d38615c` subsequently passes [hosted PR feedback](validation/chunk7-focused-integration-2026-10-23.json)
in 2:24 overall on its actual merge commit. Both hosts discover 260 tests (two
Linux skips, 14 Windows skips) and pass all required stages. Source feedback
takes 53.4 seconds on Linux and 86.8 seconds on Windows; queue waits are two
and three seconds, with 37 and 44 seconds of setup before feedback. Downloaded
artifacts match all 1,336 current source bindings. This is a second measured
run, not a long-term latency guarantee or exhaustive acceptance.

The [signed-bias integration](validation/chunk7-bias-integration-2026-10-23.json)
adds the new MiM producer/auditor tests and shared-toolchain mismatch diagnostics.
It passes 293 tests per host (15 Windows skips, two Linux skips), release-document
checks and both GUI probes in 81.7 seconds on Windows and 39.0 seconds on native
Linux storage. All 1,340 source bindings match the frozen snapshot. These are
local timings; hosted queue/setup and installed acceptance remain separate.

The [October 26 capability repair](validation/chunk7-desktop-capability-repair-2026-10-26.json)
adds the exact native-layout capability test to this lane. It caught an outdated
expected list in the prior full desktop discovery; the corrected test preserves
all forged-metadata, layer and source-lock rejection checks. Only that method
is selected, with an explicit selector regression. The repaired source lane
passes 506 tests per host and all five stages; installed acceptance remains
separate.

The new repeated-cell and parallel-resistor work adds their focused producer
and independent-checker tests. A sixth stage exercises actual source Qt
multiplicity edits, attached routes, review/apply, undo/redo and save/reopen for
all five models. Native physical/electrical batches and installed delivery
remain separate acceptance gates. The historical 506-test, five-stage result
above retains its exact candidate and scope.

The [final October 26 array integration](validation/sky130-metal-parallel-source-feedback-2026-10-26.json)
passes all six stages on both hosts: 550 tests each, four Linux skips and sixteen
Windows skips. Source feedback takes 74.9 seconds on native Linux and 161.7
seconds on Windows, excluding environment preparation. All 1,386 source hashes
agree. Separate complete Linux discovery passes 3,725 tests with 61
environment-dependent skips; no installed acceptance is inferred.


The [October 26 desktop job split](validation/desktop-job-split-local-2026-10-26.json)
addresses a Windows job that reached the hosted six-hour limit during release
archive assembly. Packaging and its original 108 steps now hand the exact build
to a fresh installed-acceptance job, which preserves all 15 original remaining
steps, their native/GUI/electrical checks and timeouts. Release preparation still
requires the complete desktop workflow. Producer diagnostics and an installed
checkpoint are uploaded under separate names before the expensive later work.

The handoff validates the candidate, workflow run and attempt, host, workspace,
archive and every member before restoring into fresh destinations. It preserves
the producer's source ZIP, verifies its candidate Git sources and rejects stale
runtime readiness or prior installed acceptance. Source archive reuse does not
replace the extracted-distribution and installed-app checks. A consumer on a
later workflow attempt cannot reuse a handoff from the earlier attempt.

Local checks pass 45 tests on each host, including execution with site packages
disabled; four Windows skips cover POSIX-only link and permission controls.
Ten workflow controls and actionlint also pass. The portable release-tools lane
includes both handoff test modules without installing GUI or native dependencies.
These are synthetic archive/Git fixtures. The split still needs a successful
hosted candidate to establish actual transfer time, fresh host compatibility and
complete installed/release acceptance. The original timeout and incomplete
Windows diagnostic upload remain recorded; neither is promoted to a release pass.

The package-reconstruction checks run in a separate required
`package-contracts` stage. The eleven selected checks include the prior package
checks and the current pw2dn predecessor and reconstruction checks. A separate
required `runtime-release-contracts` stage adds the pinned Linux runtime and
release-receipt tests; the eight preceding stages remain required. Each of the
nine original stages retains the 300-second deadline and failure propagation. The source
identity also covers the selected SKY130 package assets, versioned contracts and
the retained Linux runtime archive. These checks do not replace installed
acceptance or the release gates.

The IHP capacitor-only corner action adds a required GUI stage and focused
save/reopen, mixed-device mapping and source-lock checks. The source identity
also includes the complete declared IHP package. A subsequent local Windows
run exceeded the existing five-minute unit-stage limit before finishing. The
same complete unit selection is now divided into required `unit-contracts` and
`device-contracts` stages. A control expands both selections and verifies every
original test appears exactly once; either stage's failure or timeout still
fails the lane. All eleven stages retain the 300-second per-process limit.


### November 11 research-source follow-on

The source lane now additionally requires all eight build-only WSL suites and
three guarded app-admission/dispatch/ELF suites. Existing stage deadlines and
all prior selected tests remain intact. The test-only ordinary-Windows junction
fixture preserves actual reparse-point rejection without requiring file-symlink
privilege. Source preparation does not authorize native WSL research execution.
See [the exact validation scopes](validation/ihp-wsl-source-integration-2026-11-11.json).
