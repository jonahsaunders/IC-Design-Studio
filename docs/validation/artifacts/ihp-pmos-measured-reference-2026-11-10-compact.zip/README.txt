BLOCKED partial diagnostic, not calibration acceptance.
Incomplete batch fails mandatory audit. No relocation-independent replay claim.
See BUNDLE-MANIFEST.json for exact included/omitted identities and recovery.
