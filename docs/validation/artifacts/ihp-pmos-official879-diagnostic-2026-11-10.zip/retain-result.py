import pathlib,json,hashlib,re,zipfile
r=pathlib.Path(__file__).parent;o=r/'one-gate';run=json.loads((o/'run.json').read_text());sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
logs={v:(o/v/'console.log').read_text() for v in ['baseline','patched']};traces={v:[x for x in text.splitlines() if x.startswith('IC879 ')] for v,text in logs.items()}
summary={'schema':1,'status':'OFFICIAL879_FIX_DID_NOT_COMPLETE_FROZEN_GATE','qualified':False,'scope':'Two controlled local diagnostic engines only; not application runtime replacement, calibration, full140point grid, full20job interface controls or cross-platform acceptance.',
'run_receipt_sha256':sha(o/'run.json'),'helper_sha256':sha(r/'run-one-gate.py'),'build_contract_sha256':sha(r/'build-contract.json'),'official_commit':'277e7654a93fdd872f436ebae50691eac5421748','cleanup_commit':'dde043369fc90fcc65b48a724d7ac7cda8325d19','paired_diff_sha256':sha(r/'actual-paired-difference.patch'),
'results':[{k:x[k] for k in ['variant','timed_out','seconds','returncode','affected_branch_observed','trace_events','trace_bytes','engine_sha256','files']} for x in run['runs']],
'sampled_traces_identical':traces['baseline']==traces['patched'],
'sampled_trace_differences':{'count':sum(a!=b for a,b in zip(traces['baseline'],traces['patched'])),'first_baseline':traces['baseline'][5],'first_patched':traces['patched'][5],'interpretation':'The official rollback demonstrably changes sampled old-RHS state, but does not complete this case. Coarse sums cannot prove full-vector equality.'},
'conclusions':['Both variants reached the affected OPtran nonconvergence/retry branch; this is no longer merely a bug-report analogy.','NIiter returned103 (E_ITERLIM), and retry events reduced timestep; later samples show many successful tiny steps rather than one permanently stuck initial Newton invocation.','The exact official retry fix plus teardown cleanup did not complete this frozen gate within the unchanged90second cap. Both raw files end in an unfinished point-count header; no complete measured comparison can be audited.','Sampled finite RHS sums are coarse read-only observations, not complete-vector equality or absence-of-all-NaN proof. Instrumented timings are not general performance results.','Do not infer that more time, a looser tolerance or a new model is valid. Stop this hypothesis; no further solver sweep or model change was performed.'],
'next_defensible_work':'A separately authorized targeted numerical investigation of why this unchanged PSP/OSDI circuit repeatedly reaches the iteration limit and tiny accepted steps is required before any new run. Missing measurement uncertainty/holdout metadata remains an independent calibration blocker even if completion is fixed.',
'provenance':'Full source trees, official bare repository, authenticated Debian packages/sysroot, compiler/dependency/build manifests/logs, complete executables and both process outputs retained locally in this investigation directory. Original attempt3/main/next and bundled engine untouched.'}
(r/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
# Small retained report bundle: raw evidence and reproducible-input identities, explicitly not runnable alone.
paths=[]
for p in sorted(r.glob('*')):
 if p.is_file() and p.suffix in ['.json','.patch','.py'] and p.name!='report-bundle-manifest.json':paths.append(p)
for v in ['baseline','patched']:
 for name in ['receipt.json','config.log','stage-0.log','stage-1.log','ldd.log']:paths.append(r/f'build-{v}'/name)
for p in o.rglob('*'):
 if p.is_file():paths.append(p)
for name in ['signature.log','chain.json','packages.json']:paths.append(r/'debian'/name)
paths.append(r/'pristine47/ngspice-47/COPYING')
for p in (r/'debian/sysroot/usr/share/doc').rglob('copyright'):paths.append(p)
manifest={'scope':'Diagnostic report bundle; not self-contained or relocation-independent native replay.','files':{str(p.relative_to(r)):sha(p) for p in paths},'omitted':{'compiled_engines':{v:sha(r/f'build-{v}/src/ngspice') for v in ['baseline','patched']},'source_trees':'Exact full source manifests included; pinned47archive and official patches retained locally and identified in proposal/build-contract.','compiler_packages_libraries':'Signed Debian chain and per-package hashes included; complete archives, compiler toolchain and library bytes remain external.','official_git':'Official commit identities and exact patches included, full bare clone local only.'}}
(r/'report-bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(r/'official879-diagnostic-report.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths:z.write(p,str(p.relative_to(r)))
 z.write(r/'report-bundle-manifest.json','report-bundle-manifest.json')
print(json.dumps({'result_sha256':sha(r/'result.json'),'traces_identical':summary['sampled_traces_identical'],'bundle_sha256':sha(r/'official879-diagnostic-report.zip'),'bundle_bytes':(r/'official879-diagnostic-report.zip').stat().st_size},indent=2))
