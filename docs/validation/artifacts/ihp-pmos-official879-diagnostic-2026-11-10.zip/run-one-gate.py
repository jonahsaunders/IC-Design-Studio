import pathlib,json,hashlib,subprocess,time,uuid,shutil,re
r=pathlib.Path(__file__).parent;old=pathlib.Path('/workspace/shared/ihp-pmos-measured-attempt-3');c=json.loads((r/'build-contract.json').read_text());sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def files(root):return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def deps(exe,env):
 p=subprocess.run(['ldd',str(exe)],capture_output=True,text=True,env=env,timeout=10);assert p.returncode==0 and 'not found' not in p.stdout+p.stderr
 return {str(pathlib.Path(s)):sha(s) for line in p.stdout.splitlines() for s in line.split() if s.startswith('/') and pathlib.Path(s).is_file()}
out=r/'one-gate';out.mkdir();rec={'helper_sha256':sha(__file__),'nonce':uuid.uuid4().hex,'qualified':False,'status':'RUNNING','build_contract_sha256':sha(r/'build-contract.json'),'runs':[]}
def save(): (out/'run.json').write_text(json.dumps(rec,indent=2)+'\n')
# Immutable historical source and module identities, independent of current repository.
historical=json.loads((old/'run.json').read_text())['files']
for prefix in ['pdk','runtime']:
 shutil.copytree(old/prefix,out/prefix)
 assert files(out/prefix)=={p[len(prefix)+1:]:h for p,h in historical.items() if p.startswith(prefix+'/')}
shutil.copyfile(old/'engine/runtime/spinit',out/'spinit');assert sha(out/'spinit')==historical['engine/runtime/spinit']
rec['inputs']=files(out)
try:
 for variant in ['baseline','patched']:
  d=out/variant;d.mkdir();b=r/('build-'+variant);receipt=json.loads((b/'receipt.json').read_text());assert receipt['status']=='built-not-executed' and all(receipt['features'].values())
  assert receipt['contract_sha256']==sha(r/'build-contract.json')=='9ae0a95ae4d0b2f1cbfbc3b37f62f7ea2d712b8f7ef48899626c85367b1ba9b2'
  exe=b/'src/ngspice';assert sha(exe)==receipt['executable_sha256']
  source=r/('source-'+variant);assert files(source)==json.loads((r/('source-'+variant+'-manifest.json')).read_text())
  # Keep original exact deck bytes and historical nonce; separate fresh execution nonce above.
  shutil.copyfile(old/'runs/nominal-3/input.cir',d/'input.cir');assert sha(d/'input.cir')==historical['runs/nominal-3/input.cir']
  env={'PATH':'/usr/bin:/bin','HOME':str(out),'LANG':'C','LC_ALL':'C','TZ':'UTC','SPICE_SCRIPTS':str(out),'OMP_NUM_THREADS':'1','LD_LIBRARY_PATH':c['environment']['LD_LIBRARY_PATH']}
  before=deps(exe,env);assert before==receipt['dependencies']
  module_deps={p.name:deps(p,env) for p in (out/'runtime').iterdir()}
  cmd=[str(exe),'-n','-D','filetype=ascii','-D','ngbehavior=hsa','-b','-r',str(d/'result.raw'),str(d/'input.cir')]
  row={'variant':variant,'command':cmd,'environment':env,'cwd':str(out),'deadline_seconds':90,'returncode':None,'timed_out':False,'engine_sha256':sha(exe),'build_receipt_sha256':sha(b/'receipt.json'),'dependencies_before':before,'module_dependencies':module_deps};rec['runs'].append(row);save();start=time.monotonic()
  try:
   with (d/'console.log').open('wb') as f:z=subprocess.run(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
   row['returncode']=z.returncode
  except subprocess.TimeoutExpired:row['timed_out']=True
  row['seconds']=time.monotonic()-start;row['dependencies_after']=deps(exe,env);assert row['dependencies_after']==before;assert sha(exe)==row['engine_sha256'];assert all(sha(out/p)==h for p,h in rec['inputs'].items())
  text=(d/'console.log').read_text();events=[line for line in text.splitlines() if line.startswith('IC879 ')];assert len(events)<=512 and sum(len((line+'\n').encode()) for line in events)<=131072
  row['trace_events']=len(events);row['trace_bytes']=sum(len((line+'\n').encode()) for line in events)
  row['affected_branch_observed']=any(re.search(r'kind=ni-return .* result=(?!0(?: |$))-?\d+',s) for s in events) and any('kind=retry-before ' in s for s in events) and any('kind=retry-after ' in s for s in events)
  row['files']=files(d);save()
  if variant=='baseline' and not row['affected_branch_observed']:
   rec['status']='STOPPED_NO_AFFECTED_BASELINE_BRANCH';break
 else:rec['status']='PAIRED_EXECUTED_DIAGNOSTIC_ONLY'
except BaseException as e:rec['status']='FAILED';rec['error']=repr(e);raise
finally:save()
print(json.dumps(rec,indent=2))
