import pathlib,json,hashlib,subprocess,time,concurrent.futures
r=pathlib.Path(__file__).parent;c=json.loads((r/'build-contract.json').read_text());env=c['environment'];sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def build(v):
 d=r/('build-'+v);d.mkdir();source=r/('source-'+v);manifest=json.loads((r/('source-'+v+'-manifest.json')).read_text())
 assert {str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}==manifest
 rec={'variant':v,'contract_sha256':sha(r/'build-contract.json'),'commands':[],'status':'building'}
 try:
  for i,cmd in enumerate(c['commands'][v]):
   start=time.monotonic()
   with (d/f'stage-{i}.log').open('wb') as f:z=subprocess.run(cmd,cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
   rec['commands'].append({'command':cmd,'returncode':z.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(d/f'stage-{i}.log')});assert z.returncode==0
  exe=d/'src/ngspice';rec['executable_sha256']=sha(exe)
  config=(d/'src/include/ngspice/config.h').read_text()
  rec['features']={k:('#define '+k+' ') in config for k in ['OSDI','XSPICE','KLU','PREDICTOR']};assert all(rec['features'].values())
  out=subprocess.run(['ldd',str(exe)],env=env,capture_output=True,text=True,timeout=10);assert out.returncode==0 and 'not found' not in out.stdout+out.stderr;(d/'ldd.log').write_text(out.stdout+out.stderr);rec['dependencies']={}
  for line in out.stdout.splitlines():
   for item in line.split():
    if item.startswith('/') and pathlib.Path(item).is_file():rec['dependencies'][item]=sha(item)
  rec['source_after']={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()};assert rec['source_after']==manifest
  rec['status']='built-not-executed'
 except BaseException as e:rec['status']='failed';rec['error']=repr(e);raise
 finally:(d/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
 print(v,rec['status'],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(build,['baseline','patched']))
