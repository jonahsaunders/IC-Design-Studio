import pathlib,json,hashlib,subprocess
r=pathlib.Path(__file__).parent;sysroot=r/'debian/sysroot';lib=sysroot/'usr/lib/x86_64-linux-gnu';home=r/'build-home';home.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
env={'PATH':str(sysroot/'usr/bin')+':/usr/bin:/bin','HOME':str(home),'LANG':'C','LC_ALL':'C','TZ':'UTC','BISON_PKGDATADIR':str(sysroot/'usr/share/bison'),'M4':str(sysroot/'usr/bin/m4'),'CPPFLAGS':'-I'+str(sysroot/'usr/include'),'LDFLAGS':'-L'+str(lib),'LD_LIBRARY_PATH':str(lib),'OMP_NUM_THREADS':'1'}
options=['--with-x=no','--enable-osdi','--enable-xspice','--enable-klu','--enable-predictor','--disable-debug','CFLAGS=-O2']
paths=['/usr/bin/gcc','/usr/bin/make','/usr/bin/as','/usr/bin/ld','/usr/bin/ar','/usr/bin/ranlib',subprocess.check_output(['gcc','-print-prog-name=cc1'],text=True).strip(),str(sysroot/'usr/bin/bison'),str(sysroot/'usr/bin/flex'),str(sysroot/'usr/bin/m4')]
record={'schema':1,'qualified':False,'status':'pending-independent-review','environment':env,'configure_options':options,'toolchain':{},'sources':{},'commands':{}}
for p in paths:
 out=subprocess.run(['ldd',p],capture_output=True,text=True,env=env);deps={}
 for line in out.stdout.splitlines():
  for s in line.split():
   if s.startswith('/') and pathlib.Path(s).is_file():deps[s]=sha(s)
 record['toolchain'][p]={'sha256':sha(p),'realpath':str(pathlib.Path(p).resolve()),'ldd':out.stdout+out.stderr,'dependencies':deps}
for variant in ['baseline','patched']:
 source=r/('source-'+variant);record['sources'][variant]={'manifest_sha256':sha(r/('source-'+variant+'-manifest.json'))}
 record['commands'][variant]=[[str(source/'configure'),'--prefix='+str(r/'install'),*options],['make','-j4']]
record['patches']={p.name:sha(p) for p in sorted(r.glob('*.patch'))}
record['debian_chain_sha256']=sha(r/'debian/chain.json')
record['trace']={'max_events':512,'max_bytes':131072,'max_nodes_per_event':4096,'sampling':'first32 per event kind plus powers of two','state_writes':'diagnostic counters only; no circuit-state writes','caveat':'RHS sums are coarse observations, not complete vector equality proof. Logging changes timing; no performance qualification.'}
record['test']={'selection':'exact retained nominal-3 input.cir, Vg=-1.124V,28drain points','process_deadline_seconds':90,'patched_launch_gate':'baseline trace must show nonzero ni-return and retry-before/retry-after; otherwise stop','prohibited':'No other gate/options/tolerance changes, no fullbatch or runtime replacement'}
(r/'build-contract.json').write_text(json.dumps(record,indent=2)+'\n');print(sha(r/'build-contract.json'))
