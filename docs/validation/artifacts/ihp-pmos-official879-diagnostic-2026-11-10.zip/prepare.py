import pathlib,subprocess,shutil,difflib,hashlib,json
r=pathlib.Path(__file__).parent;base=r/'pristine47/ngspice-47'
helper=r'''/* Diagnostic observation only: no circuit-state writes; hard process-wide caps. */
static unsigned long ictrace_seen[6];
static unsigned long ictrace_events;
static size_t ictrace_bytes;
static void ictrace(CKTcircuit *ckt, int kind, double time, int result)
{
    static const char *names[] = {"accept-before-save", "ni-enter", "ni-return", "retry-before", "retry-after", "accept-after-save"};
    char line[512];
    unsigned long n = ++ictrace_seen[kind];
    unsigned int nodes = 0, bad = 0;
    double oldsum = 0.0, rhssum = 0.0;
    CKTnode *node;
    int len;
    if (ictrace_events >= 512 || ictrace_bytes >= 131072)
        return;
    if (n > 32 && (n & (n - 1)) != 0)
        return;
    for (node = ckt->CKTnodes; node && nodes < 4096; node = node->next) {
        double old = ckt->CKTrhsOld[node->number];
        double rhs = ckt->CKTrhs[node->number];
        if (!isfinite(old) || !isfinite(rhs)) ++bad;
        else { oldsum += old; rhssum += rhs; }
        ++nodes;
    }
    len = snprintf(line, sizeof(line), "IC879 kind=%s count=%lu time=%.17g delta=%.17g result=%d nodes=%u bad=%u oldsum=%.17g rhssum=%.17g\n",
                   names[kind], n, time, ckt->CKTdelta, result, nodes, bad, oldsum, rhssum);
    if (len <= 0 || (size_t)len >= sizeof(line) || ictrace_bytes + (size_t)len > 131072)
        return;
    fwrite(line, 1, (size_t)len, stderr);
    fflush(stderr);
    ++ictrace_events;
    ictrace_bytes += (size_t)len;
}

'''
# Kind0 observes accepted current RHS immediately after CKTaccept and before the official copy.
def instrument(b):
 s=b.decode();s=s.replace('int OPclrBreak(CKTcircuit* ckt);',helper+'int OPclrBreak(CKTcircuit* ckt);',1)
 s=s.replace('    error = CKTaccept(ckt);','    error = CKTaccept(ckt);\n    ictrace(ckt, 0, optime, error);',1)
 s=s.replace('    /* check if current breakpoint is outdated; if so, clear */','    ictrace(ckt, 5, optime, error);\n    /* check if current breakpoint is outdated; if so, clear */',1)
 s=s.replace('        converged = NIiter(ckt,ckt->CKTtranMaxIter);','        ictrace(ckt, 1, optime, -1);\n        converged = NIiter(ckt,ckt->CKTtranMaxIter);\n        ictrace(ckt, 2, optime, converged);',1)
 s=s.replace('        if(converged != 0) {','        if(converged != 0) {\n            ictrace(ckt, 3, optime, converged);',1)
 start=s.index('        if(converged != 0) {');pos=s.index('            if(firsttime) {',start)
 s=s[:pos]+'            ictrace(ckt, 4, optime, converged);\n'+s[pos:]
 return s.encode()
for kind in ['baseline','patched']:
 dst=r/('source-'+kind)
 if dst.exists():raise SystemExit('refuse overwrite')
 shutil.copytree(base,dst)
 subprocess.run(['git','apply',str(r/'../ihp-pmos-measured-attempt-3/engine/sources/capacitor-multiplier.patch')],cwd=dst,check=True)
 if kind=='patched':
  for name in ['official-277e7654a.patch','adapted47-cktdest-free.patch']:subprocess.run(['git','apply',str(r/name)],cwd=dst,check=True)
 path=dst/'src/spicelib/analysis/optran.c';before=path.read_bytes();after=instrument(before);path.write_bytes(after)
 (r/('instrumentation-'+kind+'.patch')).write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/src/spicelib/analysis/optran.c',tofile='b/src/spicelib/analysis/optran.c')))
 manifest={str(x.relative_to(dst)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(dst.rglob('*')) if x.is_file()}
 (r/('source-'+kind+'-manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n')
# Actual paired difference must contain only upstream primary + cleanup, despite shifted instrumentation context.
p1=r/'source-baseline';p2=r/'source-patched';out=[]
for name in json.loads((r/'source-baseline-manifest.json').read_text()):
 a=(p1/name).read_bytes();b=(p2/name).read_bytes()
 if a!=b:out.extend(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(r/'actual-paired-difference.patch').write_text(''.join(out))
