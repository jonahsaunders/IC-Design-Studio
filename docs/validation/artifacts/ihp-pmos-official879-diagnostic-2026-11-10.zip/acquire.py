import pathlib,hashlib,subprocess,lzma,json,urllib.request,concurrent.futures
r=pathlib.Path(__file__).parent;p=r/'debian';p.mkdir(exist_ok=True);(p/'gnupg').mkdir(exist_ok=True);(p/'gnupg').chmod(0o700)
old=pathlib.Path('/workspace/shared/physical-tool-inspect/debian')
for name in ['InRelease','Packages.xz']:(p/name).write_bytes((old/name).read_bytes())
cmd=['gpg','--homedir',str(p/'gnupg'),'--no-default-keyring','--keyring','/usr/share/keyrings/debian-archive-keyring.gpg','--status-fd','1','--verify',str(p/'InRelease')]
z=subprocess.run(cmd,capture_output=True,text=True);(p/'signature.log').write_text(z.stdout+z.stderr);assert z.returncode==0 and '[GNUPG:] VALIDSIG ' in z.stdout
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(p/'Packages.xz').read_bytes();entry=f'{sha(raw)} {len(raw):16d} main/binary-amd64/Packages.xz'
assert any(line.split()==[sha(raw),str(len(raw)),'main/binary-amd64/Packages.xz'] for line in (p/'InRelease').read_text().splitlines())
names={'libreadline-dev','libreadline8t64','libncurses-dev','libncurses6','libncursesw6','libtinfo6','bison','flex','libfl2','libfl-dev','m4','readline-common'};selected=[]
for block in lzma.decompress(raw).decode().split('\n\n'):
 d=dict(x.split(': ',1) for x in block.splitlines() if ': ' in x and not x.startswith(' '))
 if d.get('Package') in names:selected.append(d)
assert {x['Package'] for x in selected}==names
(p/'packages.json').write_text(json.dumps(selected,indent=2)+'\n')
def get(d):
 dest=p/pathlib.Path(d['Filename']).name
 if not dest.exists():
  retained=old/dest.name
  if retained.exists():dest.write_bytes(retained.read_bytes())
  else:
   with urllib.request.urlopen('https://snapshot.debian.org/archive/debian/20261103T013555Z/'+d['Filename'],timeout=90) as f:dest.write_bytes(f.read())
 assert sha(dest.read_bytes())==d['SHA256']
 subprocess.run(['dpkg-deb','-x',str(dest),str(p/'sysroot')],check=True)
 return dest.name
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(get,selected):print(result,flush=True)
(p/'chain.json').write_text(json.dumps({'keyring_sha256':sha(pathlib.Path('/usr/share/keyrings/debian-archive-keyring.gpg').read_bytes()),'InRelease_sha256':sha((p/'InRelease').read_bytes()),'Packages_sha256':sha(raw),'signature_command':cmd,'packages':{d['Package']:d['SHA256'] for d in selected}},indent=2)+'\n')
