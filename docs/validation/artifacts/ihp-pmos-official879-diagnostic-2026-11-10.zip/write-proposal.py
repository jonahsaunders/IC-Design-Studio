import json,hashlib,pathlib,subprocess
r=pathlib.Path('/workspace/shared/ihp-psp-engine-investigation');p=r/'pristine47/ngspice-47'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((r/'upstream-commit.json').read_text())
record={
'schema':1,'status':'proposal-only-no-build-or-native-execution','profile':'ngspice47-official879-optran-diagnostic-v1',
'official_origin':'https://git.code.sf.net/p/ngspice/ngspice','official_commit':c['sha'],'official_parent':c['parents'][0]['sha'],'official_git_path':str(r/'official.git'),'mirror_url':c['html_url'],
'patch':{'path':str(r/'official-277e7654a.patch'),'sha256':sha(r/'official-277e7654a.patch'),'files':[x['filename'] for x in c['files']],'git_apply_check_on_pristine47':'passed; no patch applied'},
'cleanup_patch':{'upstream_commit':'dde043369fc90fcc65b48a724d7ac7cda8325d19','path':str(r/'official-cktdest-free.patch'),'sha256':sha(r/'official-cktdest-free.patch'),'scope':'Only one-line CKTrhsAccepted release in CKTdestroy; exclude unrelated lexer/device hunks. Must review and apply-check after primary patch.'},
'base':{'archive':'/workspace/shared/ihp-pmos-measured-attempt-3/engine/sources/ngspice-47.tar.gz','sha256':'894e649651f1838a14095e5a5439e7d3aa63e87ede14d283173fda4fcdef675f','existing_capacitor_patch':'/workspace/shared/ihp-pmos-measured-attempt-3/engine/sources/capacitor-multiplier.patch','retained_build_script':'/workspace/shared/ihp-pmos-measured-attempt-3/engine/sources/build_ngspice_runtime.py'},
'causal_analysis':{
'confirmed':'Observed Transient op started is emitted by OPtran line331. CKTop calls OPtran at line97 after conventional OP fails. Both stepping options are zero in frozen deck. OPtran calls NIiter at704, enters nonconvergence at727, reduces delta at735 without accepted-RHS rollback. The exact official patch covers this OPtran path, not just DCtran. osdiload.c140 forwards CKTrhsOld to OSDI prev_solve.',
'predictor':'Bundled build enables PREDICTOR, but OPtran has no NIpred call or PREDICTOR conditional; dctran does. Thus the issue report default-PREDICTOR caveat does not exclude this OPtran path.',
'not_yet_proven':'Current console proves entry but no per-step trace. It does not establish NIiter returned nonzero or whether stall instead consists of accepted tiny steps, an inner model/solver loop, or another path. Official patch applicability is plausible, not demonstrated cause.',
'source_files':{s:sha(p/s) for s in ['src/spicelib/analysis/cktop.c','src/spicelib/analysis/optran.c','src/osdi/osdiload.c','src/maths/ni/niiter.c','src/maths/ni/nireinit.c','src/maths/ni/nidest.c','src/include/ngspice/cktdefs.h']}
},
'proposed_build':{
'configure':['--with-x=no','--enable-osdi','--enable-xspice','--enable-klu','--enable-predictor','--disable-debug','CFLAGS=-O2'],
'compiler_observed':'gcc (Debian 14.2.0-19) 14.2.0; GNU Make4.4.1; exact compiler, cc1, assembler, linker and dependency hashes must be retained before execution',
'missing_prerequisites':'readline development headers/libraries and bison/flex are absent from PATH/current retained Debian sysroot. KLU is vendored in ngspice source, not an external missing dependency. Release archive includes configure/generated parser; determine if generator execution needed. No system installs authorized.',
'route':'Use existing authenticated Debian13 Packages.xz/InRelease acquisition approach to extract only necessary official packages into isolated sysroot if parent authorizes. Preserve original configure options and all features; no silent disable-readline or solver changes. Retain source archive, both exact upstream patches, existing capacitor fix, source manifests, compiler/linker/environment/commands/config.log/build logs/licenses, resulting executable and ldd/readelf dependency closure. New runtime identity only; not binary reproducibility claim.',
'instrumentation':'Separately retained diagnostic-only optran patch: bounded first16 NIiter-entry/exit and accepted/rejected-step logs plus periodic counters, optime/delta/returncode and finite/nonfinite/max-difference summaries of RHS before/after rollback. Do not alter numerical state, limits, tolerances or options. Log flush after each bounded event. No unbounded per-iteration logging.',
'causal_control':'Prefer same-toolchain unpatched instrumented control plus patched instrumented variant, one frozen failing gate per variant at90s, because rebuild/toolchain changes otherwise confound cure attribution. This is two processes for one case, requires explicit parent/reviewer approval. If only one patched process authorized, do not call success causal proof against original different build.'
},
'frozen_experiment':{
'original_deck':'/workspace/shared/ihp-pmos-measured-attempt-3/runs/nominal-3/input.cir','original_deck_sha256':sha(pathlib.Path('/workspace/shared/ihp-pmos-measured-attempt-3/runs/nominal-3/input.cir')),
'selection':'Vg=-1.124V only; 28 Vd points0:-0.05:-1.35; nominal unchanged W=L10um, explicitAD/AS/PD/PS, T27C, all4signed terminal currents.',
'inputs':'Copy immutable attempt3 model/module/dependency/source identity; fresh output paths and nonce; unchanged equation/accuracy/90seconddeadline/solverprotocol; no measurement fitting.',
'observables':'branch-entry and retry trace, raw completeness exactly28points, finite all4currents, strict existing log checks, KCL existing numerical tolerance; report measurement residuals only if complete, without pass threshold.',
'interpretation':'If failed-step branch is observed and patched restores RHS then completes while samebuild control stalls, evidence supports this one-case remedy. If branch absent or corrected still stalls, no cure claim; stop rather than sweep options. No full140point,20job,calibration,RF,process-envelope,cross-platform or application acceptance.',
'approval_required':'Independent source/build/instrumentation review and explicit parent execution authorization before build/run.'}}
(r/'proposal.json').write_text(json.dumps(record,indent=2)+'\n')
print(sha(r/'proposal.json'))
