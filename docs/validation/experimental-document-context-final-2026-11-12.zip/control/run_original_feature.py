from pathlib import Path
import sys, tempfile, subprocess, hashlib, runpy
root=Path.cwd()
base='f418e3e76ea539358ec470228d7ba3810177da8d'
source=subprocess.check_output(['git','show',base+':icstudio/feature_ui.py'])
assert hashlib.sha256(source).hexdigest()=='0404f3a6acf2cbf12d137ae145945bdb5400180bf47ae15dcf2c4cc1fd02cb3d'
assert hashlib.sha256((root/'tests/gui_project_data_safety.py').read_bytes()).hexdigest()=='86b91ba150b282d1059926c1ded630bc5252abfed14db511b239b5d221bed35e'
print('Final recovery negative control: exact f418e3e feature_ui.py; ID-only Cell Parameters, no Regenerate or Erase guard.',flush=True)
print('feature_ui.py SHA256: '+hashlib.sha256(source).hexdigest(),flush=True)
print('GUI regression SHA256: '+hashlib.sha256((root/'tests/gui_project_data_safety.py').read_bytes()).hexdigest(),flush=True)
with tempfile.TemporaryDirectory(prefix='icstudio-final-recovery-control-') as td:
    package=Path(td)/'icstudio';package.mkdir()
    for p in (root/'icstudio').iterdir():
        if p.name not in ('feature_ui.py','__pycache__'):
            (package/p.name).symlink_to(p,target_is_directory=p.is_dir())
    (package/'feature_ui.py').write_bytes(source)
    sys.path[:0]=[td,str(root)]
    import icstudio.feature_ui as f
    assert Path(f.__file__).read_bytes()==source
    sys.argv=['tests.gui_project_data_safety','-v','-k','test_regenerate','-k','test_context_session','-k','test_erase']
    runpy.run_module('tests.gui_project_data_safety',run_name='__main__',alter_sys=True)
