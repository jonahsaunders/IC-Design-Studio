from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.ci_feedback import source_identity,check_syntax,UNIT_STAGE_MODULES
out=root/'build/final-context-evidence'
env={k:v for k,v in os.environ.items() if not k.upper().startswith('GIT_')};env.update(QT_QPA_PLATFORM='offscreen',PYTHONPATH=str(root/'tests'),PYTHONUTF8='1')
started=datetime.datetime.now(datetime.timezone.utc).isoformat();before=source_identity();syntax=check_syntax();(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
cmd=[sys.executable,'-m','unittest',*('tests.'+x for x in UNIT_STAGE_MODULES),'-v'];t0=time.monotonic();error=None
try:
 with (out/'unit-contracts.log').open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300);rc=r.returncode
except subprocess.TimeoutExpired:rc=124;error='Unchanged 300-second stage deadline exceeded.'
finally:
 elapsed=time.monotonic()-t0;after=source_identity();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
receipt={'schema':1,'started_utc':started,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Final combined Cell Parameters, Regenerate and Erase context guards; complete affected UNIT_STAGE_MODULES only','command':cmd,'returncode':rc,'error':error,'elapsed_seconds':round(elapsed,3),'syntax_files':syntax,'source_count':len(before),'source_unchanged':before==after,'launcher_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'environment':{'python':sys.version,'QT_QPA_PLATFORM':env['QT_QPA_PLATFORM'],'PYTHONPATH':env['PYTHONPATH']},'packages':subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True).splitlines(),'full_source_acceptance':False,'installed_acceptance':False,'historical_acceptance_inherited':False}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));print((out/'unit-contracts.log').read_text()[-700:]);raise SystemExit(rc if rc else (0 if before==after else 1))
