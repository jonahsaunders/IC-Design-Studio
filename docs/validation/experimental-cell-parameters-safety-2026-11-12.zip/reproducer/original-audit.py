import json
from pathlib import Path
from unittest.mock import patch
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QDialogButtonBox,QFileDialog
from shiboken6 import isValid
from tests.gui_project_data_safety import ProjectDataSafetyTests
from icstudio.model import clone,digest,uid,example,save_project,load_project
T=ProjectDataSafetyTests;T.setUpClass();t=T('test_same_file_save_reloads_saved_edits_and_next_save_preserves_them');w=t.window
results={'source_feature_ui_blob':'150fc0c9b70447b28e850210f2ac2c8006392046','mro':{name:[c.__name__ for c in type(w).__mro__ if name in c.__dict__] for name in ('edit_parameters','workflow_form','switch_cell_combo','commit')},'cases':[]}
A={'resistance':'10k','a_only':'1'};B={'resistance':'20k','b_only':'2'};EDIT={'resistance':'33k','a_only':'3'}
def action():
    actions=[a for a in w.findChildren(QAction) if a.text().replace('&','')=='Cell parameters…'];assert len(actions)==1 and actions[0].isEnabled();return actions[0]
def params(project):return {c['name']:c.get('parameters',{}) for c in project['cells']}
try:
  w.show();T.app.processEvents()
  for change,accept in [('none',True),('cell',True),('cell',False),('project',True),('project',False)]:
    path,_=t.prepare(dirty=False);w.mode_combo.setCurrentIndex(0);p=clone(w.project);aid=p['cells'][0]['id'];p['cells'][0].update(name='Cell_A',parameters=A);b={'id':uid(),'name':'Cell_B','ports':[],'devices':[],'shapes':[],'labels':[],'parameters':B};p['cells'].append(b);w.set_project(p,path);assert w.save();old_id=w.project['id'];source_bytes=path.read_bytes();before_all=digest(w.project)
    action().trigger();dlg=w._workflow_dialog;T.app.processEvents();assert dlg.isVisible() and not dlg.isModal();field=dlg.fields['parameters'];assert 'a_only = 1' in field.toPlainText() and 'b_only' not in field.toPlainText()
    QTest.mouseClick(field,Qt.LeftButton);QTest.keyClick(field,Qt.Key_A,Qt.ControlModifier);QTest.keyClicks(field,'resistance = 33k');QTest.keyClick(field,Qt.Key_Return);QTest.keyClicks(field,'a_only = 3');assert field.toPlainText()=='resistance = 33k\na_only = 3'
    target_path=path
    if change=='cell':
      assert w.cell_combo.isVisible() and w.cell_combo.isEnabled();w.cell_combo.setFocus();QTest.keyClick(w.cell_combo,Qt.Key_End);assert w.cid==b['id'];assert dlg.isVisible()
    if change=='project':
      target_path=path.parent/'another project.icproj';other=example();other['name']='Different project';other['cells'][0].update(name='Other_project_cell',parameters={'other_only':'9'});save_project(other,target_path)
      with patch.object(QFileDialog,'getOpenFileName',return_value=(str(target_path),'')):w.open_project()
      assert w.project['id']!=old_id and w.path==target_path and dlg.isVisible()
    before=digest(w.project);params_before=params(w.project);history=len(w.history.undo_stack);old_disk=target_path.read_bytes();saved=w.saved_hash;selected=list(w.selection);current=w.cid
    dlg.findChild(QDialogButtonBox).button(QDialogButtonBox.Ok if accept else QDialogButtonBox.Cancel).click()
    row={'switch':change,'accepted':accept,'dialog_modeless':not dlg.isModal(),'dialog_result':dlg.result(),'dialog_error':dlg.error.text(),'active_cell':w.cell['name'],'parameters_before':params_before,'parameters_after':params(w.project),'history_entries_added':len(w.history.undo_stack)-history,'project_unchanged':digest(w.project)==before,'current_and_selection_retained':w.cid==current and w.selection==selected,'saved_hash_unchanged':w.saved_hash==saved,'disk_unchanged_before_explicit_save':target_path.read_bytes()==old_disk,'source_file_unchanged_before_save':path.read_bytes()==source_bytes,'errors':list(t.errors)}
    if accept:
      committed=params(w.project);w.undo();row['undo_restores_original_parameters']=params(w.project)==params_before;w.redo();row['redo_restores_committed_parameters']=params(w.project)==committed;assert w.save();row['disk_parameters_after_save']=params(load_project(target_path));row['source_file_still_unchanged_after_target_save']=path.read_bytes()==source_bytes
    else:assert row['project_unchanged'] and row['history_entries_added']==0
    results['cases'].append(row)
    if isValid(dlg):dlg.reject()
    T.app.processEvents()
  Path('/tmp/icstudio-cell-parameters-audit.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
finally:T.tearDownClass()
