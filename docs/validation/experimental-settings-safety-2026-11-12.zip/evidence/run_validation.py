from pathlib import Path
import json,os,subprocess,sys,time,hashlib,datetime
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.ci_feedback import source_identity,check_syntax,UNIT_STAGE_MODULES
out=root/'build/settings-safety-evidence'
start=datetime.datetime.now(datetime.timezone.utc).isoformat();before=source_identity();syntax=check_syntax()
(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
cmd=[sys.executable,'-m','unittest',*('tests.'+x for x in UNIT_STAGE_MODULES),'-v']
t0=time.monotonic()
with (out/'unit-contracts.log').open('w') as log:
    p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300)
elapsed=time.monotonic()-t0;after=source_identity()
(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
receipt={'schema':1,'started_utc':start,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'complete affected UNIT_STAGE_MODULES; not full source/core or installed acceptance','command':cmd,'returncode':p.returncode,'elapsed_seconds':round(elapsed,3),'syntax':syntax,'source_count':len(before),'source_unchanged':before==after,'launcher_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'environment':{'python':sys.version,'QT_QPA_PLATFORM':os.environ.get('QT_QPA_PLATFORM'),'PYTHONPATH':os.environ.get('PYTHONPATH')}}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));print((out/'unit-contracts.log').read_text()[-500:]);assert p.returncode==0 and before==after
