"""Coverage failures must not silently shrink the public qualification target."""
import copy
from pathlib import Path
import unittest
from unittest.mock import patch

from scripts.check_pdk_qualification import (
    MATRIX, TARGETS, HOSTED_TOOLCHAIN_STEPS, read, validate, validate_toolchain_record,
)


class QualificationMatrixTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.matrix = read(MATRIX)

    def test_complete_inventory_is_bookkeeping_not_qualification(self):
        report = validate(self.matrix)
        self.assertEqual(report['status'], 'matrix_consistent')
        self.assertEqual(report['process_qualification'], 'unqualified')
        self.assertEqual(report['device_entries'], 302)

    def test_retained_solver_source_is_bound_and_cannot_change_or_disappear(self):
        from scripts.check_pdk_qualification import ROOT
        from scripts.ci_feedback import source_identity
        manifest = self.matrix['execution_acceptance']['4']['historical_source_snapshot']
        captured = read(ROOT/manifest['path'])['files']['openems_runtime.py']
        target = (ROOT/captured['path']).resolve()
        identities = source_identity()
        self.assertEqual(identities[captured['path']], captured['sha256'])
        self.assertEqual(identities[manifest['path']], manifest['sha256'])
        original = Path.read_bytes
        for missing in (False, True):
            def read_bytes(path):
                if path.resolve() == target:
                    if missing: raise FileNotFoundError(str(path))
                    return original(path)+b'\nchanged historical source\n'
                return original(path)
            with self.subTest(missing=missing), patch.object(Path, 'read_bytes', read_bytes):
                with self.assertRaises(FileNotFoundError if missing else ValueError):
                    validate(self.matrix)
        self.assertEqual(validate(self.matrix)['status'], 'matrix_consistent')

    def test_retained_document_safety_sources_cannot_change_or_disappear(self):
        from scripts.check_pdk_qualification import ROOT
        from scripts.ci_feedback import source_identity
        reference = self.matrix['execution_acceptance']['4']['historical_source_snapshot']
        manifest = read(ROOT / reference['path'])
        identities = source_identity()
        self.assertEqual(identities[reference['path']], reference['sha256'])
        original = Path.read_bytes
        for name in ('feature_ui.py', 'gui.py', 'xschem_workflow.py', 'lifecycle_ui.py', 'native_workspace.py', 'project_store.py', 'model.py', 'consistency_workspace.py', 'layout_ui.py'):
            captured = manifest['files'][name]
            target = (ROOT / captured['path']).resolve()
            self.assertEqual(identities[captured['path']], captured['sha256'])
            for missing in (False, True):
                def read_bytes(path):
                    if path.resolve() == target:
                        if missing:
                            raise FileNotFoundError(str(path))
                        return original(path) + b'\nchanged historical source\n'
                    return original(path)
                with self.subTest(name=name, missing=missing), patch.object(Path, 'read_bytes', read_bytes):
                    with self.assertRaises(FileNotFoundError if missing else ValueError):
                        validate(self.matrix)
        self.assertEqual(validate(self.matrix)['status'], 'matrix_consistent')

    def test_density_reference_record_cannot_complete_missing_fill_coverage(self):
        matrix = copy.deepcopy(self.matrix)
        self.assertIn('4', matrix['execution_acceptance'])
        # The older native-only record cannot replace full manual coverage.
        matrix['execution_acceptance']['4'] = dict(
            path=matrix['evidence']['gf-density-acceptance']['path'],
            sha256=matrix['evidence']['gf-density-acceptance']['sha256'])
        for target in ('gf180mcuC', 'gf180mcuD'):
            matrix['requirements'][target+':gf180-density']['status'] = 'partial'
        matrix['chunks']['4']['status'] = 'reference_gate_complete'
        with self.assertRaisesRegex(ValueError, 'full fill coverage'):
            validate(matrix)

    def test_omitted_unavailable_device_is_rejected(self):
        matrix = copy.deepcopy(self.matrix)
        del matrix['device_requirements']['ihp-sg13g2']['sg13g2_pr/inductor.sym']
        with self.assertRaisesRegex(ValueError, 'Device omitted'):
            validate(matrix)

    def test_variant_c_evidence_cannot_remove_variant_d_requirement(self):
        matrix = copy.deepcopy(self.matrix)
        del matrix['requirements']['gf180mcuD:digital-profile']
        with self.assertRaisesRegex(ValueError, 'Requirement coverage'):
            validate(matrix)

    def test_stale_manifest_and_partial_device_test_are_rejected(self):
        matrix = copy.deepcopy(self.matrix)
        matrix['inventory']['gf180mcuC']['revision'] = 'changed'
        with self.assertRaisesRegex(ValueError, 'inventory is stale'):
            validate(matrix)
        matrix = copy.deepcopy(self.matrix)
        matrix['device_requirements']['sky130A']['sky130_fd_pr/nfet_01v8.sym']['tests'].remove('device-physical')
        with self.assertRaisesRegex(ValueError, 'Incomplete device coverage'):
            validate(matrix)

    def test_smoke_result_cannot_be_promoted_to_qualified(self):
        matrix = copy.deepcopy(self.matrix)
        matrix['requirements']['sky130A:device-simulation']['status'] = 'passed'
        with self.assertRaisesRegex(ValueError, 'Unsupported qualification claim'):
            validate(matrix)

    def test_unavailable_model_cannot_be_promoted(self):
        matrix = copy.deepcopy(self.matrix)
        matrix['device_requirements']['ihp-sg13g2']['sg13g2_pr/inductor.sym']['status'] = 'partial'
        with self.assertRaisesRegex(ValueError, 'Unavailable device promoted'):
            validate(matrix)

    def test_reference_pass_requires_its_own_acceptance_record(self):
        matrix = copy.deepcopy(self.matrix)
        matrix.pop('execution_acceptance', None)
        matrix['requirements']['sky130A:tool-install'].update(status='passed_reference', acceptance_chunk=2)
        with self.assertRaisesRegex(ValueError, 'Unbound reference pass'):
            validate(matrix)

    def test_changed_evidence_and_empty_acceptance_contract_are_rejected(self):
        matrix = copy.deepcopy(self.matrix)
        matrix['evidence']['gds-diagnostics']['sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'Evidence changed'):
            validate(matrix)
        matrix = copy.deepcopy(self.matrix)
        matrix['tests']['ihp-rf']['expected_result'] = ''
        with self.assertRaisesRegex(ValueError, 'Missing test contract'):
            validate(matrix)

    def test_geometry_and_later_chunks_cannot_be_promoted_without_bound_evidence(self):
        matrix = copy.deepcopy(self.matrix)
        matrix['schema'] = 3
        matrix.get('execution_acceptance', {}).pop('6', None)
        matrix['chunks']['6']['status']='in_progress'
        matrix.get('execution_acceptance', {}).pop('5', None)
        matrix['chunks']['5']['status']='in_progress'
        matrix['requirements']['ihp-sg13g2:ihp-fill']['status']='partial'
        matrix.get('execution_acceptance', {}).pop('3', None)
        matrix.get('execution_acceptance', {}).pop('4', None)
        matrix['chunks']['4']['status'] = 'in_progress'
        for requirement in matrix['requirements'].values():
            if requirement.get('acceptance_chunk') in (3, 4):
                requirement.update(status='partial')
                requirement.pop('acceptance_chunk')
        matrix['chunks']['3']['status'] = 'reference_gate_complete'
        with self.assertRaisesRegex(ValueError, 'Geometry execution gate'):
            validate(matrix)
        matrix['chunks']['3']['status'] = 'in_progress'
        matrix['requirements']['gf180mcuD:gf180-geometry'].update(status='passed_reference', acceptance_chunk=3)
        with self.assertRaisesRegex(ValueError, 'Unbound reference pass'):
            validate(matrix)
        matrix = copy.deepcopy(self.matrix)
        matrix['schema'] = 3
        matrix.get('execution_acceptance', {}).pop('6', None)
        matrix['chunks']['6']['status']='in_progress'
        matrix.get('execution_acceptance', {}).pop('5', None)
        matrix['chunks']['5']['status']='in_progress'
        matrix['requirements']['ihp-sg13g2:ihp-fill']['status']='partial'
        matrix.get('execution_acceptance', {}).pop('4', None)
        for requirement in matrix['requirements'].values():
            if requirement.get('acceptance_chunk') == 4:
                requirement.update(status='partial')
                requirement.pop('acceptance_chunk')
        matrix['chunks']['4']['status'] = 'reference_gate_complete'
        with self.assertRaisesRegex(ValueError, 'Completed execution'):
            validate(matrix)


class ToolchainRecordTests(unittest.TestCase):
    def fixture(self):
        # Synthetic schema fixture only; it is never written as qualification.
        platforms = ['sky130hd', 'gf180', 'ihp-sg13g2']
        tools = [{'name': n, 'status': 'passed'} for n in
                 ('drc-legal', 'drc-narrow', 'lvs-equal', 'lvs-wrong', 'ngspice')]
        tools[0]['count'] = 0; tools[1]['count'] = 1
        tools += [{'name': 'klayout-' + n, 'status': 'passed', 'markers': c,
                   'converted_edges': c, 'version': 'KLayout 0.30.5'} for n, c in [('legal', 0), ('narrow', 1)]]
        analog = [{'target': target, 'case': kind + '-' + state,
                   'native_status': 'failed' if state == 'fault' else 'passed',
                   'drc_count': int(state == 'fault')}
                  for target in TARGETS for kind in ('drc', 'lvs') for state in ('fault', 'repaired')]
        digital = [{'platform': p, 'case': c, 'status': 'passed',
                    'expected_check_status': 'PASS' if c == 'baseline' else 'FAIL'}
                   for p in platforms for c in ('baseline', 'removed-grid', 'antenna-route')]
        return {'chunk': 2, 'status': 'passed_reference_scope', 'source_commit': 'a'*40,
                'backend_sha256': 'b'*64, 'archive_sha256': 'c'*64,
                'scope': 'test fixture', 'limitations': ['Not engine evidence.'],
                'operating_systems': {system: {
                    'acceptance': {'backend': 'b'*64, 'runtime': {'sha256': 'c'*64, 'kind': kind}, 'platforms': platforms},
                    'installation_checks': 26, 'timing_pairs': 15, 'macro_exports': 3,
                    'physical_tool_checks': copy.deepcopy(tools), 'process_rule_controls': copy.deepcopy(analog),
                    'digital_controls': copy.deepcopy(digital), 'audit_status': 'passed'}
                    for system, kind in [('Linux', 'linux'), ('Windows', 'wsl')]},
                'hosted': {'head_sha': 'a'*40, 'steps': [{'name': n, 'status': 'completed', 'conclusion': 'success'}
                                                      for n in sorted(HOSTED_TOOLCHAIN_STEPS)]},
                'old_cli_control': {'exit': 1, 'missing_interface': 'RBA::EdgePairToEdgeOperator'}}

    def test_reference_record_demands_both_os_current_source_and_all_cases(self):
        validate_toolchain_record(self.fixture())
        changes = {
            'pending': lambda r: r.update(status='awaiting_hosted_steps'),
            'missing-windows': lambda r: r['operating_systems'].pop('Windows'),
            'stale-backend': lambda r: r['operating_systems']['Windows']['acceptance'].update(backend='d'*64),
            'wrong-os': lambda r: r['operating_systems']['Windows']['acceptance']['runtime'].update(kind='linux'),
            'missing-process-case': lambda r: r['operating_systems']['Linux']['process_rule_controls'].pop(),
            'missing-digital-fault': lambda r: r['operating_systems']['Windows']['digital_controls'].pop(),
            'false-fault': lambda r: r['operating_systems']['Linux']['process_rule_controls'][0].update(native_status='passed'),
            'negative-clean-count': lambda r: r['operating_systems']['Linux']['process_rule_controls'][1].update(drc_count=-1),
            'boolean-count': lambda r: r['operating_systems']['Linux']['physical_tool_checks'][6].update(markers=True),
            'empty-native-fault': lambda r: r['operating_systems']['Linux']['physical_tool_checks'][1].update(count=0),
            'stale-hosted-head': lambda r: r['hosted'].update(head_sha='d'*40),
            'pending-hosted-step': lambda r: r['hosted']['steps'][0].update(status='in_progress', conclusion=''),
            'failed-hosted-step': lambda r: r['hosted']['steps'][0].update(conclusion='failure'),
            'missing-hosted-step': lambda r: r['hosted']['steps'].pop(),
            'no-independent-audit': lambda r: r['operating_systems']['Linux'].update(audit_status='pending'),
            'old-engine-passed': lambda r: r['old_cli_control'].update(exit=0),
        }
        for name, change in changes.items():
            record = self.fixture(); change(record)
            with self.subTest(name=name), self.assertRaises(ValueError):
                validate_toolchain_record(record)


if __name__ == '__main__':
    unittest.main()
