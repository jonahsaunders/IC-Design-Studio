import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
repo = root/'work/IC-Design-Studio'
folder = repo/'docs/validation/sky130-local-unblock-2026-10-15'
folder.mkdir(exist_ok=False)
paths = ['work/record_sky130_local_unblock_v1.py', 'work/sky130-local-clarification-request-v1.json',
         'work/sky130-rule-sources-v1/docs/rules/periphery/p018-x_dotdash.csv',
         'work/sky130-rule-sources-v1/docs/rules/periphery-rules.rst',
         'work/sky130-rule-sources-v1/LICENSE', 'work/archive_sky130_local_unblock_v1.py']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
archive = folder/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in paths:
        info=zipfile.ZipInfo(name,(2026,10,15,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,(root/name).read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.namelist() == paths
    for name in paths: assert z.read(name) == (root/name).read_bytes()
record_path = repo/'docs/validation/sky130-local-unblock-2026-10-15.json'
record = json.loads(record_path.read_bytes())
record['source_review_archive'] = dict(path=archive.relative_to(repo).as_posix(),sha256=sha(archive),
    bytes=archive.stat().st_size,files={name:sha(root/name) for name in paths},
    reproduction='Extract into the workspace root alongside the repository checkout at work/IC-Design-Studio; run work/record_sky130_local_unblock_v1.py. It requires the retained committed dependency/catalog JSON and recreates the review before this archive metadata. No geometry acceptance is generated.')
record_path.write_bytes((json.dumps(record,indent=2,ensure_ascii=False)+'\n').encode())
permanent=root.parents[1]/'IC-Design-Studio-evidence/sky130-local-unblock-2026-10-15-v1'
permanent.mkdir(exist_ok=False)
for p in (archive,record_path):
    shutil.copyfile(p,permanent/p.name);assert sha(p)==sha(permanent/p.name)
print(json.dumps(dict(archive_sha256=sha(archive),bytes=archive.stat().st_size,files=len(paths))))
