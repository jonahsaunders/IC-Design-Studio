"""Record public applicability research without changing physical acceptance."""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT/'work/IC-Design-Studio'
SOURCE = ROOT/'work/sky130-rule-sources-v1'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
dependency_path = REPO/'docs/validation/sky130-source-dependencies-2026-10-15.json'
assert sha(dependency_path) == '58dbb942fca6c61c391db30e12050761c0dd6e419647bf0c42db19e07e08700d'
deps = json.loads(dependency_path.read_bytes())
manual_path = SOURCE/'docs/rules/periphery/p018-x_dotdash.csv'
assert sha(manual_path) == '0efaf5099bc464a782f0c05a2850673ae940272c16fa22ec519057171f2f1567'
flags_path = SOURCE/'docs/rules/periphery-rules.rst'
assert sha(flags_path) == 'a4fec57aa417caa1b52d67b684a6b17dfc1ed0b69724ffe121de421bd938d44e'
assert 'Rule intended for Frame only, not checked inside Die' in flags_path.read_text(encoding='utf8')
manual = list(csv.DictReader(manual_path.open(encoding='utf8')))
assert manual[21]['Name'] == '(x.\\n12a\\n12b\\n12c)' and manual[21]['Flags'] == 'F'
assert all(manual[i]['Name'] == '(x.12e)' and manual[i]['Flags'] == 'F' for i in (24,25))
assert manual[34]['Name'] == '(x.20)' and not manual[34]['Value'] and not manual[34]['Unit']
candidates = [r for g in deps['groups'] for r in g['records'] if r['rule'] in ('x.12b','x.12e')]
assert len(candidates) == 33
assert sum(g['count'] for g in deps['groups']) == 302
out = dict(schema=1, review_date_local='2026-10-15', chunk=6,
    status='local-only-unblocking-route-prepared', qualified=False, chunk_complete=False,
    new_coverage_decisions=0, unresolved_catalog_records=302,
    application_commit='6d4fe008762484a192fd9d947811b5eca7a37479',
    user_constraint='All verification checks must run locally. Provider-run manufacturing checks were explicitly rejected. Keep the project GPL-3.0-or-later and preserve permitted third-party terms.',
    scope='Applicability research and a prepared, unsent public clarification request. No rule is waived, reclassified, deferred past its required gate, or newly executed. No source from the Cadence-licensed checker is incorporated or used to derive an implementation.',
    checkpoint=dict(path='docs/validation/sky130-dummy-partners-2026-10-15.json',sha256=sha(REPO/'docs/validation/sky130-dummy-partners-2026-10-15.json')),
    current_manual=dict(repository='fossi-foundation/skywater-pdk',revision='e8fc249dc5d0a56a0cac5f04ecf618b2f634e9a7',
        discovery='The published documentation now links to the FOSSi-maintained repository.',
        comparison='Five commits ahead of the retained Google revision; the comparison lists only .readthedocs.yml, docs/conf.py and docs/environment.yml as changed. No rule-source update was found.',
        comparison_url='https://github.com/fossi-foundation/skywater-pdk/compare/7198cf647113f56041e02abf3eb623692820c5e1...e8fc249dc5d0a56a0cac5f04ecf618b2f634e9a7'),
    applicability_candidates=dict(count=33, remaining_without_this_flag=269,
        flag_source=dict(path='docs/rules/periphery-rules.rst',sha256=sha(flags_path),meaning='Frame-only; not checked inside the die.'),
        manual_source=dict(path='docs/rules/periphery/p018-x_dotdash.csv',sha256=sha(manual_path),records=[22,25,26]),
        rows=candidates,
        interpretation='These rules have explicit scope rather than unconditional applicability. An authenticated die-interior context and exact catalog-to-manual binding are still required. Neither an IP name nor an empty frame marker alone proves that context. The remaining depmos.13 module-enclosure row does not acquire the F flag by association.',
        acceptance_effect='None. All 33 stay unreviewed in the current catalog.'),
    local_checker_candidate=dict(repository='neu-ucb-tvip/tvip-analog-workspace',revision='a4cbf5f807853b91e73e4ef0a0cbbb27672ef950',
        license='Cadence Public License 1.0; GPL compatibility is not established here.',
        reviewed_metadata=['Sky130_DRC/README','Sky130_DRC/Include/x.drc.pvl','Sky130_DRC/Include/derived_layers.drc.pvl','Sky130_DRC/Include/density.drc.pvl','Sky130_DRC/sky130_rev_0.0_2.12.drc.pvl'],
        finding='README and x-rule file explicitly omit frame-only rules. No x.20 or IP_block token occurs in the four inspected rule files. This bounded inspection does not establish absence from the entire package or completeness of any implementation.',
        decision='Not a demonstrated complete local replacement, regardless of a possible licensing arrangement. No copied rule source or local execution.'),
    route=[
        dict(step=1,action='Bind required rules to an explicit process option and layout context using published scope definitions.',gate='Every excluded rule needs a source-backed applicability proof, with adversarial tests; unknown applicability stays unresolved.'),
        dict(step=2,action='Obtain public clarifications for missing numerical limits and generated/recognized operands.',gate='Version-applicable, publicly usable specifications or validated equivalents; no confidential package and no provider-run checks.'),
        dict(step=3,action='Implement the clarified requirements in the local engines and test valid, invalid and boundary examples.',gate='Both Windows and Linux detect deliberately injected defects; source, engine, PDK, design and enabled checks are recorded.'),
        dict(step=4,action='Rerun the complete applicable local set on the exact final designs, including density, antenna and connectivity.',gate='Original chunk 6 gate; no silent omissions or replacement by a passing shuttle subset.')],
    issue_search=dict(repository='fossi-foundation/skywater-pdk',queries=['is:issue "x.20"','is:issue "fixed_layout_model_map"','is:issue mask generation'],returned_matches=[0,0,0],limitation='Search matches are bounded and do not prove no related issue exists.'),
    clarification_request=json.loads((ROOT/'work/sky130-local-clarification-request-v1.json').read_bytes()),
    request_state='prepared-not-posted; explicit user authorization is required to post a public message',
    generator_sha256=sha(__file__))
target = REPO/'docs/validation/sky130-local-unblock-2026-10-15.json'
target.write_bytes((json.dumps(out,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps(dict(path=str(target),scope_candidates=len(candidates),new_coverage_decisions=0)))
