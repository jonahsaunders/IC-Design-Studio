import hashlib,json,stat,zipfile
from pathlib import Path,PurePosixPath
def serialize(payload,output):
    payload=Path(payload);output=Path(output)
    manifest=json.loads((payload/'manifest.json').read_bytes())
    paths={p.relative_to(payload).as_posix():p for p in payload.rglob('*') if p.is_file()}
    assert set(paths)==set(manifest['files'])|{'manifest.json'}
    assert not output.exists()
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(paths.items()):
            pure=PurePosixPath(name)
            assert not pure.is_absolute() and '..' not in pure.parts and '\\' not in name
            assert not path.is_symlink() and not path.is_junction()
            data=path.read_bytes();mode=0o755 if name=='runtime/ngspice' else 0o644
            if name!='manifest.json':
                row=manifest['files'][name]
                assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and mode==row['mode']
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.create_system=3
            info.external_attr=(stat.S_IFREG|mode)<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return output
if __name__=='__main__':
    import sys
    serialize(sys.argv[1],sys.argv[2])
