IC Design Studio Linux corrected47 scalar runtime packaging input v1

This artifact preserves the exact reviewed ngspice ELF and current scalar
initializer. It is a prepared input, not an installed-qualified runtime.
No library, model, numerical threshold or acceptance gate is replaced here.

runtime/ngspice SHA256:
67399d2db139e9a8e7bfd118cab8acfa290bb6db003c996333e55ed682a65d25
runtime/spinit SHA256:
cef1e2ffa61cf0fae3afe80afa94800df8fadc67df3178aa7f1e3216ccfb0e91

The complete original ngspice47 source archive, original changed C file,
exact capacitor-multiplier patch, historical generated initializer, upstream
COPYING, modification notice and original build/configuration logs accompany
the binary. The historical source-lock describes the original fuller build;
its launcher and optional code models are not part of runtime/. The current
scalar initializer is supplied from the GPL-3.0-or-later application source.
The builder source is retained; rebuilding its C source may produce a different
ELF because compiler, timestamp and prefix identities are not normalized.
Only serialization of these exact retained bytes is reproducible here.

Licensing and dependencies
--------------------------
Retain licenses/ngspice/COPYING verbatim, including its CC-BY-SA4.0 document
attribution and upstream component notices. Ngspice includes Modified BSD,
LGPL, MPL and other component terms; the complete original archive retains
all original file notices. The local parser modification is explicitly
identified and its complete source is reproducible from archive plus patch.

The observed ELF depends on libc, libm, loader, libgcc_s, libgomp, libstdc++,
libreadline and libtinfo. These shared libraries are NOT in this artifact.
licenses/system-reference retains exact observed Ubuntu package notices and
GPL/LGPL texts. In particular, preserve GNU Readline GPL notices, GCC runtime
exception notices, ncurses notices and glibc notices when redistributing their
actual libraries; retain corresponding-source access for actual versions.
The package/source versions are recorded, not inferred from filenames.
Final PyInstaller packaging must inventory its actual collected libraries and
retain their notices/source information. Do not bundle glibc or its loader.

Safe provisioning
-----------------
First verify the externally pinned archive SHA256. Require this exact member
inventory, names, sizes, SHA256 values and regular-file modes before extraction.
Reject duplicate members, absolute paths, traversal, links and extra files.
Extract only into a new owned directory; deploy runtime/ to the dedicated
engine location and retain all source/provenance/licenses with the distribution.
Validate actual final ELF/initializer and loaded dependency identities, then
run every existing installed gate unchanged. This artifact grants no pass.

Distribution proposal
---------------------
The compressed input is small enough to commit as a versioned runtime fixture.
No public release, external message or network publication was performed.
Update the repository notices that currently state generated runtime binaries
are absent if this exact artifact is committed. Keep old42 profile/contracts
and accepted records intact; create a new explicit runtime profile.
