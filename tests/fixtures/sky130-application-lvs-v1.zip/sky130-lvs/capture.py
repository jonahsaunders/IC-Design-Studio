import runpy
runpy.run_path('/mnt/c/Users/jonah/Documents/Codex/2026-10-06/go/outputs/sky130-lvs-application-v1/linux-v2-retained/counter/sky130-lvs/reference_engine.py',init_globals={"REQUEST_PATH":'/mnt/c/Users/jonah/Documents/Codex/2026-10-06/go/outputs/sky130-lvs-application-v1/linux-v2-retained/counter/sky130-lvs/capture-request.json'})
